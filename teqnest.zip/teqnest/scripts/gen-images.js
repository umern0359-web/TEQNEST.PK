'use strict';
/**
 * Generates stylised studio-lit SVG product renders used as placeholders for the demo catalog
 * and category cards. Replace with real product photography via the admin dashboard.
 */
const fs = require('node:fs');
const path = require('node:path');
const OUT = path.join(__dirname, '..', 'public', 'img', 'products');
fs.mkdirSync(OUT, { recursive: true });

const defs = (id, body, accent) => `
<defs>
  <radialGradient id="bg${id}" cx="50%" cy="42%" r="70%">
    <stop offset="0" stop-color="#1a2233"/><stop offset=".55" stop-color="#0f141d"/><stop offset="1" stop-color="#090b10"/>
  </radialGradient>
  <radialGradient id="glow${id}" cx="50%" cy="50%" r="50%">
    <stop offset="0" stop-color="${accent}" stop-opacity=".55"/><stop offset="1" stop-color="${accent}" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="body${id}" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="${body[0]}"/><stop offset=".5" stop-color="${body[1]}"/><stop offset="1" stop-color="${body[2]}"/>
  </linearGradient>
  <linearGradient id="sheen${id}" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".35" stop-color="#fff" stop-opacity=".06"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>
  </linearGradient>
  <linearGradient id="acc${id}" x1="0" y1="0" x2="1" y2="0">
    <stop offset="0" stop-color="#397BFF"/><stop offset="1" stop-color="#00D9FF"/>
  </linearGradient>
  <filter id="soft${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="18"/></filter>
  <filter id="sh${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="10"/></filter>
</defs>`;

const frame = (id, accent, inner, rot = 0) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800">
${defs(id, PALETTE.body, accent)}
<rect width="800" height="800" fill="url(#bg${id})"/>
<circle cx="400" cy="380" r="300" fill="url(#glow${id})" opacity=".55"/>
<g stroke="#ffffff" stroke-opacity=".04" fill="none">${Array.from({ length: 9 }, (_, i) => `<circle cx="400" cy="400" r="${80 + i * 45}"/>`).join('')}</g>
<ellipse cx="400" cy="640" rx="210" ry="26" fill="#000" opacity=".7" filter="url(#sh${id})"/>
<ellipse cx="400" cy="646" rx="260" ry="6" fill="url(#acc${id})" opacity=".35" filter="url(#sh${id})"/>
<g transform="rotate(${rot} 400 400)">${inner(id)}</g>
</svg>`;

let PALETTE = { body: ['#2b313d', '#151a23', '#0b0e14'] };

const shapes = {
  earbuds: (id) => `
    <rect x="250" y="360" width="300" height="220" rx="110" fill="url(#body${id})"/>
    <rect x="250" y="360" width="300" height="220" rx="110" fill="url(#sheen${id})"/>
    <line x1="262" y1="440" x2="538" y2="440" stroke="#000" stroke-opacity=".6" stroke-width="3"/>
    <circle cx="400" cy="505" r="6" fill="url(#acc${id})"/>
    <g transform="translate(285 210) rotate(-18)"><ellipse cx="50" cy="60" rx="52" ry="58" fill="url(#body${id})"/><ellipse cx="50" cy="60" rx="52" ry="58" fill="url(#sheen${id})"/><rect x="34" y="100" width="30" height="110" rx="15" fill="url(#body${id})"/><ellipse cx="44" cy="48" rx="20" ry="22" fill="#000" opacity=".5"/><circle cx="49" cy="194" r="4" fill="url(#acc${id})"/></g>
    <g transform="translate(420 200) rotate(16)"><ellipse cx="50" cy="60" rx="52" ry="58" fill="url(#body${id})"/><ellipse cx="50" cy="60" rx="52" ry="58" fill="url(#sheen${id})"/><rect x="36" y="100" width="30" height="110" rx="15" fill="url(#body${id})"/><ellipse cx="56" cy="48" rx="20" ry="22" fill="#000" opacity=".5"/><circle cx="51" cy="194" r="4" fill="url(#acc${id})"/></g>`,
  headphones: (id) => `
    <path d="M230 470 C230 250 570 250 570 470" fill="none" stroke="url(#body${id})" stroke-width="42" stroke-linecap="round"/>
    <path d="M236 440 C246 280 554 280 564 440" fill="none" stroke="#fff" stroke-opacity=".25" stroke-width="6" stroke-linecap="round"/>
    <rect x="180" y="420" width="120" height="190" rx="56" fill="url(#body${id})"/><rect x="180" y="420" width="120" height="190" rx="56" fill="url(#sheen${id})"/>
    <rect x="500" y="420" width="120" height="190" rx="56" fill="url(#body${id})"/><rect x="500" y="420" width="120" height="190" rx="56" fill="url(#sheen${id})"/>
    <rect x="286" y="450" width="22" height="130" rx="11" fill="#05070a"/><rect x="492" y="450" width="22" height="130" rx="11" fill="#05070a"/>
    <rect x="232" y="575" width="16" height="4" rx="2" fill="url(#acc${id})"/>`,
  watch: (id) => `
    <rect x="320" y="120" width="160" height="560" rx="60" fill="url(#body${id})" opacity=".85"/>
    <g fill="#000" opacity=".25">${Array.from({ length: 8 }, (_, i) => `<rect x="380" y="${140 + i * 22}" width="40" height="6" rx="3"/>`).join('')}${Array.from({ length: 8 }, (_, i) => `<rect x="380" y="${490 + i * 22}" width="40" height="6" rx="3"/>`).join('')}</g>
    <rect x="270" y="280" width="260" height="240" rx="64" fill="url(#body${id})"/>
    <rect x="270" y="280" width="260" height="240" rx="64" fill="url(#sheen${id})"/>
    <rect x="290" y="300" width="220" height="200" rx="48" fill="#03050a"/>
    <circle cx="400" cy="400" r="70" fill="none" stroke="url(#acc${id})" stroke-width="10" stroke-dasharray="300 140" stroke-linecap="round"/>
    <circle cx="400" cy="400" r="50" fill="none" stroke="#fff" stroke-opacity=".15" stroke-width="6"/>
    <text x="400" y="408" text-anchor="middle" font-family="Arial, sans-serif" font-size="30" font-weight="700" fill="#fff">10:09</text>
    <rect x="528" y="360" width="16" height="50" rx="6" fill="url(#body${id})"/>`,
  charger: (id) => `
    <rect x="300" y="300" width="200" height="240" rx="38" fill="url(#body${id})"/><rect x="300" y="300" width="200" height="240" rx="38" fill="url(#sheen${id})"/>
    <rect x="345" y="230" width="22" height="80" rx="6" fill="#c9ced8"/><rect x="433" y="230" width="22" height="80" rx="6" fill="#c9ced8"/>
    <rect x="360" y="470" width="80" height="18" rx="9" fill="#05070a"/>
    <path d="M405 360 l-30 50 h24 l-10 40 l34 -54 h-24 z" fill="url(#acc${id})"/>`,
  powerbank: (id) => `
    <rect x="240" y="200" width="320" height="420" rx="54" fill="url(#body${id})"/><rect x="240" y="200" width="320" height="420" rx="54" fill="url(#sheen${id})"/>
    <circle cx="400" cy="410" r="110" fill="none" stroke="#fff" stroke-opacity=".08" stroke-width="18"/>
    <circle cx="400" cy="410" r="110" fill="none" stroke="url(#acc${id})" stroke-opacity=".7" stroke-width="4"/>
    <g fill="url(#acc${id})">${[0, 1, 2, 3].map((i) => `<rect x="${352 + i * 26}" y="570" width="18" height="6" rx="3" opacity="${i < 3 ? 1 : .25}"/>`).join('')}</g>`,
  cable: (id) => `
    <path d="M250 560 C120 420 300 260 420 330 S640 520 520 600 S300 520 380 400" fill="none" stroke="url(#body${id})" stroke-width="26" stroke-linecap="round"/>
    <path d="M250 560 C120 420 300 260 420 330 S640 520 520 600 S300 520 380 400" fill="none" stroke="#fff" stroke-opacity=".12" stroke-width="6" stroke-dasharray="4 8" stroke-linecap="round"/>
    <g transform="translate(212 560) rotate(40)"><rect x="-26" y="0" width="52" height="96" rx="14" fill="url(#body${id})"/><rect x="-26" y="0" width="52" height="96" rx="14" fill="url(#sheen${id})"/><rect x="-14" y="92" width="28" height="34" rx="8" fill="#c9ced8"/></g>
    <g transform="translate(380 400) rotate(200)"><rect x="-26" y="0" width="52" height="96" rx="14" fill="url(#body${id})"/><rect x="-26" y="0" width="52" height="96" rx="14" fill="url(#sheen${id})"/><rect x="-14" y="92" width="28" height="34" rx="8" fill="#c9ced8"/></g>`,
  tracker: (id) => `
    <circle cx="400" cy="400" r="160" fill="url(#body${id})"/><circle cx="400" cy="400" r="160" fill="url(#sheen${id})"/>
    <circle cx="400" cy="400" r="120" fill="none" stroke="#000" stroke-opacity=".35" stroke-width="4"/>
    <circle cx="400" cy="400" r="18" fill="url(#acc${id})"/>
    <circle cx="400" cy="400" r="50" fill="none" stroke="url(#acc${id})" stroke-width="4" opacity=".6"/>
    <circle cx="400" cy="400" r="82" fill="none" stroke="url(#acc${id})" stroke-width="3" opacity=".3"/>
    <rect x="380" y="216" width="40" height="30" rx="12" fill="none" stroke="#c9ced8" stroke-width="8"/>`,
  speaker: (id) => `
    <rect x="270" y="190" width="260" height="440" rx="130" fill="url(#body${id})"/><rect x="270" y="190" width="260" height="440" rx="130" fill="url(#sheen${id})"/>
    <g fill="#000" opacity=".35">${Array.from({ length: 13 }, (_, r) => Array.from({ length: 7 }, (_, c) => `<circle cx="${328 + c * 24}" cy="${270 + r * 24}" r="5"/>`).join('')).join('')}</g>
    <rect x="370" y="596" width="60" height="6" rx="3" fill="url(#acc${id})"/>`,
  stand: (id) => `
    <path d="M220 560 L520 300 L560 330 L270 590 Z" fill="url(#body${id})"/>
    <path d="M220 560 L520 300 L530 308 L230 568 Z" fill="#fff" opacity=".25"/>
    <rect x="460" y="300" width="40" height="300" rx="12" fill="url(#body${id})" transform="rotate(14 480 450)"/>
    <rect x="200" y="584" width="400" height="20" rx="10" fill="url(#body${id})"/>
    <rect x="200" y="584" width="400" height="6" rx="3" fill="url(#acc${id})" opacity=".6"/>`,
  hub: (id) => `
    <rect x="200" y="330" width="400" height="140" rx="48" fill="url(#body${id})"/><rect x="200" y="330" width="400" height="140" rx="48" fill="url(#sheen${id})"/>
    <g fill="#05070a">${[0, 1, 2, 3].map((i) => `<rect x="${250 + i * 80}" y="385" width="50" height="22" rx="8"/>`).join('')}</g>
    <path d="M600 400 C680 400 690 520 620 560" fill="none" stroke="url(#body${id})" stroke-width="18" stroke-linecap="round"/>
    <rect x="236" y="440" width="40" height="5" rx="2.5" fill="url(#acc${id})"/>`,
};

const colors = {
  graphite: ['#3a4150', '#1a1f29', '#0b0e14'],
  white: ['#ffffff', '#d9dee7', '#9aa3b2'],
  blue: ['#5a93ff', '#2a5fd6', '#132e70'],
  silver: ['#e9edf3', '#a5adba', '#5a6170'],
  cyan: ['#59e8ff', '#0aa4c4', '#06485a'],
};

const out = [];
for (const [shape, fn] of Object.entries(shapes)) {
  for (const [cname, body] of Object.entries(colors)) {
    for (const [vi, rot] of [[1, 0], [2, -10]]) {
      PALETTE = { body };
      const id = `${shape}${cname}${vi}`;
      const accent = vi === 1 ? '#397BFF' : '#00D9FF';
      const file = `${shape}-${cname}-${vi}.svg`;
      fs.writeFileSync(path.join(OUT, file), frame(id, accent, fn, rot).replace(/\n\s+/g, '\n'));
      out.push(file);
    }
  }
}
// Social share image
fs.writeFileSync(path.join(__dirname, '..', 'public', 'img', 'og.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630"><rect width="1200" height="630" fill="#090B10"/><text x="80" y="330" font-family="Arial" font-weight="800" font-size="110" fill="#fff" letter-spacing="10">TEQNEST</text><text x="84" y="400" font-family="Arial" font-size="36" fill="#A7AFBD">Technology That Fits Your Lifestyle.</text></svg>`);
console.log(`Generated ${out.length} product renders in ${OUT}`);
