'use strict';
// Integration tests against an isolated temporary database.
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'teqnest-test-'));
process.env.DATA_DIR = dir;
process.env.ADMIN_EMAIL = 'admin@test.pk';
process.env.ADMIN_PASSWORD = 'TestAdminPass123';
const app = require('../server/index.js');
const { get } = require('../server/db');

let server, base;
before(async () => { server = app.listen(0); await new Promise((r) => server.once('listening', r)); base = `http://127.0.0.1:${server.address().port}`; });
after(() => { server.close(); fs.rmSync(dir, { recursive: true, force: true }); });

function client() {
  let cookies = {};
  return async (p, { method = 'GET', body, raw } = {}) => {
    const res = await fetch(base + p, {
      method,
      headers: { 'X-Requested-With': raw ? '' : 'teqnest', 'Content-Type': 'application/json', cookie: Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join('; ') },
      body: body ? JSON.stringify(body) : undefined,
    });
    for (const c of res.headers.getSetCookie()) { const [kv] = c.split(';'); const [k, v] = kv.split('='); if (v) cookies[k] = v; else delete cookies[k]; }
    const data = await res.json().catch(() => null);
    return { status: res.status, data };
  };
}
const customer = { full_name: 'Test Buyer', phone: '0300 1234567', address: 'House 12, Street 3, Gulshan', city: 'Karachi', zone_id: 1, payment_method: 'cod' };

test('rejects state-changing requests without the CSRF header', async () => {
  const c = client();
  const r = await c('/api/cart/items', { method: 'POST', body: { product_id: 1, qty: 1 }, raw: true });
  assert.equal(r.status, 403);
});

test('unavailable products cannot be added to the cart', async () => {
  const c = client();
  for (const sku of ['DEMO-SW-02', 'DEMO-HP-02', 'DEMO-MA-03']) { // on_request, coming_soon, out_of_stock
    const p = get('SELECT id FROM products WHERE sku = ?', sku);
    const r = await c('/api/cart/items', { method: 'POST', body: { product_id: p.id, qty: 1 } });
    assert.equal(r.status, 409, sku);
  }
});

test('checkout decrements stock, applies delivery fee, and cancel restores stock', async () => {
  const c = client();
  const p = get(`SELECT * FROM products WHERE sku = 'DEMO-MA-01'`); // 2499, stock 60
  let r = await c('/api/cart/items', { method: 'POST', body: { product_id: p.id, qty: 2 } });
  assert.equal(r.data.subtotal, 4998);
  r = await c('/api/checkout', { method: 'POST', body: customer });
  assert.equal(r.status, 201);
  const order = get('SELECT * FROM orders WHERE order_number = ?', r.data.order_number);
  assert.equal(order.delivery_fee, 250); // below Karachi free threshold
  assert.equal(order.total, 4998 + 250);
  assert.equal(get('SELECT stock FROM products WHERE id = ?', p.id).stock, p.stock - 2);
  // order lookup needs the token
  assert.equal((await client()(`/api/orders/${order.order_number}`)).status, 404);
  assert.equal((await c(`/api/orders/${order.order_number}?t=${r.data.access_token}`)).status, 200);
  // admin cancels
  const a = client();
  assert.equal((await a('/api/account/login', { method: 'POST', body: { email: 'admin@test.pk', password: 'TestAdminPass123' } })).status, 200);
  assert.equal((await a(`/api/admin/orders/${order.id}/status`, { method: 'POST', body: { status: 'cancelled', notify: false } })).status, 200);
  assert.equal(get('SELECT stock FROM products WHERE id = ?', p.id).stock, p.stock);
});

test('cannot oversell stock', async () => {
  const c = client();
  const p = get(`SELECT * FROM products WHERE sku = 'DEMO-GD-02'`); // stock 3
  const r = await c('/api/cart/items', { method: 'POST', body: { product_id: p.id, qty: p.stock + 1 } });
  assert.equal(r.status, 409);
});

test('coupons respect usage limits', async () => {
  const a = client();
  await a('/api/account/login', { method: 'POST', body: { email: 'admin@test.pk', password: 'TestAdminPass123' } });
  assert.equal((await a('/api/admin/coupons', { method: 'POST', body: { code: 'ONCE', type: 'percent', value: 10, usage_limit: 1, active: true } })).status, 201);
  const p = get(`SELECT id FROM products WHERE sku = 'DEMO-MA-01'`);
  for (const expected of [201, 400]) {
    const c = client();
    await c('/api/cart/items', { method: 'POST', body: { product_id: p.id, qty: 1 } });
    const ap = await c('/api/cart/coupon', { method: 'POST', body: { code: 'once' } });
    if (expected === 201) { assert.equal(ap.data.discount, 249); assert.equal((await c('/api/checkout', { method: 'POST', body: customer })).status, 201); }
    else assert.equal(ap.status, 400);
  }
});

test('customers and staff cannot reach admin-only endpoints', async () => {
  const c = client();
  assert.equal((await c('/api/admin/dashboard')).status, 401);
  await c('/api/account/register', { method: 'POST', body: { name: 'Cust', email: 'cust@test.pk', password: 'password123' } });
  assert.equal((await c('/api/admin/dashboard')).status, 403);
  assert.equal((await c('/api/admin/settings')).status, 403);
});

test('reviews require a delivered order', async () => {
  const c = client();
  await c('/api/account/register', { method: 'POST', body: { name: 'Reviewer', email: 'rev@test.pk', password: 'password123' } });
  const p = get(`SELECT id FROM products WHERE sku = 'DEMO-GD-01'`);
  assert.equal((await c('/api/account/reviews', { method: 'POST', body: { product_id: p.id, rating: 5, body: 'Great product, works well.' } })).status, 403);
  await c('/api/cart/items', { method: 'POST', body: { product_id: p.id, qty: 1 } });
  const o = await c('/api/checkout', { method: 'POST', body: customer });
  const id = get('SELECT id FROM orders WHERE order_number = ?', o.data.order_number).id;
  const a = client();
  await a('/api/account/login', { method: 'POST', body: { email: 'admin@test.pk', password: 'TestAdminPass123' } });
  for (const s of ['confirmed', 'shipped', 'delivered']) await a(`/api/admin/orders/${id}/status`, { method: 'POST', body: { status: s, notify: false } });
  assert.equal((await c('/api/account/reviews', { method: 'POST', body: { product_id: p.id, rating: 5, body: 'Great product, works well.' } })).status, 201);
  // pending until approved
  const slug = get('SELECT slug FROM products WHERE id = ?', p.id).slug;
  assert.equal((await c(`/api/products/${slug}/reviews`)).data.length, 0);
});

test('product pages get server-rendered SEO meta', async () => {
  const res = await fetch(`${base}/product/orbit-s-smartwatch`);
  const html = await res.text();
  assert.match(html, /<title>Orbit S Smartwatch \| TEQNEST<\/title>/);
  assert.match(html, /"@type":"Product"/);
  assert.equal((await fetch(`${base}/product/does-not-exist`)).status, 404);
});
