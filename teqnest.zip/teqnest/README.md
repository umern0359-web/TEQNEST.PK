# TEQNEST.PK — E-commerce Platform

A full-stack e-commerce site for TEQNEST: storefront, customer accounts, cart and checkout, order management, and an admin dashboard that lets the owner run the store without touching code.

**Stack:** Node.js 22 + Express 5 · SQLite (Node's built-in `node:sqlite`, no native build) · Vanilla ES-module SPA · Three.js (hero + optional 3D viewer) · GSAP + ScrollTrigger · bcrypt · Helmet CSP.

## Quick start

```bash
npm install
ADMIN_EMAIL=you@teqnest.pk ADMIN_PASSWORD='a-long-password' npm start
```

- Storefront: http://localhost:3000
- Admin: http://localhost:3000/admin

On first boot the database is created and seeded with default content, two delivery zones, six categories, 13 **demo** products and the admin account. If `ADMIN_PASSWORD` is not set, a random password is printed to the console once.

```bash
npm test                                                   # integration tests (isolated temp DB)
npm run create-admin -- owner@teqnest.pk "Owner" admin     # add/reset an admin or staff account
```

## Before going live — owner checklist

Things only the business can supply. The site works without them, but they must be set before launch:

| Item | Where |
|---|---|
| Official logo | Admin → Website content → Brand (upload). No logo was supplied, so a text wordmark is shown; no logo was invented. |
| WhatsApp number | Admin → Website content → Contact. WhatsApp buttons stay hidden until it is set. |
| Phone, email, address, social links | Admin → Website content → Contact / Social media |
| **Real products** | Admin → Products. Delete or replace the `DEMO-` products. Their names, specs and prices are **sample data** for testing. Then turn off “Show Demo catalog notice” in Website content → Brand. |
| Product photos | The demo images are generated illustrations. Upload real photos for each product and category. |
| Delivery charges | Admin → Delivery zones. Seeded values (Karachi Rs 250, other cities Rs 400) are placeholders. |
| Payment methods | Admin → Payment methods. Only Cash on Delivery is on. Enable Bank Transfer / Easypaisa / JazzCash only once you have account details to enter. |
| Policies | Admin → Website content → Policy pages. The seeded texts are **drafts** marked for legal review. |
| Email (SMTP) | `.env`: needed for order confirmations, status emails and password resets. Without it, emails are recorded in Admin → Activity but not sent. |

## Features

**Storefront.** Cinematic hero with a procedurally modelled Three.js scene (headphones, smartwatch, earbuds) under studio lighting. It adapts quality to the device (pixel ratio, particles, antialiasing), pauses when off-screen, draws a single still frame for reduced-motion users, and falls back to static images when WebGL is unavailable or Data Saver is on. Also: animated announcement bar, glass header with mega menu, animated mobile menu, 3D-tilt category cards, product cards with hover image swap, quick view, wishlist and stock states, a touch-friendly new-arrivals carousel, brand story with parallax, promo banner, feature cards, verified-review wall, newsletter, footer and a floating WhatsApp button. Dark theme by default with a light theme toggle.

**Catalog.** SKU, slug, descriptions, multiple images, videos (uploads, YouTube, Vimeo), optional `.glb` 3D model, regular and sale price, category, specs, colours, features, box contents, stock, low-stock threshold, featured / new / trending flags, and SEO title and description.

**Availability.** Five states: In Stock, Out of Stock, Coming Soon, Available on Request, Pre-order. Only In Stock (with stock above zero) and Pre-order can be bought. The other states show a WhatsApp inquiry button instead of Add to Cart. An In Stock product with zero stock automatically shows as Out of Stock, so nothing is shown as available when it isn't.

**Search and discovery.** Instant search overlay (press `/` or Ctrl+K) with keyboard navigation and suggestions. Category, availability, price-range and on-sale filters, six sort orders, pagination, and a filter sheet on mobile.

**Product page.** Gallery with hover zoom, fullscreen lightbox, swipe, thumbnails, video and 3D tabs. Colours, quantity, Add to Cart, Buy Now, wishlist, WhatsApp inquiry with a pre-filled message, tabs (overview, specs, box contents, reviews), related and recently viewed products, and a sticky buy bar on mobile.

**Cart.** Stored on the server (guest cookie, or tied to the account and merged on login). Live stock checks, quantity limits, discount codes, delivery zone fees and free-delivery thresholds.

**Checkout.** Pakistani mobile number validation, saved addresses, delivery zones with per-zone Cash on Delivery, and configurable payment methods. Stock is reserved atomically, so a product cannot be oversold. Each order gets a unique number (`TQ-YYMMDD-XXXXX`). The confirmation page offers a WhatsApp confirmation message that contains no address, phone or payment details. For manual transfers, the customer submits a transaction ID and the admin verifies it.

**Accounts.** Register, login, logout, password reset by email, profile, password change, addresses, order history and detail, wishlist, and reviews (only for products in a delivered order, and published only after moderation). Guest checkout and public order tracking (order number + mobile) are both available.

**Admin.**
- Dashboard: sales and revenue chart, order counts by status, customers, best sellers, low stock.
- Products: full editor with uploads, plus inline stock, availability and flag edits.
- Categories.
- Orders: search and filters; status changes (cancelling restores stock and the coupon use), tracking, payment verification, internal notes, a WhatsApp link to the customer.
- Customers, review moderation, newsletter subscribers with CSV export.
- Discount codes, delivery zones, payment methods.
- All homepage and footer content, announcements, WhatsApp and social links, policy and FAQ pages.
- Staff accounts with roles, activity log and email log.

**Roles.** `admin` has full access. `staff` manages orders, products, categories, reviews and customers, but not settings, coupons, delivery, payments or staff.

## Security

- Passwords hashed with bcrypt (cost 12). Login timing is equalised and password-reset responses don't reveal whether an account exists.
- Sessions are random tokens stored as SHA-256 hashes, in `HttpOnly`, `SameSite=Lax` cookies (`Secure` in production).
- CSRF: every state-changing API call needs a custom header, together with SameSite cookies.
- Role checks happen on the server for every admin route. No credentials or keys are sent to the browser.
- Strict Content Security Policy (no inline scripts; the import map is allowed by its hash). Uploads are served with a sandbox CSP and `nosniff`. Uploaded file contents are checked, and SVGs containing scripts are rejected.
- Parameterised SQL everywhere, input validation on every endpoint, and rate limits on login, checkout, coupon, tracking and newsletter endpoints.
- Order links use a secret token, which is removed from the address bar after first use. Public tracking shows status only, never address or contact details.
- Admin changes are written to an audit log. Subscriber CSV export is protected against spreadsheet formula injection.

## SEO

The server writes a real `<title>`, description, canonical link, Open Graph tags and JSON-LD (Organization, plus Product with offer, availability and rating) into each product and category URL. Also included: `sitemap.xml`, `robots.txt`, and `noindex` on account, cart and checkout pages.

## Deployment

Any host that runs Node 22.5+ with a persistent disk works: a VPS, Railway, Render or Fly.io.

```bash
docker build -t teqnest .
docker run -p 3000:3000 -v teqnest-data:/app/data --env-file .env teqnest
```

Put the site behind HTTPS (for example Caddy, Nginx with Let's Encrypt, or the host's TLS), set `NODE_ENV=production` and `PUBLIC_URL=https://teqnest.pk`, and **back up `DATA_DIR`**: it holds the database and uploaded images. SQLite in WAL mode handles a single-server store of this size comfortably. To scale beyond one server, move to Postgres.

## Project layout

```
server/            Express app, SQLite schema, auth, cart, orders, routes (shop, account, admin), seed
public/            Storefront (app.html, css, js/views), admin SPA (public/admin), images
scripts/           Demo product illustration generator
test/              Integration tests
```
