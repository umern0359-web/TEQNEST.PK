'use strict';
const bcrypt = require('bcryptjs');
const { get, run } = require('./db');
const { randomToken, sha256, HttpError } = require('./util');

const SESSION_COOKIE = 'tq_sess';
const GUEST_COOKIE = 'tq_cart';
const SESSION_DAYS = 30;
const isProd = process.env.NODE_ENV === 'production';

const cookieOpts = (days) => ({
  httpOnly: true, sameSite: 'lax', secure: isProd, path: '/', maxAge: days * 864e5,
});

const hashPassword = (pw) => bcrypt.hash(pw, 12);
const verifyPassword = (pw, hash) => bcrypt.compare(pw, hash);

function createSession(res, userId) {
  const token = randomToken();
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  run('INSERT INTO sessions(token_hash, user_id, expires_at) VALUES (?,?,?)', sha256(token), userId, expires);
  run(`UPDATE users SET last_login_at = datetime('now') WHERE id = ?`, userId);
  res.cookie(SESSION_COOKIE, token, cookieOpts(SESSION_DAYS));
}

function destroySession(req, res) {
  const t = req.cookies?.[SESSION_COOKIE];
  if (t) run('DELETE FROM sessions WHERE token_hash = ?', sha256(t));
  res.clearCookie(SESSION_COOKIE, { path: '/' });
}

/** Attaches req.user (or null). */
function loadUser(req, _res, next) {
  req.user = null;
  const t = req.cookies?.[SESSION_COOKIE];
  if (t) {
    const row = get(`SELECT u.id, u.email, u.name, u.phone, u.role, u.active, s.expires_at
      FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`, sha256(t));
    if (row && row.active && new Date(row.expires_at) > new Date()) {
      delete row.expires_at; delete row.active;
      req.user = row;
    }
  }
  next();
}

const requireUser = (req, _res, next) => req.user ? next() : next(new HttpError(401, 'Please log in to continue.'));

/** Role-based access. admin > staff. Staff can manage orders/products/reviews but not settings, users, or coupons. */
const ROLE_RANK = { customer: 0, staff: 1, admin: 2 };
const requireRole = (role) => (req, _res, next) => {
  if (!req.user) return next(new HttpError(401, 'Please log in.'));
  if ((ROLE_RANK[req.user.role] ?? 0) < ROLE_RANK[role]) return next(new HttpError(403, 'You do not have permission for this action.'));
  next();
};

/**
 * CSRF defence for the JSON API: state-changing requests must carry a custom header,
 * which browsers will not send cross-origin without a CORS preflight (which we never allow).
 * Combined with SameSite=Lax cookies.
 */
function csrfGuard(req, _res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Requested-With') !== 'teqnest') return next(new HttpError(403, 'Invalid request origin.'));
  next();
}

module.exports = {
  SESSION_COOKIE, GUEST_COOKIE, cookieOpts, hashPassword, verifyPassword,
  createSession, destroySession, loadUser, requireUser, requireRole, csrfGuard,
};
