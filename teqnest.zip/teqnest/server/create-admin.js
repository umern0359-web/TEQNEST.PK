'use strict';
// Usage: npm run create-admin -- email@example.com "Full Name" [admin|staff]
// Reads the password from the ADMIN_PASSWORD env var or prompts on stdin.
const readline = require('node:readline');
const bcrypt = require('bcryptjs');
const { get, run } = require('./db');

(async () => {
  const [email, name = 'Admin', role = 'admin'] = process.argv.slice(2);
  if (!email || !['admin', 'staff'].includes(role)) { console.error('Usage: npm run create-admin -- <email> "<name>" [admin|staff]'); process.exit(1); }
  let pw = process.env.ADMIN_PASSWORD;
  if (!pw) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    pw = await new Promise((r) => rl.question('Password (min 12 chars): ', (a) => { rl.close(); r(a); }));
  }
  if (!pw || pw.length < 12) { console.error('Password must be at least 12 characters.'); process.exit(1); }
  const hash = bcrypt.hashSync(pw, 12);
  const u = get('SELECT id FROM users WHERE email = ?', email.toLowerCase());
  if (u) run('UPDATE users SET password_hash = ?, role = ?, active = 1 WHERE id = ?', hash, role, u.id);
  else run('INSERT INTO users(email, password_hash, name, role) VALUES (?,?,?,?)', email.toLowerCase(), hash, name, role);
  console.log(`✓ ${role} account ready for ${email}`);
})();
