'use strict';
const path = require('node:path');
const fs = require('node:fs');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const { get, all, getSetting, DATA_DIR } = require('./db');
const { loadUser, csrfGuard } = require('./auth');
const { HttpError, serializeProduct, PRODUCT_SELECT } = require('./util');

// Seed defaults on first boot so the site is usable immediately.
if (!get('SELECT 1 FROM settings LIMIT 1')) require('./seed').seed({ quiet: false });

const app = express();
// The only inline script is the import map; allow it by hash rather than 'unsafe-inline'.
const IMPORT_MAP_HASH = (() => {
  const m = fs.readFileSync(path.join(__dirname, '..', 'public', 'app.html'), 'utf8').match(/<script type="importmap">([\s\S]*?)<\/script>/);
  return m ? `'sha256-${require('node:crypto').createHash('sha256').update(m[1]).digest('base64')}'` : null;
})();
const PUBLIC = path.join(__dirname, '..', 'public');
const isProd = process.env.NODE_ENV === 'production';
app.set('trust proxy', process.env.TRUST_PROXY ? Number(process.env.TRUST_PROXY) : 1);
app.disable('x-powered-by');

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'", ...(IMPORT_MAP_HASH ? [IMPORT_MAP_HASH] : [])],
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com', 'data:'],
      'img-src': ["'self'", 'data:', 'blob:', 'https:'],
      'media-src': ["'self'", 'https:', 'blob:'],
      'connect-src': ["'self'", 'blob:', 'data:'],
      'frame-src': ['https://www.youtube-nocookie.com', 'https://www.youtube.com', 'https://player.vimeo.com'],
      'worker-src': ["'self'", 'blob:'],
      'upgrade-insecure-requests': isProd ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false,
  strictTransportSecurity: isProd,
}));
app.use(compression());
app.use(cookieParser());
app.use(express.json({ limit: '300kb' }));

// ---------- static ----------
const staticOpts = { maxAge: isProd ? '7d' : 0, index: false };
app.use('/vendor/three', express.static(path.join(__dirname, '..', 'node_modules', 'three', 'build'), staticOpts));
app.use('/vendor/three-addons', express.static(path.join(__dirname, '..', 'node_modules', 'three', 'examples', 'jsm'), staticOpts));
app.use('/vendor/gsap', express.static(path.join(__dirname, '..', 'node_modules', 'gsap', 'dist'), staticOpts));
app.use('/uploads', express.static(path.join(DATA_DIR, 'uploads'), {
  maxAge: '30d', index: false,
  setHeaders: (res) => { res.set('X-Content-Type-Options', 'nosniff'); res.set('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; sandbox"); },
}));
app.use(express.static(PUBLIC, staticOpts));

// ---------- API ----------
app.use('/api', loadUser, csrfGuard);
app.use('/api', (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use('/api', require('./routes/shop'));
app.use('/api/account', require('./routes/account'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (_req, _res, next) => next(new HttpError(404, 'Not found')));

// ---------- SEO: robots, sitemap ----------
const baseUrl = (req) => process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
app.get('/robots.txt', (req, res) => res.type('text/plain').send(`User-agent: *\nDisallow: /admin\nDisallow: /api/\nDisallow: /account\nDisallow: /checkout\nDisallow: /cart\nSitemap: ${baseUrl(req)}/sitemap.xml\n`));
app.get('/sitemap.xml', (req, res) => {
  const b = baseUrl(req);
  const urls = ['/', '/shop', '/new-arrivals', '/about', '/track', '/faq', ...['privacy', 'terms', 'shipping', 'returns'].map((p) => `/policy/${p}`)]
    .map((u) => ({ loc: b + u }))
    .concat(all('SELECT slug FROM categories WHERE active = 1').map((c) => ({ loc: `${b}/shop/${c.slug}` })))
    .concat(all('SELECT slug, updated_at FROM products WHERE active = 1').map((p) => ({ loc: `${b}/product/${p.slug}`, lastmod: p.updated_at.slice(0, 10) })));
  res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `<url><loc>${esc(u.loc)}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}</url>`).join('\n')}\n</urlset>`);
});

// ---------- HTML shells with server-rendered meta ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const jsonLd = (o) => JSON.stringify(o).replace(/</g, '\\u003c');
let shellCache = null;
const shell = () => (isProd && shellCache) || (shellCache = fs.readFileSync(path.join(PUBLIC, 'app.html'), 'utf8'));

const SCHEMA_AVAIL = { in_stock: 'InStock', out_of_stock: 'OutOfStock', coming_soon: 'PreOrder', on_request: 'BackOrder', preorder: 'PreOrder' };

function metaFor(req) {
  const brand = getSetting('brand', {});
  const site = brand.name || 'TEQNEST';
  const b = baseUrl(req);
  let m = { title: `${site} — ${brand.tagline || 'Technology That Fits Your Lifestyle.'}`, description: brand.meta_description || '', image: `${b}/img/og.png`, url: b + req.path, ld: [] };
  m.ld.push({ '@context': 'https://schema.org', '@type': 'Organization', name: site, url: b });
  let mm;
  if ((mm = req.path.match(/^\/product\/([\w-]+)$/))) {
    const p = get(PRODUCT_SELECT + ' WHERE p.slug = ? AND p.active = 1', mm[1]);
    if (p) {
      const sp = serializeProduct(p, { full: true });
      m.title = sp.seo_title || `${sp.name} | ${site}`;
      m.description = sp.seo_description || sp.short_description || m.description;
      if (sp.images[0]) m.image = sp.images[0].startsWith('http') ? sp.images[0] : b + sp.images[0];
      const ld = { '@context': 'https://schema.org', '@type': 'Product', name: sp.name, sku: sp.sku, description: m.description, image: sp.images.map((i) => i.startsWith('http') ? i : b + i), brand: { '@type': 'Brand', name: site } };
      if (sp.price != null) ld.offers = { '@type': 'Offer', priceCurrency: 'PKR', price: sp.price, availability: `https://schema.org/${SCHEMA_AVAIL[sp.availability]}`, url: m.url };
      if (sp.rating) ld.aggregateRating = { '@type': 'AggregateRating', ratingValue: sp.rating.average, reviewCount: sp.rating.count };
      m.ld.push(ld);
    } else m.status = 404;
  } else if ((mm = req.path.match(/^\/shop\/([\w-]+)$/))) {
    const c = get('SELECT * FROM categories WHERE slug = ? AND active = 1', mm[1]);
    if (c) { m.title = `${c.name} | ${site}`; m.description = c.description || m.description; } else m.status = 404;
  } else if (req.path === '/shop') { m.title = `Shop All | ${site}`; }
  else if (req.path === '/new-arrivals') { m.title = `New Arrivals | ${site}`; }
  return m;
}

app.get(['/admin', '/admin/'], (_req, res) => res.sendFile(path.join(PUBLIC, 'admin', 'index.html')));
app.get(/^\/(?!api\/|uploads\/|vendor\/).*/, (req, res) => {
  if (path.extname(req.path)) return res.status(404).send('Not found');
  const m = metaFor(req);
  const tags = [
    `<title>${esc(m.title)}</title>`,
    `<meta name="description" content="${esc(m.description)}">`,
    `<link rel="canonical" href="${esc(m.url)}">`,
    `<meta property="og:type" content="website"><meta property="og:site_name" content="TEQNEST">`,
    `<meta property="og:title" content="${esc(m.title)}"><meta property="og:description" content="${esc(m.description)}">`,
    `<meta property="og:url" content="${esc(m.url)}"><meta property="og:image" content="${esc(m.image)}">`,
    `<meta name="twitter:card" content="summary_large_image">`,
    ...m.ld.map((x) => `<script type="application/ld+json">${jsonLd(x)}</script>`),
    /^\/(account|checkout|cart|order)/.test(req.path) ? '<meta name="robots" content="noindex">' : '',
  ].join('\n    ');
  res.status(m.status || 200).type('html').send(shell().replace('<!--SEO-->', tags));
});

// ---------- errors ----------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  let status = err.status || err.statusCode || 500;
  if (err.code === 'LIMIT_FILE_SIZE') status = 413;
  if (err.type === 'entity.parse.failed') status = 400;
  if (status >= 500) console.error(err);
  const message = status >= 500 ? 'Something went wrong on our side. Please try again.' : (err.code === 'LIMIT_FILE_SIZE' ? 'File is too large.' : err.message);
  res.status(status).json({ error: message, ...(err.extra || {}) });
});

const PORT = Number(process.env.PORT || 3000);
if (require.main === module) {
  app.listen(PORT, () => console.log(`TEQNEST running on http://localhost:${PORT}  (admin: /admin)`));
}
module.exports = app;
