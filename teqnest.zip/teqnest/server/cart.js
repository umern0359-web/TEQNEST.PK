'use strict';
const { get, all, run, tx } = require('./db');
const { GUEST_COOKIE, cookieOpts } = require('./auth');
const { randomToken, sha256, serializeProduct, PRODUCT_SELECT, evaluateCoupon, deliveryFor, HttpError } = require('./util');

/** Finds the cart for the current visitor. Creates one only when `create` is true. */
function findCart(req, res, { create = false } = {}) {
  if (req.user) {
    let c = get('SELECT * FROM carts WHERE user_id = ?', req.user.id);
    if (!c && create) {
      run('INSERT INTO carts(user_id) VALUES (?)', req.user.id);
      c = get('SELECT * FROM carts WHERE user_id = ?', req.user.id);
    }
    return c || null;
  }
  const t = req.cookies?.[GUEST_COOKIE];
  if (t) {
    const c = get('SELECT * FROM carts WHERE guest_token_hash = ?', sha256(t));
    if (c) return c;
  }
  if (!create) return null;
  const token = randomToken();
  run('INSERT INTO carts(guest_token_hash) VALUES (?)', sha256(token));
  res.cookie(GUEST_COOKIE, token, cookieOpts(60));
  return get('SELECT * FROM carts WHERE guest_token_hash = ?', sha256(token));
}

/** Moves a guest cart into the user's cart on login/registration. */
function mergeGuestCart(req, res, userId) {
  const t = req.cookies?.[GUEST_COOKIE];
  if (!t) return;
  const guest = get('SELECT * FROM carts WHERE guest_token_hash = ?', sha256(t));
  res.clearCookie(GUEST_COOKIE, { path: '/' });
  if (!guest) return;
  tx(() => {
    let uc = get('SELECT * FROM carts WHERE user_id = ?', userId);
    if (!uc) {
      run('UPDATE carts SET user_id = ?, guest_token_hash = NULL WHERE id = ?', userId, guest.id);
      return;
    }
    for (const it of all('SELECT * FROM cart_items WHERE cart_id = ?', guest.id)) {
      run(`INSERT INTO cart_items(cart_id, product_id, color, qty) VALUES (?,?,?,?)
           ON CONFLICT(cart_id, product_id, color) DO UPDATE SET qty = MIN(10, qty + excluded.qty)`,
        uc.id, it.product_id, it.color, it.qty);
    }
    if (guest.coupon_code && !uc.coupon_code) run('UPDATE carts SET coupon_code = ? WHERE id = ?', guest.coupon_code, uc.id);
    run('DELETE FROM carts WHERE id = ?', guest.id);
  });
}

/** Builds a fully-priced view of the cart, validating every line against live stock/availability. */
function buildCart(cart) {
  const empty = { items: [], count: 0, subtotal: 0, discount: 0, delivery_fee: null, total: 0, coupon: null, issues: [], zones: deliveryFor(null, 0).zones, zone_id: null, can_checkout: false };
  if (!cart) return empty;
  const rows = all(`SELECT ci.id AS line_id, ci.qty, ci.color, p.* , c.slug AS category_slug, c.name AS category_name
    FROM cart_items ci JOIN products p ON p.id = ci.product_id LEFT JOIN categories c ON c.id = p.category_id
    WHERE ci.cart_id = ? ORDER BY ci.id`, cart.id);
  const issues = [];
  const items = rows.map((r) => {
    const p = serializeProduct(r);
    let problem = null;
    if (!r.active) problem = 'This product is no longer available.';
    else if (!p.purchasable) problem = `${p.availability_label} — cannot be purchased right now.`;
    else if (r.availability !== 'preorder' && r.qty > r.stock) problem = `Only ${r.stock} left in stock.`;
    if (problem) issues.push({ line_id: r.line_id, name: r.name, message: problem });
    return {
      line_id: r.line_id, qty: r.qty, color: r.color, problem,
      product: { id: p.id, name: p.name, slug: p.slug, image: p.images[0] || null, price: p.price, regular_price: p.regular_price, availability: p.availability, availability_label: p.availability_label, max_qty: p.max_qty, sku: p.sku },
      line_total: (p.price || 0) * r.qty,
    };
  });
  const valid = items.filter((i) => !i.problem);
  const subtotal = valid.reduce((s, i) => s + i.line_total, 0);
  const cp = evaluateCoupon(cart.coupon_code, subtotal);
  const d = deliveryFor(cart.zone_id, subtotal - cp.discount);
  const delivery_fee = d.zone ? d.fee : null;
  return {
    items, count: items.reduce((s, i) => s + i.qty, 0), subtotal,
    discount: cp.discount, coupon: cp.coupon, coupon_error: cart.coupon_code && cp.error ? cp.error : null,
    zone_id: d.zone ? d.zone.id : null, zones: d.zones.map((z) => ({ id: z.id, name: z.name, description: z.description, fee: z.fee, free_threshold: z.free_threshold, cod_available: !!z.cod_available })),
    delivery_fee, free_delivery: !!d.free,
    total: subtotal - cp.discount + (delivery_fee || 0),
    issues, can_checkout: valid.length > 0 && issues.length === 0,
  };
}

function addItem(cart, productId, qty, color) {
  const p = get(PRODUCT_SELECT + ' WHERE p.id = ? AND p.active = 1', productId);
  if (!p) throw new HttpError(404, 'Product not found.');
  const sp = serializeProduct(p);
  if (!sp.purchasable) throw new HttpError(409, `${p.name} is ${sp.availability_label.toLowerCase()} and cannot be added to the cart. Please send us an inquiry instead.`);
  const colors = sp.colors.map((c) => c.name);
  if (colors.length && !colors.includes(color)) color = colors[0];
  if (!colors.length) color = '';
  const existing = get('SELECT qty FROM cart_items WHERE cart_id = ? AND product_id = ? AND color = ?', cart.id, p.id, color);
  const newQty = (existing?.qty || 0) + qty;
  if (newQty > sp.max_qty) throw new HttpError(409, sp.max_qty ? `You can add at most ${sp.max_qty} of this item.` : 'Not enough stock.');
  run(`INSERT INTO cart_items(cart_id, product_id, color, qty) VALUES (?,?,?,?)
       ON CONFLICT(cart_id, product_id, color) DO UPDATE SET qty = excluded.qty`, cart.id, p.id, color, newQty);
  run(`UPDATE carts SET updated_at = datetime('now') WHERE id = ?`, cart.id);
}

module.exports = { findCart, mergeGuestCart, buildCart, addItem };
