'use strict';
const crypto = require('node:crypto');
const { get, all, run, tx, getSetting } = require('./db');
const { buildCart } = require('./cart');
const { HttpError, bad, str, email, pkPhone, int, randomToken, sha256 } = require('./util');
const { sendEmail } = require('./mail');

const STATUS_LABELS = {
  pending: 'Order received', confirmed: 'Confirmed', processing: 'Processing',
  shipped: 'Shipped', delivered: 'Delivered', cancelled: 'Cancelled',
};
const PAYMENT_LABELS = {
  unpaid: 'Unpaid', awaiting_verification: 'Awaiting verification', paid: 'Paid', refunded: 'Refunded', failed: 'Failed',
};
const ALLOWED_TRANSITIONS = {
  pending: ['confirmed', 'processing', 'cancelled'],
  confirmed: ['processing', 'shipped', 'cancelled'],
  processing: ['shipped', 'cancelled'],
  shipped: ['delivered', 'cancelled'],
  delivered: [],
  cancelled: [],
};

const fmt = (n) => 'Rs ' + Number(n).toLocaleString('en-PK');

function newOrderNumber() {
  const d = new Date();
  const ymd = `${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let i = 0; i < 10; i++) {
    let s = '';
    for (const b of crypto.randomBytes(5)) s += alphabet[b % alphabet.length];
    const num = `TQ-${ymd}-${s}`;
    if (!get('SELECT 1 FROM orders WHERE order_number = ?', num)) return num;
  }
  throw new Error('Could not allocate order number');
}

function validateCustomer(body) {
  return {
    full_name: str(body.full_name, { field: 'Full name', required: true, max: 120, min: 2 }),
    phone: pkPhone(body.phone, { required: true }),
    whatsapp: pkPhone(body.whatsapp, { field: 'WhatsApp number' }),
    email: email(body.email),
    address: str(body.address, { field: 'Delivery address', required: true, max: 500, min: 8 }),
    city: str(body.city, { field: 'City', required: true, max: 80 }),
    area: str(body.area, { field: 'Area', max: 120 }),
    postal_code: str(body.postal_code, { field: 'Postal code', max: 10 }),
    notes: str(body.notes, { field: 'Order notes', max: 1000 }),
  };
}

function placeOrder({ cart, user, body }) {
  const customer = validateCustomer(body);
  const zoneId = int(body.zone_id, { field: 'Delivery area', min: 1 });
  const method = str(body.payment_method, { field: 'Payment method', required: true, max: 40 });
  const payments = getSetting('payments', {});
  if (!payments[method]?.enabled) throw bad('Please choose an available payment method.');

  return tx(() => {
    run('UPDATE carts SET zone_id = ? WHERE id = ?', zoneId, cart.id);
    const view = buildCart(get('SELECT * FROM carts WHERE id = ?', cart.id));
    if (!view.items.length) throw bad('Your cart is empty.');
    if (view.issues.length) throw new HttpError(409, 'Some items in your cart need attention before checkout.', { issues: view.issues });
    if (view.zone_id == null) throw bad('Delivery is not available for the selected area.');
    const zone = get('SELECT * FROM delivery_zones WHERE id = ?', view.zone_id);
    if (method === 'cod' && !zone.cod_available) throw bad(`Cash on Delivery is not available for ${zone.name}.`);
    if (view.coupon_error) throw bad(view.coupon_error);

    // Atomically reserve stock: the WHERE clause guarantees we never oversell.
    const lines = [];
    for (const it of view.items) {
      const p = get('SELECT * FROM products WHERE id = ?', it.product.id);
      const isPre = p.availability === 'preorder';
      if (!isPre) {
        const r = run(`UPDATE products SET stock = stock - ?, updated_at = datetime('now') WHERE id = ? AND stock >= ?`, it.qty, p.id, it.qty);
        if (r.changes !== 1) throw new HttpError(409, `Sorry, ${p.name} just went out of stock.`);
      }
      lines.push({ it, p, isPre });
    }
    if (view.coupon) {
      const r = run(`UPDATE coupons SET used_count = used_count + 1 WHERE code = ? AND active = 1
        AND (usage_limit IS NULL OR used_count < usage_limit)`, view.coupon.code);
      if (r.changes !== 1) throw bad('This discount code is no longer available.');
    }

    const orderNumber = newOrderNumber();
    const accessToken = randomToken(24);
    const o = run(`INSERT INTO orders(order_number, access_token_hash, user_id, full_name, phone, whatsapp, email, address, city, area, postal_code, notes,
        zone_id, zone_name, subtotal, discount, delivery_fee, total, coupon_code, payment_method)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      orderNumber, sha256(accessToken), user?.id ?? null, customer.full_name, customer.phone, customer.whatsapp || null, customer.email || null,
      customer.address, customer.city, customer.area || null, customer.postal_code || null, customer.notes || null,
      zone.id, zone.name, view.subtotal, view.discount, view.delivery_fee, view.total, view.coupon?.code ?? null, method);
    const orderId = Number(o.lastInsertRowid);
    for (const { it, p, isPre } of lines) {
      run(`INSERT INTO order_items(order_id, product_id, sku, name, color, image, unit_price, qty, is_preorder, stock_deducted)
        VALUES (?,?,?,?,?,?,?,?,?,?)`, orderId, p.id, p.sku, p.name, it.color || null, it.product.image, it.product.price, it.qty, isPre ? 1 : 0, isPre ? 0 : 1);
    }
    run(`INSERT INTO order_events(order_id, type, message) VALUES (?, 'created', ?)`, orderId, 'Order placed.');
    run('DELETE FROM cart_items WHERE cart_id = ?', cart.id);
    run('UPDATE carts SET coupon_code = NULL WHERE id = ?', cart.id);
    return { orderId, orderNumber, accessToken };
  });
}

function orderSummaryText(order, items) {
  const lines = items.map((i) => `- ${i.name}${i.color ? ` (${i.color})` : ''} × ${i.qty} — ${fmt(i.unit_price * i.qty)}${i.is_preorder ? ' [Pre-order]' : ''}`);
  return [
    `Order number: ${order.order_number}`,
    ...lines,
    `Subtotal: ${fmt(order.subtotal)}`,
    order.discount ? `Discount${order.coupon_code ? ` (${order.coupon_code})` : ''}: -${fmt(order.discount)}` : null,
    `Delivery (${order.zone_name}): ${order.delivery_fee ? fmt(order.delivery_fee) : 'Free'}`,
    `Total: ${fmt(order.total)}`,
  ].filter(Boolean).join('\n');
}

async function notifyOrderPlaced(orderId) {
  const order = get('SELECT * FROM orders WHERE id = ?', orderId);
  const items = all('SELECT * FROM order_items WHERE order_id = ?', orderId);
  const payments = getSetting('payments', {});
  const pm = payments[order.payment_method] || {};
  const site = process.env.PUBLIC_URL || '';
  const summary = orderSummaryText(order, items);
  if (order.email) {
    await sendEmail(order.email, `Your TEQNEST order ${order.order_number}`,
      `Hi ${order.full_name},\n\nThank you for your order. We have received it and will contact you to confirm.\n\n${summary}\n\nPayment method: ${pm.label || order.payment_method}\n${pm.instructions && order.payment_method !== 'cod' ? `\nPayment instructions:\n${pm.instructions}\n` : ''}\nTrack your order: ${site}/track?order=${order.order_number}\n\n— TEQNEST`);
  }
  const contact = getSetting('contact', {});
  const adminEmail = process.env.ORDER_NOTIFY_EMAIL || contact.order_notification_email;
  if (adminEmail) {
    await sendEmail(adminEmail, `New order ${order.order_number} — ${fmt(order.total)}`,
      `${summary}\n\nCustomer: ${order.full_name}, ${order.phone}\nCity: ${order.city}${order.area ? ', ' + order.area : ''}\nPayment: ${order.payment_method}\n\nOpen admin: ${site}/admin#/orders/${order.id}`);
  }
}

/** Customer-safe view of an order (no admin notes, no hashes). */
function orderView(order, { includeAddress = true } = {}) {
  const items = all('SELECT id, product_id, sku, name, color, image, unit_price, qty, is_preorder FROM order_items WHERE order_id = ?', order.id);
  const events = all('SELECT type, message, created_at FROM order_events WHERE order_id = ? AND visible_to_customer = 1 ORDER BY id', order.id);
  const payments = getSetting('payments', {});
  const pm = payments[order.payment_method] || {};
  const reviewed = order.user_id ? new Set(all('SELECT product_id FROM reviews WHERE user_id = ?', order.user_id).map((r) => r.product_id)) : new Set();
  const v = {
    order_number: order.order_number, created_at: order.created_at,
    status: order.status, status_label: STATUS_LABELS[order.status],
    payment_method: order.payment_method, payment_method_label: pm.label || order.payment_method,
    payment_instructions: order.payment_method !== 'cod' ? (pm.instructions || '') : '',
    payment_status: order.payment_status, payment_status_label: PAYMENT_LABELS[order.payment_status],
    payment_reference_submitted: !!order.payment_reference,
    subtotal: order.subtotal, discount: order.discount, delivery_fee: order.delivery_fee, total: order.total,
    coupon_code: order.coupon_code, zone_name: order.zone_name, city: order.city,
    tracking: order.tracking_number ? { carrier: order.tracking_carrier, number: order.tracking_number, url: order.tracking_url } : null,
    items: items.map((i) => ({ ...i, reviewed: reviewed.has(i.product_id) })), events,
  };
  if (includeAddress) Object.assign(v, {
    full_name: order.full_name, phone: order.phone, whatsapp: order.whatsapp, email: order.email,
    address: order.address, area: order.area, postal_code: order.postal_code, notes: order.notes,
  });
  return v;
}

/** Applies a status change with stock restoration on cancel. */
function changeStatus(orderId, next, actorId, note) {
  return tx(() => {
    const o = get('SELECT * FROM orders WHERE id = ?', orderId);
    if (!o) throw new HttpError(404, 'Order not found.');
    if (o.status === next) return o;
    if (!ALLOWED_TRANSITIONS[o.status]?.includes(next)) throw bad(`Cannot change status from ${o.status} to ${next}.`);
    if (next === 'cancelled') {
      for (const it of all('SELECT * FROM order_items WHERE order_id = ? AND stock_deducted = 1', orderId)) {
        if (it.product_id) run(`UPDATE products SET stock = stock + ?, updated_at = datetime('now') WHERE id = ?`, it.qty, it.product_id);
        run('UPDATE order_items SET stock_deducted = 0 WHERE id = ?', it.id);
      }
      if (o.coupon_code) run('UPDATE coupons SET used_count = MAX(0, used_count - 1) WHERE code = ?', o.coupon_code);
    }
    run(`UPDATE orders SET status = ?, updated_at = datetime('now') WHERE id = ?`, next, orderId);
    run(`INSERT INTO order_events(order_id, type, message, actor_id) VALUES (?,?,?,?)`, orderId, next, note || STATUS_LABELS[next], actorId ?? null);
    return get('SELECT * FROM orders WHERE id = ?', orderId);
  });
}

module.exports = { placeOrder, notifyOrderPlaced, orderView, changeStatus, orderSummaryText, STATUS_LABELS, PAYMENT_LABELS, ALLOWED_TRANSITIONS };
