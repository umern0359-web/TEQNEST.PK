'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const { get, all, run } = require('../db');
const { findCart, buildCart, addItem } = require('../cart');
const { placeOrder, notifyOrderPlaced, orderView } = require('../orders');
const { serializeProduct, PRODUCT_SELECT, publicSettings, HttpError, bad, str, int, email, pkPhone, sha256, evaluateCoupon } = require('../util');

const r = express.Router();
const limiter = (max, windowMs = 15 * 60e3) => rateLimit({ windowMs, limit: max, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many requests, please try again later.' } });

// ---------- site config ----------
r.get('/settings', (_req, res) => res.json(publicSettings()));

r.get('/categories', (_req, res) => {
  const rows = all(`SELECT c.id, c.slug, c.name, c.short_name, c.description, c.image, c.show_on_home, c.show_in_nav,
    (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.active = 1) AS product_count
    FROM categories c WHERE c.active = 1 ORDER BY c.sort, c.id`);
  res.json(rows.map((c) => ({ ...c, show_on_home: !!c.show_on_home, show_in_nav: !!c.show_in_nav })));
});

// ---------- catalog ----------
const SORTS = {
  newest: 'p.created_at DESC, p.id DESC',
  price_asc: 'COALESCE(CASE WHEN p.sale_price > 0 AND p.sale_price < p.price THEN p.sale_price END, p.price) ASC NULLS LAST',
  price_desc: 'COALESCE(CASE WHEN p.sale_price > 0 AND p.sale_price < p.price THEN p.sale_price END, p.price) DESC NULLS LAST',
  name: 'p.name COLLATE NOCASE ASC',
  featured: 'p.featured DESC, p.trending DESC, p.created_at DESC',
  popular: '(SELECT COALESCE(SUM(oi.qty),0) FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = p.id AND o.status != \'cancelled\') DESC, p.featured DESC',
};

function escapeLike(s) { return s.replace(/[\\%_]/g, (m) => '\\' + m); }

r.get('/products', (req, res) => {
  const q = req.query;
  const where = ['p.active = 1'];
  const params = [];
  if (q.category) { where.push('c.slug = ?'); params.push(String(q.category)); }
  if (q.q) {
    const term = `%${escapeLike(String(q.q).slice(0, 80))}%`;
    where.push(`(p.name LIKE ? ESCAPE '\\' OR p.short_description LIKE ? ESCAPE '\\' OR p.sku LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\')`);
    params.push(term, term, term, term);
  }
  if (q.featured) where.push('p.featured = 1');
  if (q.new) where.push('p.new_arrival = 1');
  if (q.trending) where.push('p.trending = 1');
  if (q.on_sale) where.push('p.sale_price > 0 AND p.sale_price < p.price');
  const priceExpr = 'COALESCE(CASE WHEN p.sale_price > 0 AND p.sale_price < p.price THEN p.sale_price END, p.price)';
  if (q.min) { where.push(`${priceExpr} >= ?`); params.push(Number(q.min) || 0); }
  if (q.max) { where.push(`${priceExpr} <= ?`); params.push(Number(q.max) || 0); }
  if (q.availability) {
    const av = String(q.availability).split(',').filter((a) => ['in_stock', 'out_of_stock', 'coming_soon', 'on_request', 'preorder'].includes(a));
    if (av.length) {
      const parts = [];
      for (const a of av) {
        if (a === 'in_stock') parts.push(`(p.availability = 'in_stock' AND p.stock > 0)`);
        else if (a === 'out_of_stock') parts.push(`(p.availability = 'out_of_stock' OR (p.availability = 'in_stock' AND p.stock <= 0))`);
        else { parts.push('p.availability = ?'); params.push(a); }
      }
      where.push(`(${parts.join(' OR ')})`);
    }
  }
  if (q.exclude) { where.push('p.id != ?'); params.push(Number(q.exclude) || 0); }
  if (q.ids) {
    const ids = String(q.ids).split(',').map(Number).filter(Number.isInteger).slice(0, 50);
    if (!ids.length) return res.json({ products: [], total: 0, page: 1, pages: 0 });
    where.push(`p.id IN (${ids.map(() => '?').join(',')})`); params.push(...ids);
  }
  const sort = SORTS[q.sort] || SORTS.featured;
  const limit = Math.min(48, Math.max(1, Number(q.limit) || 24));
  const page = Math.max(1, Number(q.page) || 1);
  const whereSql = where.join(' AND ');
  const total = get(`SELECT COUNT(*) n FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ${whereSql}`, ...params).n;
  const rows = all(`${PRODUCT_SELECT} WHERE ${whereSql} ORDER BY ${sort} LIMIT ? OFFSET ?`, ...params, limit, (page - 1) * limit);
  const range = get(`SELECT MIN(${priceExpr}) lo, MAX(${priceExpr}) hi FROM products p WHERE p.active = 1 AND p.price IS NOT NULL`);
  res.json({ products: rows.map((p) => serializeProduct(p)), total, page, pages: Math.ceil(total / limit), price_range: range });
});

r.get('/search/suggest', (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 80);
  if (q.length < 2) return res.json({ products: [], categories: [] });
  const term = `%${escapeLike(q)}%`;
  const products = all(`${PRODUCT_SELECT} WHERE p.active = 1 AND (p.name LIKE ? ESCAPE '\\' OR p.sku LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\')
    ORDER BY (p.name LIKE ? ESCAPE '\\') DESC, p.featured DESC LIMIT 6`, term, term, term, `${escapeLike(q)}%`).map((p) => serializeProduct(p));
  const categories = all(`SELECT slug, name FROM categories WHERE active = 1 AND name LIKE ? ESCAPE '\\' LIMIT 3`, term);
  res.json({ products, categories });
});

r.get('/products/:slug', (req, res) => {
  const p = get(PRODUCT_SELECT + ' WHERE p.slug = ? AND p.active = 1', req.params.slug);
  if (!p) throw new HttpError(404, 'Product not found.');
  const out = serializeProduct(p, { full: true });
  out.wishlisted = req.user ? !!get('SELECT 1 FROM wishlists WHERE user_id = ? AND product_id = ?', req.user.id, p.id) : false;
  // review eligibility: customer has a delivered order containing this product and has not reviewed it
  out.can_review = false;
  if (req.user) {
    const eligible = get(`SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id = o.id
      WHERE o.user_id = ? AND oi.product_id = ? AND o.status = 'delivered' LIMIT 1`, req.user.id, p.id);
    out.can_review = !!eligible && !get('SELECT 1 FROM reviews WHERE user_id = ? AND product_id = ?', req.user.id, p.id);
  }
  res.json(out);
});

r.get('/products/:slug/reviews', (req, res) => {
  const p = get('SELECT id FROM products WHERE slug = ? AND active = 1', req.params.slug);
  if (!p) throw new HttpError(404, 'Product not found.');
  const reviews = all(`SELECT r.id, r.rating, r.title, r.body, r.created_at, u.name FROM reviews r JOIN users u ON u.id = r.user_id
    WHERE r.product_id = ? AND r.status = 'approved' ORDER BY r.created_at DESC LIMIT 50`, p.id);
  res.json(reviews.map((rv) => ({ ...rv, name: shortName(rv.name), verified: true })));
});

/** Homepage review wall: only approved reviews from verified purchases (all reviews require a delivered order). */
r.get('/reviews/featured', (_req, res) => {
  const reviews = all(`SELECT r.id, r.rating, r.title, r.body, r.created_at, u.name, p.name AS product_name, p.slug AS product_slug
    FROM reviews r JOIN users u ON u.id = r.user_id JOIN products p ON p.id = r.product_id
    WHERE r.status = 'approved' ORDER BY r.rating DESC, r.created_at DESC LIMIT 9`);
  res.json(reviews.map((rv) => ({ ...rv, name: shortName(rv.name), verified: true })));
});
const shortName = (n) => { const [a, b] = String(n).split(/\s+/); return b ? `${a} ${b[0]}.` : a; };

// ---------- newsletter ----------
r.post('/newsletter', limiter(10), (req, res) => {
  const e = email(req.body.email, { required: true });
  run('INSERT INTO subscribers(email) VALUES (?) ON CONFLICT(email) DO NOTHING', e);
  res.json({ ok: true, message: "You're subscribed. Welcome to TEQNEST." });
});

// ---------- cart ----------
r.get('/cart', (req, res) => res.json(buildCart(findCart(req, res))));

r.post('/cart/items', limiter(200), (req, res) => {
  const cart = findCart(req, res, { create: true });
  addItem(cart, int(req.body.product_id, { field: 'Product', min: 1 }), int(req.body.qty ?? 1, { field: 'Quantity', min: 1, max: 10 }), String(req.body.color || '').slice(0, 40));
  res.json(buildCart(get('SELECT * FROM carts WHERE id = ?', cart.id)));
});

r.patch('/cart/items/:lineId', (req, res) => {
  const cart = findCart(req, res);
  if (!cart) throw new HttpError(404, 'Cart not found.');
  const line = get(`SELECT ci.*, p.stock, p.availability FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.id = ? AND ci.cart_id = ?`, Number(req.params.lineId), cart.id);
  if (!line) throw new HttpError(404, 'Item not found.');
  const qty = int(req.body.qty, { field: 'Quantity', min: 0, max: 10 });
  if (qty === 0) run('DELETE FROM cart_items WHERE id = ?', line.id);
  else {
    if (line.availability !== 'preorder' && qty > line.stock) throw new HttpError(409, line.stock > 0 ? `Only ${line.stock} left in stock.` : 'This item is out of stock.');
    run('UPDATE cart_items SET qty = ? WHERE id = ?', qty, line.id);
  }
  res.json(buildCart(cart));
});

r.delete('/cart/items/:lineId', (req, res) => {
  const cart = findCart(req, res);
  if (cart) run('DELETE FROM cart_items WHERE id = ? AND cart_id = ?', Number(req.params.lineId), cart.id);
  res.json(buildCart(cart));
});

r.post('/cart/coupon', limiter(30), (req, res) => {
  const cart = findCart(req, res, { create: true });
  const code = str(req.body.code, { field: 'Discount code', max: 40 }).toUpperCase();
  if (!code) { run('UPDATE carts SET coupon_code = NULL WHERE id = ?', cart.id); return res.json(buildCart(cart)); }
  const view = buildCart(cart);
  const ev = evaluateCoupon(code, view.subtotal);
  if (ev.error) throw bad(ev.error);
  run('UPDATE carts SET coupon_code = ? WHERE id = ?', code, cart.id);
  res.json(buildCart(get('SELECT * FROM carts WHERE id = ?', cart.id)));
});

r.post('/cart/zone', (req, res) => {
  const cart = findCart(req, res, { create: true });
  const z = int(req.body.zone_id, { field: 'Delivery area', min: 1, nullable: true });
  run('UPDATE carts SET zone_id = ? WHERE id = ?', z, cart.id);
  res.json(buildCart(get('SELECT * FROM carts WHERE id = ?', cart.id)));
});

// ---------- checkout ----------
r.post('/checkout', limiter(20), async (req, res) => {
  const cart = findCart(req, res);
  if (!cart) throw bad('Your cart is empty.');
  const { orderId, orderNumber, accessToken } = placeOrder({ cart, user: req.user, body: req.body || {} });
  if (req.user && req.body.save_address) {
    const has = get('SELECT 1 FROM addresses WHERE user_id = ?', req.user.id);
    const b = req.body;
    try {
      run(`INSERT INTO addresses(user_id, label, full_name, phone, whatsapp, address, city, area, postal_code, zone_id, is_default) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
        req.user.id, 'Home', String(b.full_name).trim(), pkPhone(b.phone), pkPhone(b.whatsapp) || null, String(b.address).trim(), String(b.city).trim(),
        String(b.area || '').trim() || null, String(b.postal_code || '').trim() || null, Number(b.zone_id) || null, has ? 0 : 1);
    } catch { /* address save is best-effort */ }
  }
  notifyOrderPlaced(orderId).catch((e) => console.error('notify failed', e));
  res.status(201).json({ order_number: orderNumber, access_token: accessToken });
});

/** Order lookup for the confirmation page: requires the secret access token issued at checkout, or ownership. */
function loadAuthorisedOrder(req) {
  const o = get('SELECT * FROM orders WHERE order_number = ?', String(req.params.number));
  if (!o) throw new HttpError(404, 'Order not found.');
  const token = String(req.query.t || req.body?.t || '');
  const owns = req.user && o.user_id === req.user.id;
  if (!owns && !(token && sha256(token) === o.access_token_hash)) throw new HttpError(404, 'Order not found.');
  return o;
}
r.get('/orders/:number', (req, res) => res.json(orderView(loadAuthorisedOrder(req))));

/** Customer submits a bank/wallet transfer reference for manual admin verification. */
r.post('/orders/:number/payment-reference', limiter(10), (req, res) => {
  const o = loadAuthorisedOrder(req);
  if (o.payment_method === 'cod') throw bad('This order is Cash on Delivery.');
  if (['paid', 'refunded'].includes(o.payment_status) || o.status === 'cancelled') throw bad('This order cannot accept a payment reference.');
  const ref = str(req.body.reference, { field: 'Transaction ID / reference', required: true, max: 120, min: 4 });
  run(`UPDATE orders SET payment_reference = ?, payment_status = 'awaiting_verification', updated_at = datetime('now') WHERE id = ?`, ref, o.id);
  run(`INSERT INTO order_events(order_id, type, message) VALUES (?, 'payment_submitted', 'Payment reference submitted — awaiting verification.')`, o.id);
  res.json(orderView(get('SELECT * FROM orders WHERE id = ?', o.id)));
});

/** Public tracking by order number + phone. Exposes status only, not address/contact details. */
r.post('/track', limiter(30), (req, res) => {
  const number = str(req.body.order_number, { field: 'Order number', required: true, max: 30 }).toUpperCase();
  const phone = pkPhone(req.body.phone, { required: true });
  const o = get('SELECT * FROM orders WHERE order_number = ? AND phone = ?', number, phone);
  if (!o) throw new HttpError(404, 'No order matches that order number and mobile number.');
  res.json(orderView(o, { includeAddress: false }));
});

module.exports = r;
