'use strict';
const express = require('express');
const rateLimit = require('express-rate-limit');
const { get, all, run, tx } = require('../db');
const auth = require('../auth');
const { mergeGuestCart } = require('../cart');
const { orderView } = require('../orders');
const { sendEmail } = require('../mail');
const { HttpError, bad, str, int, email, pkPhone, bool, randomToken, sha256, serializeProduct, PRODUCT_SELECT } = require('../util');

const r = express.Router();
const DUMMY_HASH = require('bcryptjs').hashSync('not-a-real-password', 12);
const authLimiter = rateLimit({ windowMs: 15 * 60e3, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many attempts. Please wait a few minutes and try again.' } });

function password(v) {
  v = typeof v === 'string' ? v : '';
  if (v.length < 8) throw bad('Password must be at least 8 characters.');
  if (v.length > 128) throw bad('Password is too long.');
  if (!/[A-Za-z]/.test(v) || !/\d/.test(v)) throw bad('Password must contain letters and numbers.');
  return v;
}

r.get('/me', (req, res) => res.json({ user: req.user }));

r.post('/register', authLimiter, async (req, res) => {
  const name = str(req.body.name, { field: 'Name', required: true, max: 100, min: 2 });
  const em = email(req.body.email, { required: true });
  const phone = pkPhone(req.body.phone);
  const pw = password(req.body.password);
  if (get('SELECT 1 FROM users WHERE email = ?', em)) throw bad('An account with this email already exists. Try logging in.');
  const hash = await auth.hashPassword(pw);
  const u = run('INSERT INTO users(email, password_hash, name, phone) VALUES (?,?,?,?)', em, hash, name, phone || null);
  const userId = Number(u.lastInsertRowid);
  // Link earlier guest orders placed with the same email so they appear in order history
  run('UPDATE orders SET user_id = ? WHERE user_id IS NULL AND email = ?', userId, em);
  auth.createSession(res, userId);
  mergeGuestCart(req, res, userId);
  res.status(201).json({ user: get('SELECT id, email, name, phone, role FROM users WHERE id = ?', userId) });
});

r.post('/login', authLimiter, async (req, res) => {
  const em = email(req.body.email, { required: true });
  const pw = typeof req.body.password === 'string' ? req.body.password : '';
  const u = get('SELECT * FROM users WHERE email = ?', em);
  // Constant-ish time: always run bcrypt
  const ok = await auth.verifyPassword(pw, u?.password_hash || DUMMY_HASH);
  if (!u || !ok || !u.active) throw new HttpError(401, 'Incorrect email or password.');
  auth.createSession(res, u.id);
  mergeGuestCart(req, res, u.id);
  res.json({ user: { id: u.id, email: u.email, name: u.name, phone: u.phone, role: u.role } });
});

r.post('/logout', (req, res) => { auth.destroySession(req, res); res.json({ ok: true }); });

r.post('/password/forgot', authLimiter, async (req, res) => {
  const em = email(req.body.email, { required: true });
  const u = get('SELECT id, name FROM users WHERE email = ? AND active = 1', em);
  if (u) {
    const token = randomToken();
    run('INSERT INTO password_resets(token_hash, user_id, expires_at) VALUES (?,?,?)', sha256(token), u.id, new Date(Date.now() + 60 * 60e3).toISOString());
    const base = process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
    await sendEmail(em, 'Reset your TEQNEST password',
      `Hi ${u.name},\n\nUse the link below to reset your password. It expires in 1 hour.\n\n${base}/account/reset?token=${token}\n\nIf you did not request this, you can ignore this email.\n\n— TEQNEST`);
  }
  // Same response either way so emails can't be enumerated
  res.json({ ok: true, message: 'If an account exists for that email, a reset link has been sent.' });
});

r.post('/password/reset', authLimiter, async (req, res) => {
  const token = str(req.body.token, { field: 'Token', required: true, max: 200 });
  const pw = password(req.body.password);
  const row = get('SELECT * FROM password_resets WHERE token_hash = ?', sha256(token));
  if (!row || row.used || new Date(row.expires_at) < new Date()) throw bad('This reset link is invalid or has expired.');
  const hash = await auth.hashPassword(pw);
  tx(() => {
    run('UPDATE users SET password_hash = ? WHERE id = ?', hash, row.user_id);
    run('UPDATE password_resets SET used = 1 WHERE token_hash = ?', row.token_hash);
    run('DELETE FROM sessions WHERE user_id = ?', row.user_id);
  });
  res.json({ ok: true, message: 'Password updated. Please log in.' });
});

// ---------- everything below requires login ----------
r.use(auth.requireUser);

r.patch('/profile', (req, res) => {
  const name = str(req.body.name, { field: 'Name', required: true, max: 100, min: 2 });
  const phone = pkPhone(req.body.phone);
  run('UPDATE users SET name = ?, phone = ? WHERE id = ?', name, phone || null, req.user.id);
  res.json({ user: get('SELECT id, email, name, phone, role FROM users WHERE id = ?', req.user.id) });
});

r.post('/password/change', authLimiter, async (req, res) => {
  const u = get('SELECT password_hash FROM users WHERE id = ?', req.user.id);
  if (!(await auth.verifyPassword(String(req.body.current_password || ''), u.password_hash))) throw bad('Current password is incorrect.');
  const hash = await auth.hashPassword(password(req.body.new_password));
  run('UPDATE users SET password_hash = ? WHERE id = ?', hash, req.user.id);
  run('DELETE FROM sessions WHERE user_id = ?', req.user.id);
  auth.createSession(res, req.user.id);
  res.json({ ok: true, message: 'Password changed.' });
});

// addresses
function addressBody(b) {
  return {
    label: str(b.label, { field: 'Label', max: 40 }) || 'Address',
    full_name: str(b.full_name, { field: 'Full name', required: true, max: 120 }),
    phone: pkPhone(b.phone, { required: true }),
    whatsapp: pkPhone(b.whatsapp, { field: 'WhatsApp number' }) || null,
    address: str(b.address, { field: 'Address', required: true, max: 500, min: 8 }),
    city: str(b.city, { field: 'City', required: true, max: 80 }),
    area: str(b.area, { field: 'Area', max: 120 }) || null,
    postal_code: str(b.postal_code, { field: 'Postal code', max: 10 }) || null,
    zone_id: int(b.zone_id, { field: 'Delivery zone', min: 1, nullable: true }),
    is_default: bool(b.is_default),
  };
}
r.get('/addresses', (req, res) => res.json(all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id', req.user.id)));
r.post('/addresses', (req, res) => {
  const a = addressBody(req.body);
  if (get('SELECT COUNT(*) n FROM addresses WHERE user_id = ?', req.user.id).n >= 10) throw bad('You can save up to 10 addresses.');
  tx(() => {
    if (a.is_default || !get('SELECT 1 FROM addresses WHERE user_id = ?', req.user.id)) { a.is_default = 1; run('UPDATE addresses SET is_default = 0 WHERE user_id = ?', req.user.id); }
    run(`INSERT INTO addresses(user_id, label, full_name, phone, whatsapp, address, city, area, postal_code, zone_id, is_default) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      req.user.id, a.label, a.full_name, a.phone, a.whatsapp, a.address, a.city, a.area, a.postal_code, a.zone_id, a.is_default);
  });
  res.status(201).json(all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id', req.user.id));
});
r.put('/addresses/:id', (req, res) => {
  const a = addressBody(req.body);
  const id = Number(req.params.id);
  if (!get('SELECT 1 FROM addresses WHERE id = ? AND user_id = ?', id, req.user.id)) throw new HttpError(404, 'Address not found.');
  tx(() => {
    if (a.is_default) run('UPDATE addresses SET is_default = 0 WHERE user_id = ?', req.user.id);
    run(`UPDATE addresses SET label=?, full_name=?, phone=?, whatsapp=?, address=?, city=?, area=?, postal_code=?, zone_id=?, is_default=? WHERE id = ? AND user_id = ?`,
      a.label, a.full_name, a.phone, a.whatsapp, a.address, a.city, a.area, a.postal_code, a.zone_id, a.is_default, id, req.user.id);
  });
  res.json(all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id', req.user.id));
});
r.delete('/addresses/:id', (req, res) => {
  run('DELETE FROM addresses WHERE id = ? AND user_id = ?', Number(req.params.id), req.user.id);
  res.json(all('SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, id', req.user.id));
});

// orders
r.get('/orders', (req, res) => {
  const rows = all(`SELECT o.order_number, o.created_at, o.status, o.payment_status, o.total,
    (SELECT SUM(qty) FROM order_items WHERE order_id = o.id) AS item_count
    FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC`, req.user.id);
  res.json(rows);
});
r.get('/orders/:number', (req, res) => {
  const o = get('SELECT * FROM orders WHERE order_number = ? AND user_id = ?', req.params.number, req.user.id);
  if (!o) throw new HttpError(404, 'Order not found.');
  res.json(orderView(o));
});

// wishlist
r.get('/wishlist', (req, res) => {
  const rows = all(`${PRODUCT_SELECT} JOIN wishlists w ON w.product_id = p.id WHERE w.user_id = ? AND p.active = 1 ORDER BY w.created_at DESC`, req.user.id);
  res.json(rows.map((p) => serializeProduct(p)));
});
r.get('/wishlist/ids', (req, res) => res.json(all('SELECT product_id FROM wishlists WHERE user_id = ?', req.user.id).map((x) => x.product_id)));
r.post('/wishlist/:productId', (req, res) => {
  const pid = Number(req.params.productId);
  if (!get('SELECT 1 FROM products WHERE id = ? AND active = 1', pid)) throw new HttpError(404, 'Product not found.');
  run('INSERT INTO wishlists(user_id, product_id) VALUES (?,?) ON CONFLICT DO NOTHING', req.user.id, pid);
  res.json({ ok: true });
});
r.delete('/wishlist/:productId', (req, res) => {
  run('DELETE FROM wishlists WHERE user_id = ? AND product_id = ?', req.user.id, Number(req.params.productId));
  res.json({ ok: true });
});

// reviews — only for products in the customer's own delivered orders
r.post('/reviews', rateLimit({ windowMs: 60 * 60e3, limit: 20 }), (req, res) => {
  const productId = int(req.body.product_id, { field: 'Product', min: 1 });
  const rating = int(req.body.rating, { field: 'Rating', min: 1, max: 5 });
  const title = str(req.body.title, { field: 'Title', max: 120 });
  const body = str(req.body.body, { field: 'Review', required: true, max: 2000, min: 10 });
  const order = get(`SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id = o.id
    WHERE o.user_id = ? AND oi.product_id = ? AND o.status = 'delivered' ORDER BY o.id DESC LIMIT 1`, req.user.id, productId);
  if (!order) throw new HttpError(403, 'You can review products from your delivered orders.');
  if (get('SELECT 1 FROM reviews WHERE user_id = ? AND product_id = ?', req.user.id, productId)) throw bad('You have already reviewed this product.');
  run('INSERT INTO reviews(product_id, user_id, order_id, rating, title, body) VALUES (?,?,?,?,?,?)', productId, req.user.id, order.id, rating, title || null, body);
  res.status(201).json({ ok: true, message: 'Thanks! Your review will appear once it has been approved.' });
});

module.exports = r;
