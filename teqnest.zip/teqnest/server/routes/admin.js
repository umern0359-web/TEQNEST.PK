'use strict';
const express = require('express');
const path = require('node:path');
const fs = require('node:fs');
const multer = require('multer');
const { get, all, run, tx, getSetting, setSetting, DATA_DIR } = require('../db');
const { requireRole, hashPassword } = require('../auth');
const { changeStatus, orderView, STATUS_LABELS, PAYMENT_LABELS, ALLOWED_TRANSITIONS } = require('../orders');
const { sendEmail } = require('../mail');
const U = require('../util');
const { HttpError, bad, str, int, bool, email, slugify, strList, specList, serializeProduct, PRODUCT_SELECT, parseJSON, audit, randomToken } = U;

const r = express.Router();
r.use(requireRole('staff'));
const adminOnly = requireRole('admin');

// ---------- uploads ----------
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const KINDS = {
  image: { exts: ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif', '.svg'], max: 8 << 20 },
  video: { exts: ['.mp4', '.webm'], max: 60 << 20 },
  model: { exts: ['.glb'], max: 30 << 20 },
};
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_req, file, cb) => cb(null, `${Date.now().toString(36)}-${randomToken(6)}${path.extname(file.originalname).toLowerCase()}`),
  }),
  limits: { fileSize: 60 << 20, files: 12 },
  fileFilter: (req, file, cb) => {
    const kind = KINDS[req.params.kind];
    const ext = path.extname(file.originalname).toLowerCase();
    if (!kind || !kind.exts.includes(ext)) return cb(new HttpError(400, `Unsupported file type ${ext || ''}.`));
    cb(null, true);
  },
});
function sniff(file, kind) {
  const fd = fs.openSync(file.path, 'r'); const b = Buffer.alloc(16); fs.readSync(fd, b, 0, 16, 0); fs.closeSync(fd);
  const hex = b.toString('hex');
  if (kind === 'image') {
    if (path.extname(file.path) === '.svg') {
      const txt = fs.readFileSync(file.path, 'utf8');
      // SVG can carry script: refuse anything active
      return /<svg[\s>]/i.test(txt) && !/<script|on\w+\s*=|javascript:|<foreignObject/i.test(txt);
    }
    return hex.startsWith('ffd8ff') || hex.startsWith('89504e47') || hex.startsWith('47494638') ||
      (hex.startsWith('52494646') && b.subarray(8, 12).toString() === 'WEBP') || b.subarray(4, 12).toString().startsWith('ftypavi');
  }
  if (kind === 'video') return b.subarray(4, 8).toString() === 'ftyp' || hex.startsWith('1a45dfa3');
  if (kind === 'model') return b.subarray(0, 4).toString() === 'glTF';
  return false;
}
r.post('/upload/:kind', upload.array('files', 12), (req, res) => {
  const kind = req.params.kind;
  const out = [];
  for (const f of req.files || []) {
    if (f.size > KINDS[kind].max || !sniff(f, kind)) {
      fs.unlinkSync(f.path);
      throw bad(`${f.originalname} is not a valid ${kind} file or is too large.`);
    }
    out.push(`/uploads/${path.basename(f.path)}`);
  }
  audit(req.user.id, 'upload', kind, null, { files: out });
  res.json({ urls: out });
});

// ---------- dashboard ----------
r.get('/dashboard', (req, res) => {
  const days = Math.min(365, Math.max(7, Number(req.query.days) || 30));
  const sales = get(`SELECT COALESCE(SUM(total),0) revenue, COUNT(*) n FROM orders WHERE status != 'cancelled'`);
  const paid = get(`SELECT COALESCE(SUM(total),0) v FROM orders WHERE payment_status = 'paid' AND status != 'cancelled'`).v;
  const byStatus = Object.fromEntries(all('SELECT status, COUNT(*) n FROM orders GROUP BY status').map((x) => [x.status, x.n]));
  const series = all(`SELECT date(created_at) d, COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total END),0) revenue, COUNT(*) orders
    FROM orders WHERE created_at >= date('now', ?) GROUP BY d ORDER BY d`, `-${days - 1} days`);
  const map = new Map(series.map((s) => [s.d, s]));
  const filled = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
    filled.push(map.get(d) || { d, revenue: 0, orders: 0 });
  }
  res.json({
    total_sales: sales.revenue, paid_revenue: paid, total_orders: get('SELECT COUNT(*) n FROM orders').n,
    pending_orders: byStatus.pending || 0,
    in_progress_orders: (byStatus.confirmed || 0) + (byStatus.processing || 0) + (byStatus.shipped || 0),
    completed_orders: byStatus.delivered || 0, cancelled_orders: byStatus.cancelled || 0,
    awaiting_payment_verification: get(`SELECT COUNT(*) n FROM orders WHERE payment_status = 'awaiting_verification'`).n,
    total_customers: get(`SELECT COUNT(*) n FROM users WHERE role = 'customer'`).n,
    guest_customers: get(`SELECT COUNT(DISTINCT phone) n FROM orders WHERE user_id IS NULL`).n,
    subscribers: get('SELECT COUNT(*) n FROM subscribers').n,
    pending_reviews: get(`SELECT COUNT(*) n FROM reviews WHERE status = 'pending'`).n,
    best_sellers: all(`SELECT oi.product_id, oi.name, SUM(oi.qty) qty, SUM(oi.qty * oi.unit_price) revenue
      FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.status != 'cancelled'
      GROUP BY oi.product_id, oi.name ORDER BY qty DESC LIMIT 8`),
    low_stock: all(`SELECT id, name, sku, stock, low_stock_threshold FROM products
      WHERE active = 1 AND availability = 'in_stock' AND stock <= low_stock_threshold ORDER BY stock ASC LIMIT 15`),
    recent_orders: all('SELECT id, order_number, full_name, total, status, payment_status, created_at FROM orders ORDER BY id DESC LIMIT 8'),
    series: filled, days,
  });
});

// ---------- products ----------
function productBody(b) {
  const name = str(b.name, { field: 'Product name', required: true, max: 160 });
  const availability = String(b.availability || 'in_stock');
  if (!U.AVAILABILITY[availability]) throw bad('Invalid availability status.');
  const price = int(b.price, { field: 'Regular price', min: 0, max: 10_000_000, nullable: true });
  const sale = int(b.sale_price, { field: 'Sale price', min: 0, max: 10_000_000, nullable: true });
  if (sale != null && price != null && sale >= price) throw bad('Sale price must be lower than the regular price.');
  if (sale != null && price == null) throw bad('Set a regular price before a sale price.');
  if (['in_stock', 'preorder'].includes(availability) && price == null) throw bad('Purchasable products need a price.');
  const colors = Array.isArray(b.colors) ? b.colors.filter((c) => c && c.name).slice(0, 20).map((c) => ({
    name: String(c.name).trim().slice(0, 40), hex: /^#[0-9a-f]{3,8}$/i.test(c.hex || '') ? c.hex : '#888888',
  })) : [];
  const urls = (v) => strList(v, 'urls', 20, 500).filter((u) => /^(\/uploads\/|\/img\/|https:\/\/)/.test(u));
  return {
    name, sku: str(b.sku, { field: 'SKU', required: true, max: 60 }).toUpperCase(),
    slug: slugify(b.slug || name) || slugify(name),
    short_description: str(b.short_description, { field: 'Short description', max: 300 }),
    description: str(b.description, { field: 'Description', max: 20000 }),
    category_id: int(b.category_id, { field: 'Category', min: 1, nullable: true }),
    price, sale_price: sale,
    stock: int(b.stock ?? 0, { field: 'Stock', min: 0, max: 1_000_000 }),
    low_stock_threshold: int(b.low_stock_threshold ?? 5, { field: 'Low-stock threshold', min: 0, max: 10000 }),
    availability, featured: bool(b.featured), new_arrival: bool(b.new_arrival), trending: bool(b.trending), active: b.active === undefined ? 1 : bool(b.active),
    colors: JSON.stringify(colors), specs: JSON.stringify(specList(b.specs)),
    features: JSON.stringify(strList(b.features, 'features')), in_box: JSON.stringify(strList(b.in_box, 'in box')),
    images: JSON.stringify(urls(b.images)), videos: JSON.stringify(urls(b.videos)),
    model_url: (() => { const m = str(b.model_url, { field: '3D model', max: 500 }); return m && /^(\/uploads\/|https:\/\/).+\.glb$/i.test(m) ? m : null; })(),
    seo_title: str(b.seo_title, { field: 'SEO title', max: 70 }) || null,
    seo_description: str(b.seo_description, { field: 'SEO description', max: 170 }) || null,
  };
}
const adminProduct = (p) => ({ ...p, colors: parseJSON(p.colors, []), specs: parseJSON(p.specs, []), features: parseJSON(p.features, []), in_box: parseJSON(p.in_box, []), images: parseJSON(p.images, []), videos: parseJSON(p.videos, []), sold: get(`SELECT COALESCE(SUM(oi.qty),0) n FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.product_id = ? AND o.status != 'cancelled'`, p.id).n });

r.get('/products', (req, res) => {
  const where = ['1=1']; const params = [];
  if (req.query.q) { const t = `%${String(req.query.q).slice(0, 80)}%`; where.push('(p.name LIKE ? OR p.sku LIKE ?)'); params.push(t, t); }
  if (req.query.category) { where.push('p.category_id = ?'); params.push(Number(req.query.category)); }
  if (req.query.availability) { where.push('p.availability = ?'); params.push(String(req.query.availability)); }
  if (req.query.low_stock) where.push(`p.availability = 'in_stock' AND p.stock <= p.low_stock_threshold`);
  res.json(all(`${PRODUCT_SELECT} WHERE ${where.join(' AND ')} ORDER BY p.id DESC`, ...params).map(adminProduct));
});
r.get('/products/:id', (req, res) => {
  const p = get('SELECT * FROM products WHERE id = ?', Number(req.params.id));
  if (!p) throw new HttpError(404, 'Product not found.');
  res.json(adminProduct(p));
});
function uniqueCheck(p, id = 0) {
  if (get('SELECT 1 FROM products WHERE sku = ? AND id != ?', p.sku, id)) throw bad('Another product already uses this SKU.');
  let slug = p.slug, i = 2;
  while (get('SELECT 1 FROM products WHERE slug = ? AND id != ?', slug, id)) slug = `${p.slug}-${i++}`;
  p.slug = slug;
}
const PCOLS = ['sku', 'name', 'slug', 'short_description', 'description', 'category_id', 'price', 'sale_price', 'stock', 'low_stock_threshold', 'availability', 'featured', 'new_arrival', 'trending', 'active', 'colors', 'specs', 'features', 'in_box', 'images', 'videos', 'model_url', 'seo_title', 'seo_description'];
r.post('/products', (req, res) => {
  const p = productBody(req.body); uniqueCheck(p);
  const x = run(`INSERT INTO products(${PCOLS.join(',')}) VALUES (${PCOLS.map(() => '?').join(',')})`, ...PCOLS.map((c) => p[c]));
  audit(req.user.id, 'create', 'product', x.lastInsertRowid, { name: p.name });
  res.status(201).json(adminProduct(get('SELECT * FROM products WHERE id = ?', x.lastInsertRowid)));
});
r.put('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const before = get('SELECT * FROM products WHERE id = ?', id);
  if (!before) throw new HttpError(404, 'Product not found.');
  const p = productBody(req.body); uniqueCheck(p, id);
  run(`UPDATE products SET ${PCOLS.map((c) => `${c} = ?`).join(', ')}, updated_at = datetime('now') WHERE id = ?`, ...PCOLS.map((c) => p[c]), id);
  audit(req.user.id, 'update', 'product', id, { price: [before.price, p.price], sale: [before.sale_price, p.sale_price], stock: [before.stock, p.stock], availability: [before.availability, p.availability] });
  res.json(adminProduct(get('SELECT * FROM products WHERE id = ?', id)));
});
/** Quick inline edits from the product list (stock / availability / flags). */
r.patch('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const p = get('SELECT * FROM products WHERE id = ?', id);
  if (!p) throw new HttpError(404, 'Product not found.');
  const sets = []; const vals = [];
  if ('stock' in req.body) { sets.push('stock = ?'); vals.push(int(req.body.stock, { field: 'Stock', min: 0 })); }
  if ('availability' in req.body) {
    if (!U.AVAILABILITY[req.body.availability]) throw bad('Invalid availability.');
    if (['in_stock', 'preorder'].includes(req.body.availability) && p.price == null) throw bad('Set a price before making this product purchasable.');
    sets.push('availability = ?'); vals.push(req.body.availability);
  }
  for (const f of ['featured', 'new_arrival', 'trending', 'active']) if (f in req.body) { sets.push(`${f} = ?`); vals.push(bool(req.body[f])); }
  if (!sets.length) throw bad('Nothing to update.');
  run(`UPDATE products SET ${sets.join(', ')}, updated_at = datetime('now') WHERE id = ?`, ...vals, id);
  audit(req.user.id, 'patch', 'product', id, req.body);
  res.json(adminProduct(get('SELECT * FROM products WHERE id = ?', id)));
});
r.delete('/products/:id', adminOnly, (req, res) => {
  const id = Number(req.params.id);
  const hasOrders = get('SELECT 1 FROM order_items WHERE product_id = ?', id);
  if (hasOrders) {
    // Keep order history intact: archive instead of hard delete
    run(`UPDATE products SET active = 0, updated_at = datetime('now') WHERE id = ?`, id);
    audit(req.user.id, 'archive', 'product', id);
    return res.json({ ok: true, archived: true, message: 'Product has orders, so it was hidden from the shop instead of deleted.' });
  }
  run('DELETE FROM products WHERE id = ?', id);
  audit(req.user.id, 'delete', 'product', id);
  res.json({ ok: true });
});

// ---------- categories ----------
function categoryBody(b) {
  const name = str(b.name, { field: 'Name', required: true, max: 80 });
  return {
    name, slug: slugify(b.slug || name), short_name: str(b.short_name, { field: 'Nav label', max: 30 }) || null,
    description: str(b.description, { field: 'Description', max: 300 }) || null,
    image: str(b.image, { field: 'Image', max: 500 }) || null,
    sort: int(b.sort ?? 0, { field: 'Sort order' }), show_on_home: bool(b.show_on_home), show_in_nav: bool(b.show_in_nav), active: b.active === undefined ? 1 : bool(b.active),
  };
}
r.get('/categories', (_req, res) => res.json(all('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count FROM categories c ORDER BY sort, id')));
r.post('/categories', (req, res) => {
  const c = categoryBody(req.body);
  if (get('SELECT 1 FROM categories WHERE slug = ?', c.slug)) throw bad('A category with this URL slug already exists.');
  run('INSERT INTO categories(name, slug, short_name, description, image, sort, show_on_home, show_in_nav, active) VALUES (?,?,?,?,?,?,?,?,?)', c.name, c.slug, c.short_name, c.description, c.image, c.sort, c.show_on_home, c.show_in_nav, c.active);
  audit(req.user.id, 'create', 'category', c.slug);
  res.status(201).json({ ok: true });
});
r.put('/categories/:id', (req, res) => {
  const c = categoryBody(req.body); const id = Number(req.params.id);
  if (get('SELECT 1 FROM categories WHERE slug = ? AND id != ?', c.slug, id)) throw bad('A category with this URL slug already exists.');
  run('UPDATE categories SET name=?, slug=?, short_name=?, description=?, image=?, sort=?, show_on_home=?, show_in_nav=?, active=? WHERE id = ?', c.name, c.slug, c.short_name, c.description, c.image, c.sort, c.show_on_home, c.show_in_nav, c.active, id);
  audit(req.user.id, 'update', 'category', id);
  res.json({ ok: true });
});
r.delete('/categories/:id', adminOnly, (req, res) => {
  const id = Number(req.params.id);
  if (get('SELECT 1 FROM products WHERE category_id = ?', id)) throw bad('Move or delete the products in this category first.');
  run('DELETE FROM categories WHERE id = ?', id);
  audit(req.user.id, 'delete', 'category', id);
  res.json({ ok: true });
});

// ---------- orders ----------
r.get('/orders', (req, res) => {
  const q = req.query; const where = ['1=1']; const params = [];
  if (q.status) { where.push('status = ?'); params.push(String(q.status)); }
  if (q.payment_status) { where.push('payment_status = ?'); params.push(String(q.payment_status)); }
  if (q.from) { where.push('date(created_at) >= date(?)'); params.push(String(q.from)); }
  if (q.to) { where.push('date(created_at) <= date(?)'); params.push(String(q.to)); }
  if (q.q) { const t = `%${String(q.q).slice(0, 80)}%`; where.push('(order_number LIKE ? OR full_name LIKE ? OR phone LIKE ? OR email LIKE ? OR city LIKE ?)'); params.push(t, t, t, t, t); }
  const page = Math.max(1, Number(q.page) || 1); const limit = 30;
  const total = get(`SELECT COUNT(*) n FROM orders WHERE ${where.join(' AND ')}`, ...params).n;
  const rows = all(`SELECT id, order_number, full_name, phone, city, total, status, payment_method, payment_status, created_at,
    (SELECT SUM(qty) FROM order_items WHERE order_id = orders.id) items FROM orders WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...params, limit, (page - 1) * limit);
  res.json({ orders: rows, total, page, pages: Math.ceil(total / limit), status_labels: STATUS_LABELS, payment_labels: PAYMENT_LABELS });
});
r.get('/orders/:id', (req, res) => {
  const o = get('SELECT * FROM orders WHERE id = ?', Number(req.params.id));
  if (!o) throw new HttpError(404, 'Order not found.');
  const v = orderView(o);
  v.events = all(`SELECT e.*, u.name actor FROM order_events e LEFT JOIN users u ON u.id = e.actor_id WHERE order_id = ? ORDER BY e.id`, o.id);
  res.json({ ...v, id: o.id, user_id: o.user_id, admin_notes: o.admin_notes, payment_reference: o.payment_reference, zone_id: o.zone_id,
    allowed_transitions: ALLOWED_TRANSITIONS[o.status], status_labels: STATUS_LABELS, payment_labels: PAYMENT_LABELS,
    customer_order_count: get('SELECT COUNT(*) n FROM orders WHERE phone = ?', o.phone).n });
});
r.post('/orders/:id/status', async (req, res) => {
  const id = Number(req.params.id);
  const next = String(req.body.status);
  if (!STATUS_LABELS[next]) throw bad('Invalid status.');
  const o = changeStatus(id, next, req.user.id, str(req.body.note, { field: 'Note', max: 500 }) || null);
  audit(req.user.id, 'status', 'order', id, { status: next });
  if (o.email && req.body.notify !== false) {
    sendEmail(o.email, `Your TEQNEST order ${o.order_number} — ${STATUS_LABELS[next]}`,
      `Hi ${o.full_name},\n\nYour order ${o.order_number} is now: ${STATUS_LABELS[next]}.${o.tracking_number ? `\nTracking: ${o.tracking_carrier || ''} ${o.tracking_number} ${o.tracking_url || ''}` : ''}\n\nTrack your order: ${process.env.PUBLIC_URL || ''}/track?order=${o.order_number}\n\n— TEQNEST`).catch(() => {});
  }
  res.json({ ok: true });
});
r.post('/orders/:id/tracking', (req, res) => {
  const id = Number(req.params.id);
  const carrier = str(req.body.carrier, { field: 'Courier', max: 60 }) || null;
  const number = str(req.body.number, { field: 'Tracking number', max: 80 }) || null;
  let url = str(req.body.url, { field: 'Tracking URL', max: 500 }) || null;
  if (url && !/^https:\/\//.test(url)) throw bad('Tracking URL must start with https://');
  run(`UPDATE orders SET tracking_carrier = ?, tracking_number = ?, tracking_url = ?, updated_at = datetime('now') WHERE id = ?`, carrier, number, url, id);
  if (number) run(`INSERT INTO order_events(order_id, type, message, actor_id) VALUES (?, 'tracking', ?, ?)`, id, `Tracking added: ${carrier || ''} ${number}`.trim(), req.user.id);
  audit(req.user.id, 'tracking', 'order', id, { carrier, number });
  res.json({ ok: true });
});
r.post('/orders/:id/payment', (req, res) => {
  const id = Number(req.params.id);
  const ps = String(req.body.payment_status);
  if (!PAYMENT_LABELS[ps]) throw bad('Invalid payment status.');
  run(`UPDATE orders SET payment_status = ?, updated_at = datetime('now') WHERE id = ?`, ps, id);
  run(`INSERT INTO order_events(order_id, type, message, actor_id, visible_to_customer) VALUES (?, 'payment', ?, ?, 1)`, id, `Payment status: ${PAYMENT_LABELS[ps]}`, req.user.id);
  audit(req.user.id, 'payment', 'order', id, { payment_status: ps });
  res.json({ ok: true });
});
r.post('/orders/:id/notes', (req, res) => {
  run(`UPDATE orders SET admin_notes = ?, updated_at = datetime('now') WHERE id = ?`, str(req.body.admin_notes, { field: 'Notes', max: 5000 }) || null, Number(req.params.id));
  res.json({ ok: true });
});

// ---------- customers ----------
r.get('/customers', (req, res) => {
  const t = `%${String(req.query.q || '').slice(0, 80)}%`;
  res.json(all(`SELECT u.id, u.name, u.email, u.phone, u.created_at, u.last_login_at, u.active,
    (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) orders,
    (SELECT COALESCE(SUM(total),0) FROM orders o WHERE o.user_id = u.id AND o.status != 'cancelled') spent
    FROM users u WHERE u.role = 'customer' AND (u.name LIKE ? OR u.email LIKE ? OR COALESCE(u.phone,'') LIKE ?) ORDER BY u.id DESC LIMIT 200`, t, t, t));
});
r.get('/customers/:id', (req, res) => {
  const u = get(`SELECT id, name, email, phone, created_at, last_login_at, active FROM users WHERE id = ? AND role = 'customer'`, Number(req.params.id));
  if (!u) throw new HttpError(404, 'Customer not found.');
  res.json({ ...u,
    orders: all('SELECT id, order_number, total, status, payment_status, created_at FROM orders WHERE user_id = ? ORDER BY id DESC', u.id),
    addresses: all('SELECT * FROM addresses WHERE user_id = ?', u.id),
    wishlist: all('SELECT p.id, p.name FROM wishlists w JOIN products p ON p.id = w.product_id WHERE w.user_id = ?', u.id),
    reviews: all('SELECT r.id, r.rating, r.status, p.name product FROM reviews r JOIN products p ON p.id = r.product_id WHERE r.user_id = ?', u.id),
  });
});
r.patch('/customers/:id', adminOnly, (req, res) => {
  run(`UPDATE users SET active = ? WHERE id = ? AND role = 'customer'`, bool(req.body.active), Number(req.params.id));
  if (!bool(req.body.active)) run('DELETE FROM sessions WHERE user_id = ?', Number(req.params.id));
  audit(req.user.id, 'customer_active', 'user', req.params.id, { active: bool(req.body.active) });
  res.json({ ok: true });
});

// ---------- reviews ----------
r.get('/reviews', (req, res) => {
  const status = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : 'pending';
  res.json(all(`SELECT r.*, u.name, u.email, p.name product, p.slug, o.order_number FROM reviews r
    JOIN users u ON u.id = r.user_id JOIN products p ON p.id = r.product_id JOIN orders o ON o.id = r.order_id
    WHERE r.status = ? ORDER BY r.id DESC`, status));
});
r.post('/reviews/:id', (req, res) => {
  const status = String(req.body.status);
  if (!['approved', 'rejected', 'pending'].includes(status)) throw bad('Invalid status.');
  run('UPDATE reviews SET status = ? WHERE id = ?', status, Number(req.params.id));
  audit(req.user.id, 'moderate', 'review', req.params.id, { status });
  res.json({ ok: true });
});
r.delete('/reviews/:id', adminOnly, (req, res) => { run('DELETE FROM reviews WHERE id = ?', Number(req.params.id)); res.json({ ok: true }); });

// ---------- subscribers ----------
r.get('/subscribers', (_req, res) => res.json(all('SELECT id, email, created_at FROM subscribers ORDER BY id DESC')));
r.get('/subscribers.csv', (_req, res) => {
  const rows = all('SELECT email, created_at FROM subscribers ORDER BY id');
  const esc = (v) => /^[=+\-@]/.test(v) ? `'${v}` : v; // neutralise spreadsheet formula injection
  res.set('Content-Type', 'text/csv; charset=utf-8').set('Content-Disposition', 'attachment; filename="teqnest-subscribers.csv"')
    .send('email,subscribed_at\n' + rows.map((x) => `"${esc(x.email).replace(/"/g, '""')}",${x.created_at}`).join('\n'));
});
r.delete('/subscribers/:id', adminOnly, (req, res) => { run('DELETE FROM subscribers WHERE id = ?', Number(req.params.id)); res.json({ ok: true }); });

// ---------- admin-only: coupons, delivery, settings, staff ----------
function couponBody(b) {
  const type = b.type === 'percent' ? 'percent' : 'fixed';
  const value = int(b.value, { field: 'Value', min: 1, max: type === 'percent' ? 100 : 10_000_000 });
  let expires = str(b.expires_at, { field: 'Expiry', max: 30 }) || null;
  if (expires && isNaN(new Date(expires))) throw bad('Expiry date is invalid.');
  if (expires && /^\d{4}-\d{2}-\d{2}$/.test(expires)) expires += 'T23:59:59+05:00'; // end of day, Pakistan time
  return {
    code: str(b.code, { field: 'Code', required: true, max: 40 }).toUpperCase().replace(/\s+/g, ''),
    type, value, min_subtotal: int(b.min_subtotal ?? 0, { field: 'Minimum order', min: 0 }),
    max_discount: int(b.max_discount, { field: 'Max discount', min: 1, nullable: true }),
    expires_at: expires, usage_limit: int(b.usage_limit, { field: 'Usage limit', min: 1, nullable: true }), active: bool(b.active),
  };
}
r.get('/coupons', adminOnly, (_req, res) => res.json(all('SELECT * FROM coupons ORDER BY id DESC')));
r.post('/coupons', adminOnly, (req, res) => {
  const c = couponBody(req.body);
  if (get('SELECT 1 FROM coupons WHERE code = ?', c.code)) throw bad('This code already exists.');
  run('INSERT INTO coupons(code, type, value, min_subtotal, max_discount, expires_at, usage_limit, active) VALUES (?,?,?,?,?,?,?,?)', c.code, c.type, c.value, c.min_subtotal, c.max_discount, c.expires_at, c.usage_limit, c.active);
  audit(req.user.id, 'create', 'coupon', c.code); res.status(201).json({ ok: true });
});
r.put('/coupons/:id', adminOnly, (req, res) => {
  const c = couponBody(req.body); const id = Number(req.params.id);
  if (get('SELECT 1 FROM coupons WHERE code = ? AND id != ?', c.code, id)) throw bad('This code already exists.');
  run('UPDATE coupons SET code=?, type=?, value=?, min_subtotal=?, max_discount=?, expires_at=?, usage_limit=?, active=? WHERE id = ?', c.code, c.type, c.value, c.min_subtotal, c.max_discount, c.expires_at, c.usage_limit, c.active, id);
  audit(req.user.id, 'update', 'coupon', id); res.json({ ok: true });
});
r.delete('/coupons/:id', adminOnly, (req, res) => { run('DELETE FROM coupons WHERE id = ?', Number(req.params.id)); audit(req.user.id, 'delete', 'coupon', req.params.id); res.json({ ok: true }); });

function zoneBody(b) {
  return {
    name: str(b.name, { field: 'Zone name', required: true, max: 80 }), description: str(b.description, { field: 'Description', max: 200 }) || null,
    fee: int(b.fee ?? 0, { field: 'Delivery fee', min: 0 }), free_threshold: int(b.free_threshold, { field: 'Free delivery threshold', min: 0, nullable: true }),
    cod_available: bool(b.cod_available), active: bool(b.active), sort: int(b.sort ?? 0, { field: 'Sort' }),
  };
}
r.get('/zones', (_req, res) => res.json(all('SELECT * FROM delivery_zones ORDER BY sort, id')));
r.post('/zones', adminOnly, (req, res) => { const z = zoneBody(req.body); run('INSERT INTO delivery_zones(name, description, fee, free_threshold, cod_available, active, sort) VALUES (?,?,?,?,?,?,?)', z.name, z.description, z.fee, z.free_threshold, z.cod_available, z.active, z.sort); audit(req.user.id, 'create', 'zone', z.name); res.status(201).json({ ok: true }); });
r.put('/zones/:id', adminOnly, (req, res) => { const z = zoneBody(req.body); run('UPDATE delivery_zones SET name=?, description=?, fee=?, free_threshold=?, cod_available=?, active=?, sort=? WHERE id = ?', z.name, z.description, z.fee, z.free_threshold, z.cod_available, z.active, z.sort, Number(req.params.id)); audit(req.user.id, 'update', 'zone', req.params.id); res.json({ ok: true }); });
r.delete('/zones/:id', adminOnly, (req, res) => { run('UPDATE delivery_zones SET active = 0 WHERE id = ?', Number(req.params.id)); res.json({ ok: true, message: 'Zone deactivated (kept for order history).' }); });

const SETTING_KEYS = ['brand', 'announcements', 'hero', 'promo', 'brand_story', 'why_choose', 'contact', 'social', 'footer', 'payments', 'home_sections', 'pages'];
r.get('/settings', adminOnly, (_req, res) => res.json(Object.fromEntries(SETTING_KEYS.map((k) => [k, getSetting(k, null)]))));
r.put('/settings/:key', adminOnly, (req, res) => {
  const key = req.params.key;
  if (!SETTING_KEYS.includes(key)) throw bad('Unknown setting.');
  const value = req.body?.value;
  if (value === undefined || JSON.stringify(value).length > 200_000) throw bad('Invalid value.');
  // Light structural validation for the security-relevant bits
  if (key === 'social' && value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value)) if (v && !/^https:\/\//.test(v)) throw bad(`${k} link must start with https://`);
  }
  if (key === 'contact' && value?.whatsapp && !/^92\d{10}$/.test(String(value.whatsapp).replace(/\D/g, ''))) throw bad('WhatsApp number must be in international format, e.g. 923001234567.');
  setSetting(key, value);
  audit(req.user.id, 'settings', 'settings', key);
  res.json({ ok: true });
});

r.get('/staff', adminOnly, (_req, res) => res.json(all(`SELECT id, name, email, role, active, last_login_at FROM users WHERE role IN ('staff','admin') ORDER BY id`)));
r.post('/staff', adminOnly, async (req, res) => {
  const name = str(req.body.name, { field: 'Name', required: true, max: 100 });
  const em = email(req.body.email, { required: true });
  const role = req.body.role === 'admin' ? 'admin' : 'staff';
  const pw = String(req.body.password || '');
  if (pw.length < 12) throw bad('Staff passwords must be at least 12 characters.');
  const existing = get('SELECT id, role FROM users WHERE email = ?', em);
  if (existing) {
    run('UPDATE users SET role = ?, active = 1 WHERE id = ?', role, existing.id);
  } else {
    run('INSERT INTO users(email, password_hash, name, role) VALUES (?,?,?,?)', em, await hashPassword(pw), name, role);
  }
  audit(req.user.id, 'staff_add', 'user', em, { role });
  res.status(201).json({ ok: true });
});
r.patch('/staff/:id', adminOnly, (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) throw bad('You cannot change your own role or access.');
  const role = ['customer', 'staff', 'admin'].includes(req.body.role) ? req.body.role : null;
  if (role) run('UPDATE users SET role = ? WHERE id = ?', role, id);
  if ('active' in req.body) { run('UPDATE users SET active = ? WHERE id = ?', bool(req.body.active), id); if (!bool(req.body.active)) run('DELETE FROM sessions WHERE user_id = ?', id); }
  audit(req.user.id, 'staff_update', 'user', id, req.body);
  res.json({ ok: true });
});

r.get('/outbox', adminOnly, (_req, res) => res.json(all('SELECT id, channel, recipient, subject, status, error, created_at FROM outbox ORDER BY id DESC LIMIT 100')));
r.get('/audit', adminOnly, (_req, res) => res.json(all('SELECT a.*, u.name FROM audit_log a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 200')));

module.exports = r;
