'use strict';
const crypto = require('node:crypto');
const { get, all, run, getSetting } = require('./db');

const AVAILABILITY = {
  in_stock: { label: 'In Stock', purchasable: true },
  out_of_stock: { label: 'Out of Stock', purchasable: false },
  coming_soon: { label: 'Coming Soon', purchasable: false },
  on_request: { label: 'Available on Request', purchasable: false },
  preorder: { label: 'Pre-order', purchasable: true },
};

class HttpError extends Error {
  constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; }
}
const bad = (msg, extra) => new HttpError(400, msg, extra);

const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

function slugify(s) {
  return String(s).toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '')
    .trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 90);
}

const parseJSON = (s, fb) => { try { return JSON.parse(s); } catch { return fb; } };

// ---------- validation helpers ----------
function str(v, { field, max = 500, required = false, min = 0 } = {}) {
  if (v === undefined || v === null) v = '';
  if (typeof v !== 'string' && typeof v !== 'number') throw bad(`${field} is invalid`);
  v = String(v).trim();
  if (required && !v) throw bad(`${field} is required`);
  if (v.length > max) throw bad(`${field} is too long (max ${max})`);
  if (v && v.length < min) throw bad(`${field} is too short (min ${min})`);
  return v;
}
function int(v, { field, min = -Infinity, max = Infinity, nullable = false } = {}) {
  if ((v === '' || v === null || v === undefined) && nullable) return null;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw bad(`${field} must be a whole number${min > -Infinity ? ` ≥ ${min}` : ''}`);
  return n;
}
const bool = (v) => (v === true || v === 1 || v === '1' || v === 'true' || v === 'on') ? 1 : 0;
function email(v, { required = false, field = 'Email' } = {}) {
  v = str(v, { field, max: 254, required }).toLowerCase();
  if (v && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) throw bad(`${field} is not valid`);
  return v;
}
/** Pakistani mobile: accepts 03XXXXXXXXX, +923XXXXXXXXX, 923XXXXXXXXX. Normalises to 03XXXXXXXXX. */
function pkPhone(v, { field = 'Mobile number', required = false } = {}) {
  v = str(v, { field, max: 20, required }).replace(/[\s-]/g, '');
  if (!v) return '';
  let m = v.match(/^(?:\+?92|0)?(3\d{9})$/);
  if (!m) throw bad(`${field} must be a valid Pakistani mobile number (e.g. 03XX XXXXXXX)`);
  return '0' + m[1];
}
function strList(v, field, maxItems = 50, maxLen = 300) {
  if (!Array.isArray(v)) v = typeof v === 'string' ? v.split('\n') : [];
  return v.map((x) => String(x).trim()).filter(Boolean).slice(0, maxItems).map((x) => x.slice(0, maxLen));
}
function specList(v) {
  if (!Array.isArray(v)) return [];
  return v.filter((s) => s && s.label && s.value).slice(0, 60)
    .map((s) => ({ label: String(s.label).trim().slice(0, 80), value: String(s.value).trim().slice(0, 300) }));
}

// ---------- products ----------
function effectivePrice(p) {
  if (p.price == null) return null;
  return (p.sale_price != null && p.sale_price > 0 && p.sale_price < p.price) ? p.sale_price : p.price;
}

function ratingFor(productId) {
  const r = get(`SELECT COUNT(*) c, AVG(rating) a FROM reviews WHERE product_id = ? AND status = 'approved'`, productId);
  return r.c ? { count: r.c, average: Math.round(r.a * 10) / 10 } : null;
}

function serializeProduct(p, { full = false } = {}) {
  if (!p) return null;
  const av = AVAILABILITY[p.availability] || AVAILABILITY.out_of_stock;
  const price = effectivePrice(p);
  const onSale = p.price != null && price < p.price;
  // in_stock items with zero stock are not purchasable — never claim stock that isn't there
  const purchasable = av.purchasable && price != null && (p.availability === 'preorder' || p.stock > 0);
  let availabilityLabel = av.label;
  if (p.availability === 'in_stock' && p.stock <= 0) availabilityLabel = 'Out of Stock';
  const out = {
    id: p.id, sku: p.sku, name: p.name, slug: p.slug,
    short_description: p.short_description,
    category: p.category_slug ? { slug: p.category_slug, name: p.category_name } : null,
    price, regular_price: p.price,
    discount_percent: onSale ? Math.round((1 - price / p.price) * 100) : 0,
    availability: p.availability === 'in_stock' && p.stock <= 0 ? 'out_of_stock' : p.availability,
    availability_label: availabilityLabel,
    purchasable,
    low_stock: p.availability === 'in_stock' && p.stock > 0 && p.stock <= p.low_stock_threshold,
    max_qty: p.availability === 'preorder' ? 10 : Math.max(0, Math.min(p.stock, 10)),
    featured: !!p.featured, new_arrival: !!p.new_arrival, trending: !!p.trending,
    colors: parseJSON(p.colors, []),
    images: parseJSON(p.images, []),
    rating: ratingFor(p.id),
  };
  if (full) {
    Object.assign(out, {
      description: p.description,
      specs: parseJSON(p.specs, []),
      features: parseJSON(p.features, []),
      in_box: parseJSON(p.in_box, []),
      videos: parseJSON(p.videos, []),
      model_url: p.model_url,
      seo_title: p.seo_title, seo_description: p.seo_description,
    });
  }
  return out;
}

const PRODUCT_SELECT = `SELECT p.*, c.slug AS category_slug, c.name AS category_name
  FROM products p LEFT JOIN categories c ON c.id = p.category_id`;

// ---------- cart pricing ----------
function evaluateCoupon(code, subtotal) {
  if (!code) return { discount: 0, coupon: null };
  const c = get('SELECT * FROM coupons WHERE code = ?', code);
  if (!c || !c.active) return { discount: 0, coupon: null, error: 'This discount code is not valid.' };
  if (c.expires_at && new Date(c.expires_at) < new Date()) return { discount: 0, coupon: null, error: 'This discount code has expired.' };
  if (c.usage_limit != null && c.used_count >= c.usage_limit) return { discount: 0, coupon: null, error: 'This discount code has reached its usage limit.' };
  if (subtotal < c.min_subtotal) return { discount: 0, coupon: null, error: `Minimum order of Rs ${c.min_subtotal.toLocaleString('en-PK')} required for this code.` };
  let d = c.type === 'percent' ? Math.floor(subtotal * c.value / 100) : c.value;
  if (c.max_discount != null) d = Math.min(d, c.max_discount);
  d = Math.min(d, subtotal);
  return { discount: d, coupon: { code: c.code, type: c.type, value: c.value } };
}

function deliveryFor(zoneId, subtotalAfterDiscount) {
  const zones = all('SELECT * FROM delivery_zones WHERE active = 1 ORDER BY sort, id');
  const zone = zones.find((z) => z.id === Number(zoneId)) || null;
  if (!zone) return { zone: null, fee: null, zones };
  const free = zone.free_threshold != null && subtotalAfterDiscount >= zone.free_threshold;
  return { zone, fee: free ? 0 : zone.fee, zones, free };
}

function audit(userId, action, entity, entityId, details) {
  run('INSERT INTO audit_log(user_id, action, entity, entity_id, details) VALUES (?,?,?,?,?)',
    userId ?? null, action, entity ?? null, entityId == null ? null : String(entityId), details ? JSON.stringify(details) : null);
}

function publicSettings() {
  const keys = ['brand', 'announcements', 'hero', 'promo', 'brand_story', 'why_choose', 'contact', 'social', 'footer', 'payments', 'home_sections', 'pages'];
  const out = {};
  for (const k of keys) out[k] = getSetting(k, null);
  // Never expose internal-only bits of payments config
  if (out.payments) {
    out.payments = Object.fromEntries(Object.entries(out.payments).map(([k, v]) => [k, { enabled: !!v.enabled, label: v.label, instructions: v.instructions || '' }]));
  }
  return out;
}

module.exports = {
  AVAILABILITY, HttpError, bad, randomToken, sha256, slugify, parseJSON,
  str, int, bool, email, pkPhone, strList, specList,
  effectivePrice, serializeProduct, PRODUCT_SELECT, ratingFor,
  evaluateCoupon, deliveryFor, audit, publicSettings,
};
