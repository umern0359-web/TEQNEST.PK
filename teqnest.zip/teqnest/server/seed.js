'use strict';
/**
 * Seeds default site content, delivery zones, categories and an initial admin account.
 * Demo products (SKU prefix DEMO-) carry SAMPLE prices so the full purchase flow can be tested.
 * They are clearly flagged on the storefront until the admin switches off "demo notice" and
 * replaces them with the real TEQNEST catalog.
 */
const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');
const { get, run, tx, setSetting, getSetting } = require('./db');

const img = (shape, color, n = 2) => Array.from({ length: n }, (_, i) => `/img/products/${shape}-${color}-${i + 1}.svg`);
const C = { graphite: { name: 'Graphite', hex: '#2b313d' }, white: { name: 'Arctic White', hex: '#e9edf3' }, blue: { name: 'Electric Blue', hex: '#397BFF' }, silver: { name: 'Silver', hex: '#a5adba' }, cyan: { name: 'Cyan', hex: '#00D9FF' } };

const CATEGORIES = [
  { slug: 'earbuds', name: 'Wireless Earbuds', short_name: 'Earbuds', description: 'Compact true-wireless sound for every day.', image: '/img/products/earbuds-graphite-1.svg' },
  { slug: 'headphones', name: 'Headphones', short_name: 'Headphones', description: 'Immersive over-ear and on-ear listening.', image: '/img/products/headphones-silver-1.svg' },
  { slug: 'smartwatches', name: 'Smartwatches', short_name: 'Smartwatches', description: 'Fitness, notifications and time — on your wrist.', image: '/img/products/watch-graphite-1.svg' },
  { slug: 'gadgets', name: 'Smart Gadgets', short_name: 'Gadgets', description: 'Clever devices that simplify daily life.', image: '/img/products/tracker-blue-1.svg' },
  { slug: 'mobile-accessories', name: 'Mobile Accessories', short_name: 'Accessories', description: 'Chargers, power banks and cables that keep you going.', image: '/img/products/powerbank-graphite-1.svg' },
  { slug: 'essentials', name: 'Everyday Tech Essentials', short_name: 'Essentials', description: 'Desk and travel tech you will reach for daily.', image: '/img/products/stand-silver-1.svg', show_in_nav: 0 },
];

// NOTE: names, specs and prices below are SAMPLE DATA for testing — replace with real catalog data.
const PRODUCTS = [
  { sku: 'DEMO-EB-01', cat: 'earbuds', name: 'Pulse ANC Wireless Earbuds', price: 8999, sale: 7499, stock: 25, availability: 'in_stock', featured: 1, trending: 1, colors: ['graphite', 'white'], shape: 'earbuds',
    short: 'Active noise cancellation in a pocket-size case.',
    specs: [['Bluetooth', '5.3'], ['Driver', '10 mm dynamic'], ['Charging port', 'USB-C'], ['Controls', 'Touch']],
    features: ['Active noise cancellation with transparency mode', 'Touch controls for music and calls', 'USB-C charging case'], box: ['Earbuds', 'Charging case', 'USB-C cable', 'Spare ear tips'] },
  { sku: 'DEMO-EB-02', cat: 'earbuds', name: 'Air Lite Open Earbuds', price: 5499, stock: 0, availability: 'preorder', new_arrival: 1, colors: ['white', 'blue'], shape: 'earbuds',
    short: 'Featherweight earbuds for all-day comfort.',
    specs: [['Bluetooth', '5.3'], ['Charging port', 'USB-C']], features: ['Lightweight design', 'Low-latency game mode'], box: ['Earbuds', 'Charging case', 'USB-C cable'] },
  { sku: 'DEMO-HP-01', cat: 'headphones', name: 'Studio Max ANC Headphones', price: 18999, sale: 16499, stock: 8, availability: 'in_stock', featured: 1, trending: 1, colors: ['silver', 'graphite'], shape: 'headphones',
    short: 'Over-ear comfort with deep, detailed sound.',
    specs: [['Type', 'Over-ear, closed back'], ['Bluetooth', '5.3'], ['Wired', '3.5 mm AUX'], ['Charging port', 'USB-C']],
    features: ['Hybrid active noise cancellation', 'Foldable design with travel pouch', 'Wired and wireless listening'], box: ['Headphones', 'Travel pouch', 'USB-C cable', '3.5 mm audio cable'] },
  { sku: 'DEMO-HP-02', cat: 'headphones', name: 'Wave On-Ear Headphones', price: null, stock: 0, availability: 'coming_soon', new_arrival: 1, colors: ['blue', 'white'], shape: 'headphones',
    short: 'Compact on-ear headphones. Launching soon.', specs: [['Type', 'On-ear']], features: ['Compact folding design'], box: [] },
  { sku: 'DEMO-SW-01', cat: 'smartwatches', name: 'Orbit S Smartwatch', price: 12499, stock: 14, availability: 'in_stock', featured: 1, trending: 1, new_arrival: 1, colors: ['graphite', 'silver'], shape: 'watch',
    short: 'Health tracking and smart notifications.',
    specs: [['Display', '1.9" AMOLED'], ['Sensors', 'Heart rate, SpO2'], ['Connectivity', 'Bluetooth 5.2'], ['Water resistance', 'IP68 (manufacturer rating)']],
    features: ['Always-on AMOLED display', 'Heart rate and sleep tracking', 'Call and message notifications'], box: ['Smartwatch', 'Magnetic charger', 'Quick start guide'] },
  { sku: 'DEMO-SW-02', cat: 'smartwatches', name: 'Orbit Pro Smartwatch', price: null, stock: 0, availability: 'on_request', colors: ['cyan', 'graphite'], shape: 'watch',
    short: 'Premium titanium-finish smartwatch. Available on request.', specs: [['Display', 'AMOLED']], features: ['Premium finish'], box: [] },
  { sku: 'DEMO-GD-01', cat: 'gadgets', name: 'Locate Smart Tag', price: 2999, stock: 40, availability: 'in_stock', trending: 1, colors: ['white', 'graphite'], shape: 'tracker',
    short: 'Keep track of keys, bags and more.', specs: [['Connectivity', 'Bluetooth'], ['Battery', 'Replaceable coin cell']], features: ['Ring your item from your phone', 'Compact key-ring design'], box: ['Smart tag', 'Key ring'] },
  { sku: 'DEMO-GD-02', cat: 'gadgets', name: 'Boom Mini Bluetooth Speaker', price: 6999, sale: 5999, stock: 3, availability: 'in_stock', new_arrival: 1, colors: ['blue', 'graphite'], shape: 'speaker',
    short: 'Room-filling sound in a portable body.', specs: [['Bluetooth', '5.3'], ['Charging port', 'USB-C']], features: ['Portable design with strap', 'Pair two for stereo'], box: ['Speaker', 'USB-C cable'] },
  { sku: 'DEMO-MA-01', cat: 'mobile-accessories', name: 'Volt 20W USB-C Fast Charger', price: 2499, stock: 60, availability: 'in_stock', trending: 1, colors: ['white'], shape: 'charger',
    short: 'Compact fast charging for phones and earbuds.', specs: [['Output', '20 W USB-C PD'], ['Plug', 'Two-pin']], features: ['USB Power Delivery', 'Compact travel size'], box: ['Charger'] },
  { sku: 'DEMO-MA-02', cat: 'mobile-accessories', name: 'Flux 10000mAh Magnetic Power Bank', price: 6499, stock: 18, availability: 'in_stock', featured: 1, new_arrival: 1, colors: ['graphite', 'white', 'blue'], shape: 'powerbank',
    short: 'Snap-on wireless charging on the go.', specs: [['Capacity', '10000 mAh'], ['Output', 'USB-C PD + magnetic wireless']], features: ['Magnetic wireless charging', 'USB-C input/output'], box: ['Power bank', 'USB-C cable'] },
  { sku: 'DEMO-MA-03', cat: 'mobile-accessories', name: 'Braid USB-C to USB-C Cable (1.5 m)', price: 1299, stock: 0, availability: 'out_of_stock', colors: ['graphite', 'cyan'], shape: 'cable',
    short: 'Durable braided cable for daily charging.', specs: [['Length', '1.5 m'], ['Connectors', 'USB-C to USB-C']], features: ['Braided jacket'], box: ['Cable'] },
  { sku: 'DEMO-ES-01', cat: 'essentials', name: 'Lift Aluminium Laptop Stand', price: 4999, stock: 12, availability: 'in_stock', new_arrival: 1, colors: ['silver', 'graphite'], shape: 'stand',
    short: 'Raise your screen for a better posture.', specs: [['Material', 'Aluminium'], ['Fits', 'Laptops 10–16"']], features: ['Foldable, travel-friendly', 'Non-slip pads'], box: ['Stand', 'Pouch'] },
  { sku: 'DEMO-ES-02', cat: 'essentials', name: 'Dock 6-in-1 USB-C Hub', price: 5999, stock: 9, availability: 'in_stock', colors: ['silver'], shape: 'hub',
    short: 'Expand one USB-C port into six.', specs: [['Ports', 'HDMI, 2× USB-A, USB-C PD, SD, microSD']], features: ['4K HDMI output', 'Pass-through charging'], box: ['Hub'] },
];

const POLICY = (title, paras) => ({ title, body: paras.join('\n\n') });

function seed({ quiet = true, withProducts = true } = {}) {
  const log = (...a) => !quiet && console.log(...a);
  tx(() => {
    if (!getSetting('brand')) {
      setSetting('brand', { name: 'TEQNEST', domain: 'TEQNEST.PK', tagline: 'Technology That Fits Your Lifestyle.', logo_url: '', meta_description: 'TEQNEST is a Pakistani technology brand offering carefully selected earbuds, headphones, smartwatches, smart gadgets and mobile accessories.', demo_notice: true });
      setSetting('announcements', { enabled: true, interval: 4500, messages: ['Discover the Latest in Technology.', 'Premium Gadgets. Smarter Lifestyle.', "Explore What's New at TEQNEST."] });
      setSetting('hero', { eyebrow: 'TEQNEST.PK', line1: 'UPGRADE YOUR', line2: 'EVERYDAY TECH.', description: 'Discover smart gadgets and next-generation accessories designed to make everyday life better.', primary: { label: 'Explore Collection', url: '/shop' }, secondary: { label: 'Discover TEQNEST', url: '/about' }, enable_3d: true });
      setSetting('promo', { enabled: true, eyebrow: 'Limited picks', heading: 'YOUR NEXT TECH UPGRADE STARTS HERE.', text: 'Explore curated gadgets and accessories selected for everyday life.', cta_label: 'Shop Now', cta_url: '/shop', image: '/img/products/headphones-blue-1.svg' });
      setSetting('brand_story', { heading: 'NOT JUST GADGETS. A BETTER WAY TO CONNECT.', paragraphs: ['TEQNEST brings carefully selected technology to people who want their devices to simply work — and look good doing it.', 'From the earbuds you wear on your commute to the charger on your desk, we focus on accessible, lifestyle-ready tech and on looking after our customers before and after every order.'], points: ['Accessible technology', 'Smart lifestyle products', 'Customer-first support'], image: '/img/products/watch-blue-1.svg', cta: { label: 'About TEQNEST', url: '/about' } });
      setSetting('why_choose', [
        { icon: 'select', title: 'Carefully Selected Products', text: 'Every item in our catalog is chosen for everyday usefulness and design.' },
        { icon: 'cart', title: 'Convenient Ordering', text: 'Order online with Cash on Delivery or other available payment options, or reach us on WhatsApp.' },
        { icon: 'support', title: 'Customer Support', text: 'Questions before or after you buy? Our team is reachable on WhatsApp and email.' },
        { icon: 'truck', title: 'Delivery Across Available Service Areas', text: 'We deliver to the service areas shown at checkout, with charges shown before you pay.' },
      ]);
      setSetting('contact', { whatsapp: '', phone: '', email: '', address: '', hours: '', order_notification_email: '' });
      setSetting('social', { instagram: '', facebook: '', tiktok: '', youtube: '' });
      setSetting('footer', { description: 'TEQNEST is a modern Pakistani technology brand offering carefully selected gadgets and accessories. Technology That Fits Your Lifestyle.', copyright: 'TEQNEST.PK. All rights reserved.' });
      setSetting('payments', {
        cod: { enabled: true, label: 'Cash on Delivery', instructions: 'Pay in cash when your order is delivered.' },
        bank: { enabled: false, label: 'Bank Transfer', instructions: 'Add your bank name, account title, account number and IBAN in Admin → Settings → Payments.' },
        easypaisa: { enabled: false, label: 'Easypaisa', instructions: 'Add your Easypaisa merchant/account details in Admin → Settings → Payments.' },
        jazzcash: { enabled: false, label: 'JazzCash', instructions: 'Add your JazzCash merchant/account details in Admin → Settings → Payments.' },
      });
      setSetting('home_sections', { categories_heading: 'SHOP BY CATEGORY', trending_heading: "TECH EVERYONE'S TALKING ABOUT.", new_heading: 'NEW ARRIVALS', why_heading: 'WHY CHOOSE TEQNEST?', reviews_heading: 'FROM OUR CUSTOMERS', newsletter_heading: "STAY AHEAD OF WHAT'S NEXT.", newsletter_text: 'New arrivals, restocks and offers — straight to your inbox. No spam.' });
      setSetting('pages', {
        about: POLICY('About TEQNEST', ['TEQNEST is a Pakistani technology and lifestyle brand. We curate earbuds, headphones, smartwatches, smart gadgets and mobile accessories for people who want technology that fits naturally into daily life.', 'Our focus is simple: accessible technology, a clean shopping experience, and real people you can talk to on WhatsApp when you need help.']),
        privacy: POLICY('Privacy Policy', ['DRAFT — TEQNEST should review this policy with a legal adviser before launch.', 'We collect the information you provide when you place an order or create an account (name, phone, WhatsApp number, email, delivery address) to process and deliver your orders and to support you.', 'We do not sell your personal information. We share delivery details only with the courier partners needed to deliver your order.', 'Passwords are stored using one-way hashing. You can request access to or deletion of your account data by contacting us.']),
        terms: POLICY('Terms & Conditions', ['DRAFT — TEQNEST should review these terms with a legal adviser before launch.', 'Prices are shown in Pakistani Rupees (PKR). Orders are subject to confirmation and product availability.', 'Products marked Coming Soon or Available on Request cannot be ordered online; contact us to enquire.', 'Pre-order items are dispatched once stock arrives; we will contact you about timing.']),
        shipping: POLICY('Shipping Policy', ['DRAFT — update with TEQNEST\'s actual courier arrangements.', 'We deliver to the service areas listed at checkout. Delivery charges for your area are shown before you place your order.', 'Delivery times depend on your location and courier; we will share tracking details once your order ships.']),
        returns: POLICY('Return & Refund Policy', ['DRAFT — TEQNEST must define its actual return window and conditions before launch.', 'If your item arrives damaged or not as described, contact us on WhatsApp or email with your order number and photos as soon as possible.', 'Eligible returns and refunds are handled case by case according to the conditions TEQNEST publishes here.']),
        faq: { title: 'FAQ', items: [
          { q: 'How do I place an order?', a: 'Add products to your cart, go to checkout, enter your delivery details and choose a payment method. You will receive an order number immediately.' },
          { q: 'Do I need an account?', a: 'No. Guest checkout is available. An account lets you track orders, save addresses and keep a wishlist.' },
          { q: 'Which payment methods are available?', a: 'Available methods are shown at checkout. Cash on Delivery is supported in eligible areas.' },
          { q: 'How can I track my order?', a: 'Use the Track Order page with your order number and mobile number, or view it in your account.' },
          { q: 'What does "Available on Request" mean?', a: 'The product is in our catalog but not currently held in stock. Send us an inquiry on WhatsApp and we will tell you about availability.' },
        ] },
      });
      log('✓ Default site content');
    }
    if (!get('SELECT 1 FROM delivery_zones')) {
      // Sample charges — set real values in Admin → Delivery.
      run(`INSERT INTO delivery_zones(name, description, fee, free_threshold, cod_available, sort) VALUES ('Karachi', 'Delivery within Karachi', 250, 10000, 1, 1)`);
      run(`INSERT INTO delivery_zones(name, description, fee, free_threshold, cod_available, sort) VALUES ('Other cities in Pakistan', 'Nationwide courier delivery', 400, 15000, 1, 2)`);
      log('✓ Delivery zones (sample charges)');
    }
    CATEGORIES.forEach((c, i) => {
      if (!get('SELECT 1 FROM categories WHERE slug = ?', c.slug)) {
        run('INSERT INTO categories(slug, name, short_name, description, image, sort, show_in_nav) VALUES (?,?,?,?,?,?,?)', c.slug, c.name, c.short_name, c.description, c.image, i, c.show_in_nav ?? 1);
      }
    });
    if (withProducts && !get('SELECT 1 FROM products')) {
      for (const p of PRODUCTS) {
        const cat = get('SELECT id FROM categories WHERE slug = ?', p.cat);
        const slug = p.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
        const images = p.colors.flatMap((c, i) => img(p.shape, c, i === 0 ? 2 : 1));
        run(`INSERT INTO products(sku, name, slug, short_description, description, category_id, price, sale_price, stock, availability, featured, new_arrival, trending, colors, specs, features, in_box, images)
          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          p.sku, p.name, slug, p.short,
          `${p.short}\n\nThis is a DEMO product with sample information and pricing, included so the store can be tested end to end. Replace it with real TEQNEST catalog data in the admin dashboard.`,
          cat.id, p.price, p.sale ?? null, p.stock, p.availability, p.featured || 0, p.new_arrival || 0, p.trending || 0,
          JSON.stringify(p.colors.map((c) => C[c])), JSON.stringify(p.specs.map(([label, value]) => ({ label, value }))),
          JSON.stringify(p.features), JSON.stringify(p.box), JSON.stringify(images));
      }
      log(`✓ ${PRODUCTS.length} demo products (SKU prefix DEMO-, sample prices)`);
    }
    if (!get(`SELECT 1 FROM users WHERE role = 'admin'`)) {
      const email = (process.env.ADMIN_EMAIL || 'admin@teqnest.pk').toLowerCase();
      const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(12).toString('base64url');
      run(`INSERT INTO users(email, password_hash, name, role) VALUES (?,?,?,'admin')`, email, bcrypt.hashSync(pw, 12), 'TEQNEST Admin');
      console.log(`\n✓ Admin account created\n   email:    ${email}\n   password: ${process.env.ADMIN_PASSWORD ? '(from ADMIN_PASSWORD)' : pw}\n   Change it after first login.\n`);
    }
  });
}

module.exports = { seed };
if (require.main === module) seed({ quiet: false });
