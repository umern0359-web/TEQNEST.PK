'use strict';
const { run, getSetting } = require('./db');

let transporter = null;
if (process.env.SMTP_HOST) {
  const nodemailer = require('nodemailer');
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
}

/**
 * Sends an email when SMTP is configured; always records the message in the outbox table
 * so the admin can see what was (or would have been) sent. Never throws to the caller.
 */
async function sendEmail(to, subject, text) {
  if (!to) return;
  const r = run('INSERT INTO outbox(channel, recipient, subject, body, status) VALUES (?,?,?,?,?)',
    'email', to, subject, text, transporter ? 'queued' : 'not_configured');
  if (!transporter) {
    if (process.env.NODE_ENV !== 'production') console.log(`[mail:not-configured] to=${to} subject="${subject}"\n${text}\n`);
    return;
  }
  try {
    const brand = getSetting('brand', {});
    await transporter.sendMail({
      from: process.env.MAIL_FROM || `${brand.name || 'TEQNEST'} <no-reply@teqnest.pk>`,
      to, subject, text,
    });
    run(`UPDATE outbox SET status = 'sent' WHERE id = ?`, r.lastInsertRowid);
  } catch (e) {
    run(`UPDATE outbox SET status = 'failed', error = ? WHERE id = ?`, String(e.message).slice(0, 500), r.lastInsertRowid);
    console.error('[mail] send failed:', e.message);
  }
}

module.exports = { sendEmail };
