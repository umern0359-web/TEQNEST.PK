// TEQNEST admin dashboard (hash-routed SPA). All authorisation is enforced server-side.
import { api, esc, rs, qs, qsa, icon, toast, setBusy, formData, safeUrl } from '/js/core.js';

const root = qs('#admin-root');
let me = null;
const isAdmin = () => me?.role === 'admin';
const dt = (s) => s ? new Date(s.replace(' ', 'T') + (/[Z+]/.test(s) ? '' : 'Z')).toLocaleString('en-PK', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const AV = { in_stock: 'In Stock', out_of_stock: 'Out of Stock', coming_soon: 'Coming Soon', on_request: 'Available on Request', preorder: 'Pre-order' };
const STATUS = { pending: 'Pending', confirmed: 'Confirmed', processing: 'Processing', shipped: 'Shipped', delivered: 'Delivered', cancelled: 'Cancelled' };
const PAY = { unpaid: 'Unpaid', awaiting_verification: 'Awaiting verification', paid: 'Paid', refunded: 'Refunded', failed: 'Failed' };
const opts = (map, sel) => Object.entries(map).map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${esc(l)}</option>`).join('');
const pill = (s, label) => `<span class="pill ${s}">${esc(label || s)}</span>`;

// ---------------- auth ----------------
async function boot() {
  try { me = (await api('/account/me')).user; } catch { me = null; }
  if (!me || !['staff', 'admin'].includes(me.role)) return loginScreen(me);
  shell(); addEventListener('hashchange', route); route();
}
function loginScreen(user) {
  root.innerHTML = `<div class="login-box"><div style="text-align:center;margin-bottom:24px"><div class="logo" style="justify-content:center">TEQNEST<span class="dot"></span></div><h1 class="h-md" style="margin-top:14px">Admin sign in</h1></div>
    ${user ? `<div class="notice warn" style="margin-bottom:14px">You are signed in as ${esc(user.email)}, which does not have admin access.</div>` : ''}
    <form class="card" style="display:grid;gap:14px" novalidate><div class="field"><label for="ae">Email</label><input class="input" id="ae" name="email" type="email" autocomplete="username" required></div>
    <div class="field"><label for="ap">Password</label><input class="input" id="ap" name="password" type="password" autocomplete="current-password" required></div>
    <div class="form-err" role="alert"></div><button class="btn btn-primary" type="submit">Sign In</button><a class="small muted" href="/" style="text-align:center">← Back to store</a></form></div>`;
  const f = qs('form', root);
  f.onsubmit = async (e) => {
    e.preventDefault(); const b = qs('button', f); setBusy(b, true);
    try { const r = await api('/account/login', { method: 'POST', body: formData(f) }); if (!['staff', 'admin'].includes(r.user.role)) throw new Error('This account does not have admin access.'); boot(); }
    catch (ex) { qs('.form-err', f).textContent = ex.message; setBusy(b, false); }
  };
}

// ---------------- shell ----------------
const NAV = [
  ['', 'Dashboard'], ['orders', 'Orders'], ['products', 'Products'], ['categories', 'Categories'], ['reviews', 'Reviews'], ['customers', 'Customers'], ['subscribers', 'Subscribers'],
  ['-', 'Store settings', true], ['content', 'Website content', true], ['coupons', 'Discount codes', true], ['zones', 'Delivery zones', true], ['payments', 'Payment methods', true], ['staff', 'Staff & roles', true], ['activity', 'Activity & emails', true],
];
function shell() {
  root.innerHTML = `<div class="adm"><aside class="adm-side" id="side"><a class="logo" href="#/">TEQNEST<small>ADMIN</small></a>
    ${NAV.filter(([, , a]) => !a || isAdmin()).map(([k, l]) => k === '-' ? `<div class="sep">${l}</div>` : `<a href="#/${k}" data-nav="${k}">${l}<span data-cnt="${k}"></span></a>`).join('')}
    <div style="margin-top:auto;padding-top:16px;display:grid;gap:6px"><a href="/" target="_blank" rel="noopener">View store ↗</a><a href="#" data-logout>Log out</a><div class="tiny muted" style="padding:6px 12px">${esc(me.email)} <span class="badge-role">${me.role}</span></div></div></aside>
    <div class="adm-main"><div class="adm-top"><button class="icon-btn adm-menu" data-menu aria-label="Menu"><span class="burger" style="display:grid"><span></span><span></span><span></span></span></button><h1 id="adm-title">Dashboard</h1></div><div class="adm-body" id="adm-body"></div></div></div>`;
  qs('[data-menu]').onclick = () => qs('#side').classList.toggle('open');
  qs('#side').addEventListener('click', (e) => { if (e.target.closest('a')) qs('#side').classList.remove('open'); });
  qs('[data-logout]').onclick = async (e) => { e.preventDefault(); await api('/account/logout', { method: 'POST' }); location.reload(); };
}
const body = () => qs('#adm-body');
const title = (t) => { qs('#adm-title').textContent = t; document.title = `${t} · TEQNEST Admin`; };

async function route() {
  const [sec = '', id, extra] = location.hash.replace(/^#\/?/, '').split('?')[0].split('/');
  qsa('[data-nav]').forEach((a) => a.classList.toggle('on', a.dataset.nav === sec));
  body().innerHTML = '<div class="skel" style="height:300px"></div>';
  scrollTo(0, 0);
  try {
    const views = { '': dashboard, orders, products, categories, reviews, customers, subscribers, content, coupons, zones, payments, staff, activity };
    if (!views[sec]) { body().innerHTML = '<div class="empty-state">Not found.</div>'; return; }
    await views[sec](id, extra);
  } catch (e) {
    if (e.status === 401) return boot();
    body().innerHTML = `<div class="empty-state"><h3>Couldn't load this page</h3><p>${esc(e.message)}</p></div>`;
  }
}

// ---------------- dashboard ----------------
async function dashboard() {
  title('Dashboard');
  const d = await api('/admin/dashboard?days=30');
  const cnt = qs('[data-cnt="orders"]'); if (cnt) cnt.innerHTML = d.pending_orders ? `<span class="cnt">${d.pending_orders}</span>` : '';
  const rc = qs('[data-cnt="reviews"]'); if (rc) rc.innerHTML = d.pending_reviews ? `<span class="cnt">${d.pending_reviews}</span>` : '';
  const max = Math.max(1, ...d.series.map((s) => s.revenue));
  const nice = Math.ceil(max / Math.pow(10, Math.floor(Math.log10(max)))) * Math.pow(10, Math.floor(Math.log10(max)));
  const k = (label, val, sub, cls = '') => `<div class="kpi ${cls}"><div class="k-label">${label}</div><div class="k-val">${val}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}</div>`;
  body().innerHTML = `
    <div class="kpis">
      ${k('Total sales', rs(d.total_sales), 'Excludes cancelled orders')}${k('Paid revenue', rs(d.paid_revenue), 'Payment marked paid')}
      ${k('Total orders', d.total_orders)}${k('Pending orders', d.pending_orders, '<a href="#/orders?status=pending" style="color:var(--cyan)">Review now</a>', d.pending_orders ? 'warn' : '')}
      ${k('In progress', d.in_progress_orders, 'Confirmed, processing, shipped')}${k('Completed', d.completed_orders, 'Delivered')}${k('Cancelled', d.cancelled_orders)}
      ${k('Payments to verify', d.awaiting_payment_verification, '', d.awaiting_payment_verification ? 'warn' : '')}
      ${k('Registered customers', d.total_customers, `${d.guest_customers} guest buyer${d.guest_customers === 1 ? '' : 's'}`)}${k('Subscribers', d.subscribers)}
    </div>
    <div class="grid2">
      <section class="card"><div class="sec-title"><h2>Revenue — last ${d.days} days</h2><span class="tiny muted">PKR, excluding cancelled orders</span></div>
        <div class="chart" role="img" aria-label="Daily revenue for the last ${d.days} days. Total ${rs(d.series.reduce((s, x) => s + x.revenue, 0))}.">
          <div class="chart-grid" aria-hidden="true">${[1, 0.5].map((f) => `<span style="top:${(1 - f) * 100}%">${rs(Math.round(nice * f))}</span>`).join('')}</div>
          ${d.series.map((s) => `<div class="bar" tabindex="0"><i style="height:${(s.revenue / nice) * 100}%"></i><span class="tip">${new Date(s.d).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })} · ${rs(s.revenue)} · ${s.orders} order${s.orders === 1 ? '' : 's'}</span></div>`).join('')}
        </div>
        <div class="chart-axis"><span>${new Date(d.series[0].d).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}</span><span>Today</span></div></section>
      <section class="card"><div class="sec-title"><h2>Best-selling products</h2></div>${d.best_sellers.length ? `<table class="table"><thead><tr><th>Product</th><th>Sold</th><th>Revenue</th></tr></thead><tbody>${d.best_sellers.map((b) => `<tr><td>${b.product_id ? `<a class="ln" href="#/products/${b.product_id}">${esc(b.name)}</a>` : esc(b.name)}</td><td>${b.qty}</td><td>${rs(b.revenue)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted small">No sales yet.</p>'}</section>
    </div>
    <div class="grid2">
      <section class="card"><div class="sec-title"><h2>Recent orders</h2><a class="link-arrow" href="#/orders">All orders ${icon('arrow')}</a></div>${ordersTable(d.recent_orders)}</section>
      <section class="card"><div class="sec-title"><h2>Low stock</h2><a class="link-arrow" href="#/products?low_stock=1">Manage ${icon('arrow')}</a></div>${d.low_stock.length ? `<table class="table"><tbody>${d.low_stock.map((p) => `<tr><td><a class="ln" href="#/products/${p.id}">${esc(p.name)}</a><div class="tiny muted">${esc(p.sku)}</div></td><td style="text-align:right">${p.stock <= 0 ? pill('cancelled', 'Out') : pill('pending', `${p.stock} left`)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted small">All in-stock products are above their low-stock threshold.</p>'}</section>
    </div>`;
}
function ordersTable(rows) {
  if (!rows.length) return '<p class="muted small">No orders yet.</p>';
  return `<div class="table-wrap"><table class="table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th></tr></thead><tbody>
    ${rows.map((o) => `<tr><td><a class="ln" href="#/orders/${o.id}">${esc(o.order_number)}</a></td><td>${esc(o.full_name)}${o.city ? `<div class="tiny muted">${esc(o.city)}</div>` : ''}</td><td>${rs(o.total)}</td><td>${pill(o.status, STATUS[o.status])}</td><td>${pill(o.payment_status, PAY[o.payment_status])}</td><td class="tiny">${dt(o.created_at)}</td></tr>`).join('')}</tbody></table></div>`;
}

// ---------------- orders ----------------
function hashParams() { return new URLSearchParams(location.hash.split('?')[1] || ''); }
async function orders(id) {
  if (id && /^\d+$/.test(id)) return orderDetail(Number(id));
  title('Orders');
  const p = hashParams();
  const r = await api(`/admin/orders?${p}`);
  body().innerHTML = `<section class="card"><form class="bar-tools" data-f>
      <div class="field grow"><label for="oq">Search</label><input class="input" id="oq" name="q" value="${esc(p.get('q') || '')}" placeholder="Order #, name, phone, email, city"></div>
      <div class="field"><label for="os">Status</label><select class="input" id="os" name="status"><option value="">All</option>${opts(STATUS, p.get('status'))}</select></div>
      <div class="field"><label for="op">Payment</label><select class="input" id="op" name="payment_status"><option value="">All</option>${opts(PAY, p.get('payment_status'))}</select></div>
      <div class="field"><label for="of">From</label><input class="input" id="of" type="date" name="from" value="${esc(p.get('from') || '')}"></div>
      <div class="field"><label for="ot">To</label><input class="input" id="ot" type="date" name="to" value="${esc(p.get('to') || '')}"></div>
      <button class="btn btn-primary btn-sm" type="submit">Filter</button><a class="btn btn-ghost btn-sm" href="#/orders">Reset</a></form></section>
    <section class="card"><div class="sec-title"><h2>${r.total} order${r.total === 1 ? '' : 's'}</h2></div>${ordersTable(r.orders)}
      ${r.pages > 1 ? `<div class="pager">${Array.from({ length: r.pages }, (_, i) => i + 1).map((n) => n === r.page ? `<span class="cur">${n}</span>` : `<a href="#/orders?${new URLSearchParams({ ...Object.fromEntries(p), page: n })}">${n}</a>`).join('')}</div>` : ''}</section>`;
  qs('[data-f]').onsubmit = (e) => { e.preventDefault(); const q = new URLSearchParams(Object.entries(formData(e.target)).filter(([, v]) => v)); location.hash = `#/orders?${q}`; };
}

async function orderDetail(id) {
  const o = await api(`/admin/orders/${id}`);
  title(`Order ${o.order_number}`);
  const waNum = (o.whatsapp || o.phone || '').replace(/^0/, '92').replace(/\D/g, '');
  const waMsg = encodeURIComponent(`Assalam-o-Alaikum ${o.full_name}, this is TEQNEST regarding your order ${o.order_number} (${rs(o.total)}). Current status: ${STATUS[o.status]}.`);
  body().innerHTML = `<a class="link-arrow" href="#/orders">${icon('left')} All orders</a>
  <div class="grid2">
    <div style="display:grid;gap:20px">
      <section class="card"><div class="sec-title"><h2>Status</h2><div>${pill(o.status, STATUS[o.status])} ${pill(o.payment_status, PAY[o.payment_status])}</div></div>
        ${o.allowed_transitions.length ? `<form data-status class="bar-tools"><div class="field"><label for="ns">Change status to</label><select class="input" id="ns" name="status">${o.allowed_transitions.map((s) => `<option value="${s}">${STATUS[s]}</option>`).join('')}</select></div>
          <div class="field grow"><label for="nn">Note (shown to customer)</label><input class="input" id="nn" name="note" maxlength="500" placeholder="Optional"></div><label class="toggle"><input type="checkbox" name="notify" checked> Email customer</label><button class="btn btn-primary btn-sm" type="submit">Update</button></form>
          <p class="tiny muted" style="margin:10px 0 0">Cancelling restores stock for items that were deducted and releases the discount code use.</p>` : '<p class="muted small">This order is closed.</p>'}
      </section>
      <section class="card"><div class="sec-title"><h2>Items</h2></div><table class="table"><tbody>${o.items.map((i) => `<tr><td>${i.image ? `<img src="${esc(safeUrl(i.image))}" alt="" width="44" height="44" style="border-radius:8px">` : ''}</td><td>${i.product_id ? `<a class="ln" href="#/products/${i.product_id}">${esc(i.name)}</a>` : esc(i.name)}<div class="tiny muted">${esc(i.sku || '')}${i.color ? ` · ${esc(i.color)}` : ''}${i.is_preorder ? ' · <strong style="color:var(--cyan)">Pre-order</strong>' : ''}</div></td><td>${rs(i.unit_price)} × ${i.qty}</td><td style="text-align:right">${rs(i.unit_price * i.qty)}</td></tr>`).join('')}</tbody></table>
        <div style="display:grid;gap:6px;margin-top:12px;max-width:360px;margin-left:auto"><div class="sum-row"><span>Subtotal</span><span>${rs(o.subtotal)}</span></div>${o.discount ? `<div class="sum-row"><span>Discount (${esc(o.coupon_code)})</span><span>−${rs(o.discount)}</span></div>` : ''}<div class="sum-row"><span>Delivery (${esc(o.zone_name)})</span><span>${rs(o.delivery_fee)}</span></div><div class="sum-row total"><span>Total</span><span>${rs(o.total)}</span></div></div></section>
      <section class="card"><div class="sec-title"><h2>History</h2></div><ol class="timeline">${o.events.map((e) => `<li class="done"><div style="font-weight:600;font-size:14px">${esc(e.message || e.type)}</div><div class="tiny muted">${dt(e.created_at)}${e.actor ? ` · ${esc(e.actor)}` : ''}${e.visible_to_customer ? '' : ' · internal'}</div></li>`).join('')}</ol></section>
    </div>
    <div style="display:grid;gap:20px;align-content:start">
      <section class="card"><div class="sec-title"><h2>Customer</h2>${o.user_id ? `<a class="ln small" href="#/customers/${o.user_id}">Profile</a>` : '<span class="tiny muted">Guest</span>'}</div>
        <dl class="dl"><dt>Name</dt><dd>${esc(o.full_name)}</dd><dt>Mobile</dt><dd><a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></dd>${o.whatsapp ? `<dt>WhatsApp</dt><dd>${esc(o.whatsapp)}</dd>` : ''}${o.email ? `<dt>Email</dt><dd>${esc(o.email)}</dd>` : ''}
        <dt>Address</dt><dd>${esc(o.address)}<br>${esc([o.area, o.city, o.postal_code].filter(Boolean).join(', '))}</dd>${o.notes ? `<dt>Notes</dt><dd>${esc(o.notes)}</dd>` : ''}<dt>Orders by phone</dt><dd>${o.customer_order_count}</dd></dl>
        <a class="btn btn-wa btn-sm" style="margin-top:14px" href="https://wa.me/${waNum}?text=${waMsg}" target="_blank" rel="noopener">Message customer on WhatsApp</a></section>
      <section class="card"><div class="sec-title"><h2>Payment</h2></div><dl class="dl"><dt>Method</dt><dd>${esc(o.payment_method_label)}</dd><dt>Reference</dt><dd>${o.payment_reference ? `<code>${esc(o.payment_reference)}</code>` : '—'}</dd></dl>
        <form data-pay class="bar-tools" style="margin-top:12px"><div class="field grow"><label for="ps">Payment status</label><select class="input" id="ps" name="payment_status">${opts(PAY, o.payment_status)}</select></div><button class="btn btn-ghost btn-sm" type="submit">Save</button></form>
        ${o.payment_status === 'awaiting_verification' ? '<p class="tiny" style="color:var(--warn);margin:10px 0 0">Check your bank/wallet statement for this reference before marking as paid.</p>' : ''}</section>
      <section class="card"><div class="sec-title"><h2>Tracking</h2></div><form data-track style="display:grid;gap:10px">
        <div class="field"><label for="tc">Courier</label><input class="input" id="tc" name="carrier" value="${esc(o.tracking?.carrier || '')}" placeholder="e.g. TCS, Leopards, M&P"></div>
        <div class="field"><label for="tn">Tracking number</label><input class="input" id="tn" name="number" value="${esc(o.tracking?.number || '')}"></div>
        <div class="field"><label for="tu">Tracking URL (optional)</label><input class="input" id="tu" name="url" value="${esc(o.tracking?.url || '')}" placeholder="https://"></div>
        <button class="btn btn-ghost btn-sm" type="submit">Save tracking</button></form></section>
      <section class="card"><div class="sec-title"><h2>Internal notes</h2></div><form data-notes style="display:grid;gap:10px"><textarea class="input" name="admin_notes" rows="3" aria-label="Internal notes">${esc(o.admin_notes || '')}</textarea><button class="btn btn-ghost btn-sm" type="submit">Save notes</button></form></section>
    </div></div>`;
  const post = (sel, path, transform = (d) => d) => { const f = qs(sel); if (!f) return; f.onsubmit = async (e) => { e.preventDefault(); const b = qs('button[type=submit]', f); setBusy(b, true); try { await api(`/admin/orders/${id}/${path}`, { method: 'POST', body: transform(formData(f)) }); toast('Saved', 'ok'); orderDetail(id); } catch (ex) { toast(ex.message, 'err'); setBusy(b, false); } }; };
  post('[data-status]', 'status', (d) => { if (d.status === 'cancelled' && !confirm('Cancel this order? Stock will be restored.')) throw new Error('Not cancelled'); return d; });
  post('[data-pay]', 'payment'); post('[data-track]', 'tracking'); post('[data-notes]', 'notes');
}

// ---------------- products ----------------
async function products(id) {
  const pid = id?.split('?')[0];
  if (pid === 'new' || /^\d+$/.test(pid || '')) return productForm(pid === 'new' ? null : Number(pid));
  title('Products');
  const p = hashParams();
  const [list, cats] = await Promise.all([api(`/admin/products?${p}`), api('/admin/categories')]);
  body().innerHTML = `<section class="card"><form class="bar-tools" data-f>
      <div class="field grow"><label for="pq">Search</label><input class="input" id="pq" name="q" value="${esc(p.get('q') || '')}" placeholder="Name or SKU"></div>
      <div class="field"><label for="pc">Category</label><select class="input" id="pc" name="category"><option value="">All</option>${cats.map((c) => `<option value="${c.id}" ${String(c.id) === p.get('category') ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
      <div class="field"><label for="pa">Availability</label><select class="input" id="pa" name="availability"><option value="">All</option>${opts(AV, p.get('availability'))}</select></div>
      <label class="toggle" style="height:42px"><input type="checkbox" name="low_stock" ${p.get('low_stock') ? 'checked' : ''}> Low stock</label>
      <button class="btn btn-ghost btn-sm" type="submit">Filter</button><a class="btn btn-primary btn-sm" href="#/products/new">${icon('plus').replace('<svg', '<svg width="16"')} Add product</a></form></section>
    <section class="card"><div class="sec-title"><h2>${list.length} product${list.length === 1 ? '' : 's'}</h2><span class="tiny muted">Stock, availability and flags save instantly</span></div>
    <div class="table-wrap"><table class="table"><thead><tr><th></th><th>Product</th><th>Price</th><th>Stock</th><th>Availability</th><th>Featured</th><th>New</th><th>Trending</th><th>Visible</th><th></th></tr></thead><tbody>
    ${list.map((x) => `<tr data-id="${x.id}"><td><img src="${esc(safeUrl(x.images[0] || ''))}" alt="" width="44" height="44" style="border-radius:8px;background:var(--bg-3)"></td>
      <td><a class="ln" href="#/products/${x.id}">${esc(x.name)}</a><div class="tiny muted">${esc(x.sku)} · ${esc(x.category_name || 'No category')} · ${x.sold} sold</div></td>
      <td>${x.price == null ? '<span class="muted">—</span>' : x.sale_price ? `${rs(x.sale_price)}<div class="tiny muted" style="text-decoration:line-through">${rs(x.price)}</div>` : rs(x.price)}</td>
      <td><input class="input inline-num" type="number" min="0" value="${x.stock}" data-k="stock" aria-label="Stock for ${esc(x.name)}" ${x.availability === 'in_stock' && x.stock <= x.low_stock_threshold ? 'style="border-color:var(--warn)"' : ''}></td>
      <td><select class="input inline-sel" data-k="availability" aria-label="Availability for ${esc(x.name)}">${opts(AV, x.availability)}</select></td>
      ${['featured', 'new_arrival', 'trending', 'active'].map((f) => `<td><input type="checkbox" data-k="${f}" ${x[f] ? 'checked' : ''} aria-label="${f}" style="accent-color:var(--blue);width:18px;height:18px"></td>`).join('')}
      <td style="white-space:nowrap"><a class="mini-btn" style="display:inline-grid;place-items:center;height:32px" href="/product/${esc(x.slug)}" target="_blank" rel="noopener">View</a>${isAdmin() ? ` <button class="mini-btn" style="height:32px" data-del>Delete</button>` : ''}</td></tr>`).join('')}
    </tbody></table></div></section>`;
  qs('[data-f]').onsubmit = (e) => { e.preventDefault(); const d = formData(e.target); const q = new URLSearchParams(Object.entries(d).filter(([, v]) => v && v !== false).map(([k, v]) => [k, v === true ? '1' : v])); location.hash = `#/products?${q}`; };
  body().addEventListener('change', async (e) => {
    const el = e.target.closest('[data-k]'); if (!el) return;
    const tr = el.closest('tr'); const k = el.dataset.k;
    const v = el.type === 'checkbox' ? el.checked : k === 'stock' ? Number(el.value) : el.value;
    try { await api(`/admin/products/${tr.dataset.id}`, { method: 'PATCH', body: { [k]: v } }); toast('Saved', 'ok'); }
    catch (ex) { toast(ex.message, 'err'); products(id); }
  });
  body().addEventListener('click', async (e) => {
    if (!e.target.closest('[data-del]')) return;
    const tr = e.target.closest('tr');
    if (!confirm('Delete this product? Products with orders are hidden instead of deleted.')) return;
    try { const r = await api(`/admin/products/${tr.dataset.id}`, { method: 'DELETE' }); toast(r.message || 'Deleted', 'ok'); products(id); } catch (ex) { toast(ex.message, 'err'); }
  });
}

async function upload(kind, files) {
  const fd = new FormData(); [...files].forEach((f) => fd.append('files', f));
  const res = await fetch(`/api/admin/upload/${kind}`, { method: 'POST', body: fd, headers: { 'X-Requested-With': 'teqnest' }, credentials: 'same-origin' });
  const d = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(d.error || 'Upload failed');
  return d.urls;
}

async function productForm(id) {
  const [p, cats] = await Promise.all([id ? api(`/admin/products/${id}`) : Promise.resolve({ availability: 'in_stock', stock: 0, low_stock_threshold: 5, active: 1, images: [], videos: [], colors: [], specs: [], features: [], in_box: [] }), api('/admin/categories')]);
  title(id ? `Edit: ${p.name}` : 'Add product');
  let images = [...p.images]; let videos = [...p.videos];
  const f = (name, label, attrs = '', val = p[name] ?? '', hint = '') => `<div class="field"><label for="f-${name}">${label}</label><input class="input" id="f-${name}" name="${name}" value="${esc(val)}" ${attrs}>${hint ? `<span class="hint">${hint}</span>` : ''}</div>`;
  body().innerHTML = `<a class="link-arrow" href="#/products">${icon('left')} All products</a>
  <form data-pf style="display:grid;gap:20px" novalidate>
    <div class="grid2">
      <div style="display:grid;gap:20px">
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Basics</h2>
          ${f('name', 'Product name *', 'required maxlength="160"')}
          <div class="form-grid two">${f('sku', 'SKU *', 'required maxlength="60"')}${f('slug', 'URL slug', 'maxlength="90"', p.slug || '', 'Leave blank to generate from the name')}</div>
          <div class="field"><label for="f-cat">Category</label><select class="input" id="f-cat" name="category_id"><option value="">— None —</option>${cats.map((c) => `<option value="${c.id}" ${c.id === p.category_id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
          ${f('short_description', 'Short description', 'maxlength="300"', p.short_description || '', 'Shown on product cards and as default SEO description')}
          <div class="field"><label for="f-desc">Full description</label><textarea class="input" id="f-desc" name="description" rows="7">${esc(p.description || '')}</textarea></div></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Images</h2><p class="hint-box" style="margin:0">First image is the main image. JPG, PNG, WebP or AVIF, up to 8 MB each. Use square images (at least 1200×1200) for the best look.</p><div class="thumbs" data-imgs></div></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Videos & 3D</h2>
          <div class="rows" data-vids></div>
          <div class="bar-tools"><input class="input grow" data-vurl placeholder="YouTube/Vimeo link or https:// video URL"><button type="button" class="btn btn-ghost btn-sm" data-vadd>Add link</button><label class="btn btn-ghost btn-sm">Upload MP4/WebM<input type="file" accept="video/mp4,video/webm" hidden data-vup></label></div>
          <div class="bar-tools">${f('model_url', '3D model (.glb, optional)', 'placeholder="/uploads/… .glb"', p.model_url || '')}<label class="btn btn-ghost btn-sm">Upload .glb<input type="file" accept=".glb" hidden data-mup></label></div></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Specifications</h2><div class="rows" data-specs></div><button type="button" class="btn btn-ghost btn-sm" style="justify-self:start" data-add-spec>+ Add specification</button></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Features & box contents</h2>
          <div class="field"><label for="f-feat">Key features (one per line)</label><textarea class="input" id="f-feat" name="features" rows="4">${esc(p.features.join('\n'))}</textarea></div>
          <div class="field"><label for="f-box">What's in the box (one per line)</label><textarea class="input" id="f-box" name="in_box" rows="4">${esc(p.in_box.join('\n'))}</textarea></div></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">SEO</h2>${f('seo_title', 'SEO title', 'maxlength="70"', p.seo_title || '', 'Up to 70 characters. Defaults to “Product name | TEQNEST”.')}${f('seo_description', 'SEO description', 'maxlength="170"', p.seo_description || '', 'Up to 170 characters.')}</section>
      </div>
      <div style="display:grid;gap:20px;align-content:start">
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Pricing (PKR)</h2>
          <div class="form-grid two">${f('price', 'Regular price', 'type="number" min="0" inputmode="numeric"', p.price ?? '')}${f('sale_price', 'Sale price', 'type="number" min="0" inputmode="numeric"', p.sale_price ?? '', 'Leave blank for no discount')}</div>
          <p class="hint-box" style="margin:0">Products that are In Stock or Pre-order need a price. Coming Soon / On Request products can be listed without one.</p></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Inventory & availability</h2>
          <div class="field"><label for="f-av">Availability</label><select class="input" id="f-av" name="availability">${opts(AV, p.availability)}</select>
            <span class="hint">Coming Soon, Available on Request and Out of Stock disable Add to Cart and show a WhatsApp inquiry button. Switch to In Stock when inventory arrives.</span></div>
          <div class="form-grid two">${f('stock', 'Stock quantity', 'type="number" min="0"', p.stock)}${f('low_stock_threshold', 'Low-stock alert at', 'type="number" min="0"', p.low_stock_threshold)}</div>
          <label class="toggle"><input type="checkbox" name="active" ${p.active ? 'checked' : ''}> Visible in store</label>
          <label class="toggle"><input type="checkbox" name="featured" ${p.featured ? 'checked' : ''}> Featured</label>
          <label class="toggle"><input type="checkbox" name="new_arrival" ${p.new_arrival ? 'checked' : ''}> New arrival</label>
          <label class="toggle"><input type="checkbox" name="trending" ${p.trending ? 'checked' : ''}> Trending (homepage)</label></section>
        <section class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Colours</h2><div class="rows" data-colors></div><button type="button" class="btn btn-ghost btn-sm" style="justify-self:start" data-add-color>+ Add colour</button></section>
      </div>
    </div>
    <div class="form-err" role="alert"></div>
    <div class="form-actions">${id ? `<a class="btn btn-ghost" href="/product/${esc(p.slug)}" target="_blank" rel="noopener">View in store</a>` : ''}<button class="btn btn-primary" type="submit">${id ? 'Save changes' : 'Create product'}</button></div>
  </form>`;
  const form = qs('[data-pf]');
  // images
  const renderImgs = () => {
    qs('[data-imgs]').innerHTML = images.map((u, i) => `<div class="th ${i === 0 ? 'first' : ''}"><img src="${esc(safeUrl(u))}" alt=""><button type="button" class="x" data-rm="${i}" aria-label="Remove image">×</button><div class="mv">${i > 0 ? `<button type="button" data-mv="${i}" data-d="-1" aria-label="Move left">←</button>` : ''}${i < images.length - 1 ? `<button type="button" data-mv="${i}" data-d="1" aria-label="Move right">→</button>` : ''}</div></div>`).join('') +
      `<label class="up">+ Upload<br>images<input type="file" accept="image/*" multiple hidden data-iup></label>`;
  };
  renderImgs();
  qs('[data-imgs]').addEventListener('click', (e) => {
    const rm = e.target.closest('[data-rm]'); const mv = e.target.closest('[data-mv]');
    if (rm) { images.splice(Number(rm.dataset.rm), 1); renderImgs(); }
    if (mv) { const i = Number(mv.dataset.mv); const j = i + Number(mv.dataset.d); [images[i], images[j]] = [images[j], images[i]]; renderImgs(); }
  });
  qs('[data-imgs]').addEventListener('change', async (e) => {
    if (!e.target.matches('[data-iup]')) return;
    try { toast('Uploading…'); images.push(...await upload('image', e.target.files)); renderImgs(); toast('Uploaded', 'ok'); } catch (ex) { toast(ex.message, 'err'); }
  });
  // videos
  const renderVids = () => { qs('[data-vids]').innerHTML = videos.map((v, i) => `<div class="row one"><input class="input" value="${esc(v)}" readonly aria-label="Video ${i + 1}"><button type="button" class="mini-btn" data-vrm="${i}">Remove</button></div>`).join('') || '<span class="hint-box">No videos.</span>'; };
  renderVids();
  qs('[data-vids]').onclick = (e) => { const b = e.target.closest('[data-vrm]'); if (b) { videos.splice(Number(b.dataset.vrm), 1); renderVids(); } };
  qs('[data-vadd]').onclick = () => { const u = qs('[data-vurl]').value.trim(); if (!/^https:\/\//.test(u)) return toast('Enter an https:// link', 'err'); videos.push(u); qs('[data-vurl]').value = ''; renderVids(); };
  qs('[data-vup]').onchange = async (e) => { try { toast('Uploading video…'); videos.push(...await upload('video', e.target.files)); renderVids(); toast('Uploaded', 'ok'); } catch (ex) { toast(ex.message, 'err'); } };
  qs('[data-mup]').onchange = async (e) => { try { toast('Uploading model…'); const [u] = await upload('model', e.target.files); form.model_url.value = u; toast('Uploaded', 'ok'); } catch (ex) { toast(ex.message, 'err'); } };
  // specs & colours
  const specRow = (s = {}) => `<div class="row"><input class="input" data-sl placeholder="Label (e.g. Bluetooth)" value="${esc(s.label || '')}"><input class="input" data-sv placeholder="Value (e.g. 5.3)" value="${esc(s.value || '')}"><button type="button" class="mini-btn" data-row-rm>Remove</button></div>`;
  const colorRow = (c = {}) => `<div class="row color"><input class="input" data-cn placeholder="Colour name" value="${esc(c.name || '')}"><input type="color" class="input" data-ch value="${esc(c.hex || '#2b313d')}" aria-label="Colour swatch"><button type="button" class="mini-btn" data-row-rm>Remove</button></div>`;
  qs('[data-specs]').innerHTML = p.specs.map(specRow).join('');
  qs('[data-colors]').innerHTML = p.colors.map(colorRow).join('');
  qs('[data-add-spec]').onclick = () => qs('[data-specs]').insertAdjacentHTML('beforeend', specRow());
  qs('[data-add-color]').onclick = () => qs('[data-colors]').insertAdjacentHTML('beforeend', colorRow());
  form.addEventListener('click', (e) => { if (e.target.closest('[data-row-rm]')) e.target.closest('.row').remove(); });

  form.onsubmit = async (e) => {
    e.preventDefault(); const b = qs('[type=submit]', form); const err = qs('.form-err', form); err.textContent = '';
    const d = formData(form);
    d.images = images; d.videos = videos;
    d.specs = qsa('[data-specs] .row').map((r) => ({ label: qs('[data-sl]', r).value, value: qs('[data-sv]', r).value })).filter((s) => s.label && s.value);
    d.colors = qsa('[data-colors] .row').map((r) => ({ name: qs('[data-cn]', r).value, hex: qs('[data-ch]', r).value })).filter((c) => c.name);
    d.features = d.features.split('\n'); d.in_box = d.in_box.split('\n');
    setBusy(b, true);
    try { const r = await api(`/admin/products${id ? '/' + id : ''}`, { method: id ? 'PUT' : 'POST', body: d }); toast('Product saved', 'ok'); location.hash = `#/products/${r.id}`; if (id) productForm(id); }
    catch (ex) { err.textContent = ex.message; setBusy(b, false); err.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  };
}

// ---------------- generic CRUD list helper ----------------
function crudPage({ heading, items, columns, formFields, endpoint, canDelete = true, emptyText, intro = '' }) {
  body().innerHTML = `${intro}<section class="card"><div class="sec-title"><h2>${heading}</h2><button class="btn btn-primary btn-sm" data-new>${icon('plus').replace('<svg', '<svg width="16"')} Add</button></div>
    <div data-form></div>
    ${items.length ? `<div class="table-wrap"><table class="table"><thead><tr>${columns.map((c) => `<th>${c[0]}</th>`).join('')}<th></th></tr></thead><tbody>${items.map((it) => `<tr data-id="${it.id}">${columns.map((c) => `<td>${c[1](it)}</td>`).join('')}<td style="white-space:nowrap;text-align:right"><button class="mini-btn" style="height:32px" data-edit>Edit</button>${canDelete ? ` <button class="mini-btn" style="height:32px" data-del>Delete</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : `<p class="muted small">${emptyText}</p>`}</section>`;
  const host = qs('[data-form]');
  const open = (it = {}) => {
    host.innerHTML = `<form class="card" style="display:grid;gap:14px;margin-bottom:20px;background:var(--bg-3)" novalidate><div class="form-grid two">${formFields(it)}</div><div class="form-err" role="alert"></div><div style="display:flex;gap:8px"><button class="btn btn-primary btn-sm" type="submit">Save</button><button class="btn btn-ghost btn-sm" type="button" data-cancel>Cancel</button></div></form>`;
    const f = qs('form', host);
    qs('[data-cancel]', f).onclick = () => { host.innerHTML = ''; };
    bindImageField(f);
    f.onsubmit = async (e) => {
      e.preventDefault(); const b = qs('[type=submit]', f); setBusy(b, true);
      try { await api(`${endpoint}${it.id ? '/' + it.id : ''}`, { method: it.id ? 'PUT' : 'POST', body: formData(f) }); toast('Saved', 'ok'); route(); }
      catch (ex) { qs('.form-err', f).textContent = ex.message; setBusy(b, false); }
    };
    f.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  qs('[data-new]').onclick = () => open();
  body().onclick = async (e) => {
    const tr = e.target.closest('tr[data-id]'); if (!tr) return;
    const it = items.find((x) => String(x.id) === tr.dataset.id);
    if (e.target.closest('[data-edit]')) open(it);
    if (e.target.closest('[data-del]') && confirm('Delete this item?')) { try { const r = await api(`${endpoint}/${it.id}`, { method: 'DELETE' }); toast(r.message || 'Deleted', 'ok'); route(); } catch (ex) { toast(ex.message, 'err'); } }
  };
}
const inp = (name, label, val = '', attrs = '', hint = '') => `<div class="field ${attrs.includes('span-2') ? 'span-2' : ''}"><label for="i-${name}">${label}</label><input class="input" id="i-${name}" name="${name}" value="${esc(val ?? '')}" ${attrs.replace('span-2', '')}>${hint ? `<span class="hint">${hint}</span>` : ''}</div>`;
const chk = (name, label, on) => `<label class="toggle"><input type="checkbox" name="${name}" ${on ? 'checked' : ''}> ${label}</label>`;
const imgField = (name, label, val = '') => `<div class="field span-2"><label for="i-${name}">${label}</label><div class="bar-tools"><input class="input grow" id="i-${name}" name="${name}" value="${esc(val || '')}" placeholder="/uploads/… or https://"><label class="btn btn-ghost btn-sm">Upload<input type="file" accept="image/*" hidden data-img-for="${name}"></label></div></div>`;
function bindImageField(form) {
  qsa('[data-img-for]', form).forEach((inpEl) => inpEl.onchange = async () => {
    try { toast('Uploading…'); const [u] = await upload('image', inpEl.files); form[inpEl.dataset.imgFor].value = u; toast('Uploaded', 'ok'); } catch (ex) { toast(ex.message, 'err'); }
  });
}

async function categories() {
  title('Categories');
  const items = await api('/admin/categories');
  crudPage({
    heading: 'Categories', items, endpoint: '/admin/categories', canDelete: isAdmin(), emptyText: 'No categories yet.',
    columns: [['', (c) => c.image ? `<img src="${esc(safeUrl(c.image))}" alt="" width="40" height="40" style="border-radius:8px">` : ''], ['Name', (c) => `<strong>${esc(c.name)}</strong><div class="tiny muted">/shop/${esc(c.slug)}</div>`], ['Products', (c) => c.product_count], ['Order', (c) => c.sort], ['Homepage', (c) => c.show_on_home ? 'Yes' : 'No'], ['Menu', (c) => c.show_in_nav ? 'Yes' : 'No'], ['Visible', (c) => c.active ? 'Yes' : 'No']],
    formFields: (c) => `${inp('name', 'Name *', c.name, 'required')}${inp('slug', 'URL slug', c.slug, '', 'Blank = generated from name')}${inp('short_name', 'Short label', c.short_name)}${inp('sort', 'Display order', c.sort ?? 0, 'type="number"')}${inp('description', 'Short description', c.description, 'span-2 maxlength="300"')}${imgField('image', 'Card image', c.image)}
      <div style="display:flex;gap:18px;flex-wrap:wrap" class="span-2">${chk('show_on_home', 'Show on homepage', c.id ? c.show_on_home : 1)}${chk('show_in_nav', 'Show in menu', c.id ? c.show_in_nav : 1)}${chk('active', 'Visible', c.id ? c.active : 1)}</div>`,
  });
}

async function coupons() {
  title('Discount codes');
  const items = await api('/admin/coupons');
  crudPage({
    heading: 'Discount codes', items, endpoint: '/admin/coupons', emptyText: 'No discount codes yet.',
    columns: [['Code', (c) => `<code style="font-weight:700">${esc(c.code)}</code>`], ['Discount', (c) => c.type === 'percent' ? `${c.value}%${c.max_discount ? ` (max ${rs(c.max_discount)})` : ''}` : rs(c.value)], ['Min. order', (c) => c.min_subtotal ? rs(c.min_subtotal) : '—'], ['Used', (c) => `${c.used_count}${c.usage_limit ? ` / ${c.usage_limit}` : ''}`], ['Expires', (c) => c.expires_at ? dt(c.expires_at) : 'Never'], ['Status', (c) => !c.active ? pill('cancelled', 'Inactive') : c.expires_at && new Date(c.expires_at) < new Date() ? pill('cancelled', 'Expired') : pill('delivered', 'Active')]],
    formFields: (c) => `${inp('code', 'Code *', c.code, 'required style="text-transform:uppercase"')}<div class="field"><label for="i-type">Type</label><select class="input" id="i-type" name="type"><option value="percent" ${c.type === 'percent' ? 'selected' : ''}>Percentage (%)</option><option value="fixed" ${c.type === 'fixed' ? 'selected' : ''}>Fixed amount (Rs)</option></select></div>
      ${inp('value', 'Value *', c.value, 'type="number" min="1" required')}${inp('max_discount', 'Max discount (Rs, % only)', c.max_discount, 'type="number" min="1"')}${inp('min_subtotal', 'Minimum order (Rs)', c.min_subtotal ?? 0, 'type="number" min="0"')}${inp('usage_limit', 'Usage limit', c.usage_limit, 'type="number" min="1"', 'Blank = unlimited')}
      ${inp('expires_at', 'Expiry date', c.expires_at ? c.expires_at.slice(0, 10) : '', 'type="date"', 'Valid until end of day (PKT). Blank = no expiry')}<div class="field" style="align-self:end">${chk('active', 'Active', c.id ? c.active : 1)}</div>`,
  });
}

async function zones() {
  title('Delivery zones');
  const items = await api('/admin/zones');
  crudPage({
    heading: 'Delivery zones', items, endpoint: '/admin/zones', emptyText: 'No delivery zones. Customers cannot check out until at least one active zone exists.',
    intro: '<div class="notice">Customers choose a zone at checkout. Charges shown here are what customers pay. Do not promise delivery times you cannot guarantee — use the description for general information only.</div>',
    columns: [['Zone', (z) => `<strong>${esc(z.name)}</strong><div class="tiny muted">${esc(z.description || '')}</div>`], ['Fee', (z) => rs(z.fee)], ['Free over', (z) => z.free_threshold != null ? rs(z.free_threshold) : '—'], ['COD', (z) => z.cod_available ? 'Yes' : 'No'], ['Order', (z) => z.sort], ['Status', (z) => z.active ? pill('delivered', 'Active') : pill('cancelled', 'Inactive')]],
    formFields: (z) => `${inp('name', 'Zone name *', z.name, 'required')}${inp('description', 'Description', z.description)}${inp('fee', 'Delivery fee (Rs)', z.fee ?? 0, 'type="number" min="0"')}${inp('free_threshold', 'Free delivery over (Rs)', z.free_threshold, 'type="number" min="0"', 'Blank = never free')}${inp('sort', 'Display order', z.sort ?? 0, 'type="number"')}
      <div style="display:flex;gap:18px;align-self:end">${chk('cod_available', 'Cash on Delivery available', z.id ? z.cod_available : 1)}${chk('active', 'Active', z.id ? z.active : 1)}</div>`,
  });
}

// ---------------- reviews ----------------
async function reviews() {
  title('Reviews');
  const status = hashParams().get('status') || 'pending';
  const items = await api(`/admin/reviews?status=${status}`);
  body().innerHTML = `<div class="notice">Only customers with a delivered order for the product can submit reviews. Approve genuine reviews to show them on the product page and homepage.</div>
    <section class="card"><div class="sec-title"><div style="display:flex;gap:6px">${['pending', 'approved', 'rejected'].map((s) => `<a class="btn btn-sm ${s === status ? 'btn-primary' : 'btn-ghost'}" href="#/reviews?status=${s}">${s}</a>`).join('')}</div></div>
    ${items.length ? items.map((r) => `<div class="card" style="margin-bottom:12px;background:var(--bg-3)" data-id="${r.id}"><div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><div><strong>${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</strong> · <a class="ln" href="/product/${esc(r.slug)}" target="_blank" rel="noopener" style="color:var(--cyan)">${esc(r.product)}</a></div><span class="tiny muted">${esc(r.name)} (${esc(r.email)}) · order ${esc(r.order_number)} · ${dt(r.created_at)}</span></div>
      ${r.title ? `<h3 style="font-size:16px;margin-top:10px">${esc(r.title)}</h3>` : ''}<p style="margin:8px 0 14px">${esc(r.body)}</p>
      <div style="display:flex;gap:8px">${status !== 'approved' ? '<button class="btn btn-primary btn-sm" data-s="approved">Approve</button>' : ''}${status !== 'rejected' ? '<button class="btn btn-ghost btn-sm" data-s="rejected">Reject</button>' : ''}${isAdmin() ? '<button class="mini-btn" data-del>Delete</button>' : ''}</div></div>`).join('') : `<p class="muted small">No ${status} reviews.</p>`}</section>`;
  body().onclick = async (e) => {
    const card = e.target.closest('[data-id]'); if (!card) return;
    const s = e.target.closest('[data-s]');
    try {
      if (s) { await api(`/admin/reviews/${card.dataset.id}`, { method: 'POST', body: { status: s.dataset.s } }); toast('Updated', 'ok'); route(); }
      if (e.target.closest('[data-del]') && confirm('Delete this review permanently?')) { await api(`/admin/reviews/${card.dataset.id}`, { method: 'DELETE' }); route(); }
    } catch (ex) { toast(ex.message, 'err'); }
  };
}

// ---------------- customers ----------------
async function customers(id) {
  if (id && /^\d+$/.test(id)) {
    const c = await api(`/admin/customers/${id}`);
    title(c.name);
    body().innerHTML = `<a class="link-arrow" href="#/customers">${icon('left')} All customers</a><div class="grid2">
      <section class="card"><div class="sec-title"><h2>Orders (${c.orders.length})</h2></div>${ordersTable(c.orders.map((o) => ({ ...o, full_name: c.name })))}</section>
      <div style="display:grid;gap:20px;align-content:start"><section class="card"><div class="sec-title"><h2>Profile</h2>${c.active ? pill('delivered', 'Active') : pill('cancelled', 'Disabled')}</div><dl class="dl"><dt>Email</dt><dd>${esc(c.email)}</dd><dt>Mobile</dt><dd>${esc(c.phone || '—')}</dd><dt>Joined</dt><dd>${dt(c.created_at)}</dd><dt>Last login</dt><dd>${dt(c.last_login_at)}</dd><dt>Wishlist</dt><dd>${c.wishlist.map((w) => esc(w.name)).join(', ') || '—'}</dd><dt>Reviews</dt><dd>${c.reviews.length}</dd></dl>
        ${isAdmin() ? `<button class="btn btn-ghost btn-sm" style="margin-top:14px" data-toggle>${c.active ? 'Disable account' : 'Enable account'}</button>` : ''}</section>
      <section class="card"><div class="sec-title"><h2>Addresses</h2></div>${c.addresses.map((a) => `<p class="small" style="margin:0 0 10px">${esc(a.label || '')}: ${esc(a.address)}, ${esc(a.city)}</p>`).join('') || '<p class="muted small">None saved.</p>'}</section></div></div>`;
    const t = qs('[data-toggle]'); if (t) t.onclick = async () => { await api(`/admin/customers/${id}`, { method: 'PATCH', body: { active: !c.active } }); toast('Updated', 'ok'); route(); };
    return;
  }
  title('Customers');
  const q = hashParams().get('q') || '';
  const list = await api(`/admin/customers?q=${encodeURIComponent(q)}`);
  body().innerHTML = `<section class="card"><form class="bar-tools" data-f><div class="field grow"><label for="cq">Search</label><input class="input" id="cq" name="q" value="${esc(q)}" placeholder="Name, email or phone"></div><button class="btn btn-ghost btn-sm">Search</button></form></section>
    <section class="card"><div class="sec-title"><h2>${list.length} registered customer${list.length === 1 ? '' : 's'}</h2><span class="tiny muted">Guest buyers appear in Orders</span></div>
    ${list.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Mobile</th><th>Orders</th><th>Spent</th><th>Joined</th></tr></thead><tbody>${list.map((c) => `<tr><td><a class="ln" href="#/customers/${c.id}">${esc(c.name)}</a>${c.active ? '' : ' ' + pill('cancelled', 'Disabled')}</td><td>${esc(c.email)}</td><td>${esc(c.phone || '—')}</td><td>${c.orders}</td><td>${rs(c.spent)}</td><td class="tiny">${dt(c.created_at)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small">No customers found.</p>'}</section>`;
  qs('[data-f]').onsubmit = (e) => { e.preventDefault(); location.hash = `#/customers?q=${encodeURIComponent(e.target.q.value)}`; };
}

async function subscribers() {
  title('Newsletter subscribers');
  const list = await api('/admin/subscribers');
  body().innerHTML = `<section class="card"><div class="sec-title"><h2>${list.length} subscriber${list.length === 1 ? '' : 's'}</h2><a class="btn btn-ghost btn-sm" href="/api/admin/subscribers.csv" download>Export CSV</a></div>
    ${list.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>Email</th><th>Subscribed</th><th></th></tr></thead><tbody>${list.map((s) => `<tr data-id="${s.id}"><td>${esc(s.email)}</td><td class="tiny">${dt(s.created_at)}</td><td style="text-align:right">${isAdmin() ? '<button class="mini-btn" style="height:32px" data-del>Remove</button>' : ''}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small">No subscribers yet.</p>'}</section>`;
  body().onclick = async (e) => { const tr = e.target.closest('tr[data-id]'); if (tr && e.target.closest('[data-del]') && confirm('Remove this subscriber?')) { await api(`/admin/subscribers/${tr.dataset.id}`, { method: 'DELETE' }); route(); } };
}

// ---------------- website content (settings) ----------------
async function content() {
  title('Website content');
  const s = await api('/admin/settings');
  const sec = (key, heading, inner, note = '') => `<form class="card" data-key="${key}" style="display:grid;gap:14px" novalidate><div class="sec-title"><h2>${heading}</h2><button class="btn btn-primary btn-sm" type="submit">Save</button></div>${note ? `<p class="hint-box" style="margin:0">${note}</p>` : ''}${inner}</form>`;
  const ta = (name, label, val, rows = 3, hint = '') => `<div class="field span-2"><label for="t-${name}">${label}</label><textarea class="input" id="t-${name}" name="${name}" rows="${rows}">${esc(val ?? '')}</textarea>${hint ? `<span class="hint">${hint}</span>` : ''}</div>`;
  const b = s.brand || {}; const h = s.hero || {}; const pr = s.promo || {}; const st = s.brand_story || {}; const hs = s.home_sections || {}; const c = s.contact || {}; const so = s.social || {}; const ft = s.footer || {}; const pg = s.pages || {}; const an = s.announcements || {};
  body().innerHTML = `
    ${sec('brand', 'Brand', `<div class="form-grid two">${inp('name', 'Brand name', b.name)}${inp('tagline', 'Tagline', b.tagline)}${imgField('logo_url', 'Official logo (SVG/PNG, transparent background)', b.logo_url)}${ta('meta_description', 'Default SEO description', b.meta_description, 2)}${chk('demo_notice', 'Show “Demo catalog” notice on storefront (turn off once real products are added)', b.demo_notice)}</div>`)}
    ${sec('announcements', 'Announcement bar', `${chk('enabled', 'Show announcement bar', an.enabled)}${ta('messages', 'Messages (one per line)', (an.messages || []).join('\n'), 3)}${inp('interval', 'Rotate every (ms)', an.interval || 4500, 'type="number" min="2500"')}`)}
    ${sec('hero', 'Homepage hero', `<div class="form-grid two">${inp('eyebrow', 'Small label', h.eyebrow)}<div></div>${inp('line1', 'Heading line 1', h.line1)}${inp('line2', 'Heading line 2 (gradient)', h.line2)}${ta('description', 'Description', h.description, 2)}${inp('primary_label', 'Primary button text', h.primary?.label)}${inp('primary_url', 'Primary button link', h.primary?.url)}${inp('secondary_label', 'Secondary button text', h.secondary?.label)}${inp('secondary_url', 'Secondary button link', h.secondary?.url)}${chk('enable_3d', 'Enable 3D product scene (falls back to images on unsupported devices)', h.enable_3d !== false)}</div>`)}
    ${sec('promo', 'Promotional banner', `<div class="form-grid two">${chk('enabled', 'Show promotional banner', pr.enabled)}<div></div>${inp('eyebrow', 'Small label', pr.eyebrow)}${inp('heading', 'Heading', pr.heading)}${ta('text', 'Text', pr.text, 2)}${inp('cta_label', 'Button text', pr.cta_label)}${inp('cta_url', 'Button link', pr.cta_url)}${imgField('image', 'Image', pr.image)}</div>`)}
    ${sec('brand_story', 'Brand experience section', `<div class="form-grid two">${inp('heading', 'Heading', st.heading, 'span-2')}${ta('paragraphs', 'Paragraphs (blank line between paragraphs)', (st.paragraphs || []).join('\n\n'), 5)}${ta('points', 'Highlights (one per line)', (st.points || []).join('\n'), 3)}${imgField('image', 'Image', st.image)}${inp('cta_label', 'Button text', st.cta?.label)}${inp('cta_url', 'Button link', st.cta?.url)}</div>`)}
    ${sec('why_choose', 'Why choose TEQNEST — feature cards', (s.why_choose || []).map((w, i) => `<div class="form-grid two" style="padding-bottom:12px;border-bottom:1px solid var(--line)">${inp(`title_${i}`, `Card ${i + 1} title`, w.title)}<div class="field"><label for="i-icon_${i}">Icon</label><select class="input" id="i-icon_${i}" name="icon_${i}">${['select', 'cart', 'support', 'truck'].map((x) => `<option ${x === w.icon ? 'selected' : ''}>${x}</option>`).join('')}</select></div>${ta(`text_${i}`, 'Text', w.text, 2)}</div>`).join(''), 'Avoid unsupported claims about warranties, authenticity or delivery times.')}
    ${sec('home_sections', 'Homepage section headings', `<div class="form-grid two">${[['categories_heading', 'Categories'], ['trending_heading', 'Trending'], ['new_heading', 'New arrivals'], ['why_heading', 'Why choose'], ['reviews_heading', 'Reviews'], ['newsletter_heading', 'Newsletter']].map(([k, l]) => inp(k, l, hs[k])).join('')}${ta('newsletter_text', 'Newsletter text', hs.newsletter_text, 2)}</div>`)}
    ${sec('contact', 'Contact & WhatsApp', `<div class="form-grid two">${inp('whatsapp', 'WhatsApp number (international format)', c.whatsapp, 'placeholder="923001234567"', 'Used for the floating button, product inquiries and order confirmations. Leave blank to hide WhatsApp buttons.')}${inp('phone', 'Phone', c.phone)}${inp('email', 'Public email', c.email, 'type="email"')}${inp('order_notification_email', 'Send new-order alerts to', c.order_notification_email, 'type="email"', 'Requires SMTP to be configured on the server')}${inp('address', 'Address', c.address, 'span-2')}${inp('hours', 'Business hours', c.hours, 'span-2')}</div>`)}
    ${sec('social', 'Social media', `<div class="form-grid two">${['instagram', 'facebook', 'tiktok', 'youtube'].map((k) => inp(k, k[0].toUpperCase() + k.slice(1), so[k], 'placeholder="https://"')).join('')}</div>`, 'Only icons with a link are shown.')}
    ${sec('footer', 'Footer', `${ta('description', 'Brand description', ft.description, 2)}${inp('copyright', 'Copyright text', ft.copyright)}`)}
    ${sec('pages', 'Policy & information pages', `${['about', 'privacy', 'terms', 'shipping', 'returns'].map((k) => `<div class="form-grid two" style="padding-bottom:12px;border-bottom:1px solid var(--line)">${inp(`${k}_title`, `${k[0].toUpperCase() + k.slice(1)} — title`, pg[k]?.title, 'span-2')}${ta(`${k}_body`, 'Content (blank line between paragraphs)', pg[k]?.body, 6)}</div>`).join('')}
      ${ta('faq', 'FAQ — one per block: question on the first line, answer below; blank line between items', (pg.faq?.items || []).map((x) => `${x.q}\n${x.a}`).join('\n\n'), 10)}`, 'The seeded policy texts are DRAFTS. Have them reviewed before launch.')}`;

  const lines = (v) => String(v || '').split('\n').map((x) => x.trim()).filter(Boolean);
  const build = {
    brand: (d) => ({ ...b, name: d.name, tagline: d.tagline, logo_url: d.logo_url, meta_description: d.meta_description, demo_notice: d.demo_notice }),
    announcements: (d) => ({ enabled: d.enabled, messages: lines(d.messages), interval: Number(d.interval) || 4500 }),
    hero: (d) => ({ eyebrow: d.eyebrow, line1: d.line1, line2: d.line2, description: d.description, primary: { label: d.primary_label, url: d.primary_url }, secondary: { label: d.secondary_label, url: d.secondary_url }, enable_3d: d.enable_3d }),
    promo: (d) => ({ enabled: d.enabled, eyebrow: d.eyebrow, heading: d.heading, text: d.text, cta_label: d.cta_label, cta_url: d.cta_url, image: d.image }),
    brand_story: (d) => ({ heading: d.heading, paragraphs: String(d.paragraphs).split(/\n\s*\n/).map((x) => x.trim()).filter(Boolean), points: lines(d.points), image: d.image, cta: d.cta_label ? { label: d.cta_label, url: d.cta_url } : null }),
    why_choose: (d) => (s.why_choose || []).map((_, i) => ({ icon: d[`icon_${i}`], title: d[`title_${i}`], text: d[`text_${i}`] })),
    home_sections: (d) => d,
    contact: (d) => ({ ...d, whatsapp: String(d.whatsapp || '').replace(/\D/g, '').replace(/^0/, '92') }),
    social: (d) => d,
    footer: (d) => d,
    pages: (d) => ({ ...Object.fromEntries(['about', 'privacy', 'terms', 'shipping', 'returns'].map((k) => [k, { title: d[`${k}_title`], body: d[`${k}_body`] }])), faq: { title: pg.faq?.title || 'FAQ', items: String(d.faq).split(/\n\s*\n/).map((blk) => { const [q, ...a] = blk.trim().split('\n'); return { q: q?.trim(), a: a.join(' ').trim() }; }).filter((x) => x.q && x.a) } }),
  };
  qsa('form[data-key]').forEach((f) => {
    bindImageField(f);
    f.onsubmit = async (e) => {
      e.preventDefault(); const btn = qs('[type=submit]', f); setBusy(btn, true);
      try { await api(`/admin/settings/${f.dataset.key}`, { method: 'PUT', body: { value: build[f.dataset.key](formData(f)) } }); toast('Saved — refresh the store to see changes', 'ok'); }
      catch (ex) { toast(ex.message, 'err'); } finally { setBusy(btn, false); }
    };
  });
}

async function payments() {
  title('Payment methods');
  const s = await api('/admin/settings');
  const pm = s.payments || {};
  body().innerHTML = `<div class="notice warn">Only enable methods you can actually accept. Bank Transfer, Easypaisa and JazzCash are manual: the customer pays using your instructions, submits the transaction ID, and you verify it in the order before marking it Paid. No online payment is simulated.</div>
    <form class="card" data-pm style="display:grid;gap:20px">${['cod', 'bank', 'easypaisa', 'jazzcash'].map((k) => `<div style="display:grid;gap:12px;padding-bottom:18px;border-bottom:1px solid var(--line)"><div class="sec-title" style="margin:0"><h2>${esc(pm[k]?.label || k)}</h2>${chk(`${k}_enabled`, 'Enabled', pm[k]?.enabled)}</div>
      <div class="form-grid two">${inp(`${k}_label`, 'Label shown to customers', pm[k]?.label)}<div></div><div class="field span-2"><label for="pi-${k}">${k === 'cod' ? 'Customer note' : 'Payment instructions (account title, number/IBAN, etc.)'}</label><textarea class="input" id="pi-${k}" name="${k}_instructions" rows="${k === 'cod' ? 2 : 4}">${esc(pm[k]?.instructions || '')}</textarea></div></div></div>`).join('')}
      <p class="hint-box" style="margin:0">Future payment gateway integration: add a new provider server-side (server/orders.js) — the order model already tracks payment status and references.</p>
      <div style="display:flex;justify-content:flex-end"><button class="btn btn-primary" type="submit">Save payment settings</button></div></form>`;
  const f = qs('[data-pm]');
  f.onsubmit = async (e) => {
    e.preventDefault(); const d = formData(f); const b = qs('[type=submit]', f); setBusy(b, true);
    const value = Object.fromEntries(['cod', 'bank', 'easypaisa', 'jazzcash'].map((k) => [k, { enabled: d[`${k}_enabled`], label: d[`${k}_label`] || k, instructions: d[`${k}_instructions`] }]));
    try { await api('/admin/settings/payments', { method: 'PUT', body: { value } }); toast('Saved', 'ok'); } catch (ex) { toast(ex.message, 'err'); } finally { setBusy(b, false); }
  };
}

async function staff() {
  title('Staff & roles');
  const list = await api('/admin/staff');
  body().innerHTML = `<div class="notice"><strong>Admin</strong>: full access including settings, coupons, delivery, payments and staff. <strong>Staff</strong>: orders, products, categories, reviews and customers — no store settings.</div>
    <section class="card"><div class="sec-title"><h2>Team</h2></div><div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Last login</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map((u) => `<tr data-id="${u.id}"><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.id === me.id ? `<span class="badge-role">${u.role}</span>` : `<select class="input inline-sel" data-role>${opts({ staff: 'Staff', admin: 'Admin', customer: 'Remove access' }, u.role)}</select>`}</td><td class="tiny">${dt(u.last_login_at)}</td><td>${u.active ? pill('delivered', 'Active') : pill('cancelled', 'Disabled')}</td><td>${u.id !== me.id ? `<button class="mini-btn" style="height:32px" data-act>${u.active ? 'Disable' : 'Enable'}</button>` : '(you)'}</td></tr>`).join('')}</tbody></table></div></section>
    <form class="card" data-new style="display:grid;gap:14px"><h2 class="h-md" style="font-size:17px">Add team member</h2><div class="form-grid two">${inp('name', 'Name', '', 'required')}${inp('email', 'Email', '', 'type="email" required')}${inp('password', 'Temporary password (12+ characters)', '', 'type="password" autocomplete="new-password" minlength="12" required')}<div class="field"><label for="i-role">Role</label><select class="input" id="i-role" name="role"><option value="staff">Staff</option><option value="admin">Admin</option></select></div></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary btn-sm" type="submit" style="justify-self:start">Add</button></form>`;
  body().onchange = async (e) => { const tr = e.target.closest('tr[data-id]'); if (tr && e.target.matches('[data-role]')) { try { await api(`/admin/staff/${tr.dataset.id}`, { method: 'PATCH', body: { role: e.target.value } }); toast('Role updated', 'ok'); route(); } catch (ex) { toast(ex.message, 'err'); } } };
  body().onclick = async (e) => { const tr = e.target.closest('tr[data-id]'); if (tr && e.target.closest('[data-act]')) { const u = list.find((x) => String(x.id) === tr.dataset.id); await api(`/admin/staff/${u.id}`, { method: 'PATCH', body: { active: !u.active } }); route(); } };
  const f = qs('[data-new]');
  f.onsubmit = async (e) => { e.preventDefault(); const b = qs('[type=submit]', f); setBusy(b, true); try { await api('/admin/staff', { method: 'POST', body: formData(f) }); toast('Added', 'ok'); route(); } catch (ex) { qs('.form-err', f).textContent = ex.message; setBusy(b, false); } };
}

async function activity() {
  title('Activity & emails');
  const [log, out] = await Promise.all([api('/admin/audit'), api('/admin/outbox')]);
  body().innerHTML = `<section class="card"><div class="sec-title"><h2>Outgoing emails</h2><span class="tiny muted">“not_configured” means SMTP is not set up on the server, so the email was logged but not sent</span></div>
    ${out.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>To</th><th>Subject</th><th>Status</th><th>When</th></tr></thead><tbody>${out.map((m) => `<tr><td>${esc(m.recipient)}</td><td>${esc(m.subject || '')}</td><td>${pill(m.status === 'sent' ? 'delivered' : m.status === 'failed' ? 'cancelled' : 'pending', m.status)}${m.error ? `<div class="tiny muted">${esc(m.error)}</div>` : ''}</td><td class="tiny">${dt(m.created_at)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small">No emails yet.</p>'}</section>
    <section class="card"><div class="sec-title"><h2>Admin activity log</h2></div>${log.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Item</th></tr></thead><tbody>${log.map((a) => `<tr><td class="tiny">${dt(a.created_at)}</td><td>${esc(a.name || '—')}</td><td>${esc(a.action)}</td><td class="tiny">${esc(a.entity || '')} ${esc(a.entity_id || '')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted small">No activity yet.</p>'}</section>`;
}

boot();
