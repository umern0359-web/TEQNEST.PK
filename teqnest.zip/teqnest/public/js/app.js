// TEQNEST storefront entry: boot + client-side router (server renders SEO meta for each URL).
import { api, state, qs, esc, refreshUser, refreshCart, toast } from './core.js';
import { renderAnnouncement, renderHeader, renderFooter, renderWaFloat, setNavigator, markActiveNav, closeAllOverlays } from './ui.js';
import { homeView, cleanupHome, killScrollTriggers } from './views/home.js';
import { shopView } from './views/shop.js';
import { productView, cleanupProduct } from './views/product.js';
import { cartView, checkoutView, orderView, trackView, cleanupCheckout } from './views/checkout.js';
import { loginView, registerView, forgotView, resetView, accountView, wishlistView } from './views/account.js';
import { policyView, aboutView, faqView, notFoundView } from './views/pages.js';

const main = qs('#main');
const site = () => state.settings?.brand?.name || 'TEQNEST';

const routes = [
  [/^\/$/, () => homeView(main), () => `${site()} — ${state.settings.brand?.tagline || ''}`],
  [/^\/shop\/?$/, () => shopView(main, { navigate }), () => `Shop All | ${site()}`],
  [/^\/shop\/([\w-]+)$/, (m) => shopView(main, { category: m[1], navigate }), (m) => `${state.categories.find((c) => c.slug === m[1])?.name || 'Shop'} | ${site()}`],
  [/^\/new-arrivals$/, () => shopView(main, { newArrivals: true, navigate }), () => `New Arrivals | ${site()}`],
  [/^\/product\/([\w-]+)$/, (m) => productView(main, { slug: m[1], navigate }), () => `${qs('h1', main)?.textContent || 'Product'} | ${site()}`],
  [/^\/p\/(\d+)$/, async (m) => { const r = await api(`/products?ids=${m[1]}`); if (!r.products[0]) return false; navigate(`/product/${r.products[0].slug}${location.hash}`, { replace: true }); return true; }],
  [/^\/cart$/, () => cartView(main), () => `Cart | ${site()}`],
  [/^\/checkout$/, () => checkoutView(main, { navigate }), () => `Checkout | ${site()}`],
  [/^\/order\/([\w-]+)$/, (m) => orderView(main, { number: m[1] }), (m) => `Order ${m[1]} | ${site()}`],
  [/^\/track$/, () => trackView(main), () => `Track Order | ${site()}`],
  [/^\/wishlist$/, () => wishlistView(main), () => `Wishlist | ${site()}`],
  [/^\/account\/login$/, () => loginView(main, { navigate }), () => `Log in | ${site()}`],
  [/^\/account\/register$/, () => registerView(main, { navigate }), () => `Create account | ${site()}`],
  [/^\/account\/forgot$/, () => forgotView(main), () => `Reset password | ${site()}`],
  [/^\/account\/reset$/, () => resetView(main, { navigate }), () => `New password | ${site()}`],
  [/^\/account(?:\/(orders|wishlist|addresses|profile))?(?:\/([\w-]+))?$/, (m) => accountView(main, { tab: m[1] || '', sub: m[2], navigate }), () => `My Account | ${site()}`],
  [/^\/policy\/(\w+)$/, (m) => policyView(main, { key: m[1] }), () => `${qs('h1', main)?.textContent || 'Policy'} | ${site()}`],
  [/^\/about$/, () => aboutView(main), () => `About | ${site()}`],
  [/^\/faq$/, () => faqView(main), () => `FAQ | ${site()}`],
];

let navToken = 0;
async function render({ keepScroll = false } = {}) {
  const token = ++navToken;
  const path = location.pathname.replace(/\/+$/, '') || '/';
  closeAllOverlays();
  cleanupHome(); killScrollTriggers(); cleanupProduct(); cleanupCheckout();
  main.classList.remove('view-enter');
  let matched = false;
  for (const [re, view, title] of routes) {
    const m = path.match(re);
    if (!m) continue;
    matched = true;
    try {
      const ok = await view(m);
      if (token !== navToken) return;
      if (ok === false) { notFoundView(main); break; }
      if (title) document.title = title(m);
    } catch (e) {
      if (token !== navToken) return;
      console.error(e);
      main.innerHTML = `<div class="wrap"><div class="empty-state" style="margin:80px auto;max-width:560px"><h3>Something went wrong</h3><p>${esc(e.message || 'Please check your connection and try again.')}</p><button class="btn btn-primary" data-retry>Try Again</button></div></div>`;
      qs('[data-retry]', main).onclick = () => render();
    }
    break;
  }
  if (!matched) notFoundView(main);
  void main.offsetWidth; main.classList.add('view-enter');
  markActiveNav(path);
  if (!keepScroll) {
    if (location.hash && location.hash !== '#review') qs(location.hash)?.scrollIntoView();
    else scrollTo({ top: 0, behavior: 'instant' });
  }
  // Move focus to main for screen readers on navigation (not on first load)
  if (render.booted) main.focus({ preventScroll: true });
  render.booted = true;
}

export function navigate(url, { replace = false, keepScroll = false } = {}) {
  const u = new URL(url, location.origin);
  if (u.origin !== location.origin) { location.href = url; return; }
  if (replace) history.replaceState({}, '', u.pathname + u.search + u.hash);
  else history.pushState({}, '', u.pathname + u.search + u.hash);
  render({ keepScroll });
}
setNavigator(navigate);

document.addEventListener('click', (e) => {
  if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  const a = e.target.closest('a[href]');
  if (!a || a.target === '_blank' || a.hasAttribute('download') || a.getAttribute('aria-disabled') === 'true') { if (a?.getAttribute('aria-disabled') === 'true') e.preventDefault(); return; }
  const href = a.getAttribute('href');
  if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
  const u = new URL(href, location.href);
  if (u.origin !== location.origin || /^\/(admin|api|uploads|vendor)(\/|$)/.test(u.pathname)) return;
  e.preventDefault();
  if (u.pathname === location.pathname && u.search === location.search && u.hash) { qs(u.hash)?.scrollIntoView({ behavior: 'smooth' }); return; }
  navigate(u.pathname + u.search + u.hash);
});
addEventListener('popstate', () => render({ keepScroll: false }));

// ---------- boot ----------
(async function boot() {
  try {
    [state.settings, state.categories] = await Promise.all([api('/settings'), api('/categories')]);
  } catch {
    main.innerHTML = `<div class="wrap"><div class="empty-state" style="margin:80px auto;max-width:560px"><h3>We couldn't load the store</h3><p>Please check your connection and refresh the page.</p><button class="btn btn-primary" data-reload>Reload</button></div></div>`;
    qs('[data-reload]', main).onclick = () => location.reload();
    return;
  }
  renderAnnouncement();
  renderHeader();
  renderFooter();
  renderWaFloat();
  if (state.settings.brand?.demo_notice) {
    const d = document.createElement('div'); d.className = 'demo-flag'; d.textContent = 'Demo catalog — sample products & prices';
    document.body.append(d);
  }
  await Promise.all([refreshUser().catch(() => {}), refreshCart().catch(() => {})]);
  await render();
  addEventListener('offline', () => toast('You are offline. Some features may not work.', 'err'));
})();
