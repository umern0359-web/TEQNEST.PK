// Runs before paint: theme + motion preferences, avoids flash of wrong theme.
(function () {
  var d = document.documentElement;
  d.classList.remove('no-js');
  try { var t = localStorage.getItem('tq_theme'); if (t === 'light' || t === 'dark') d.setAttribute('data-theme', t); } catch (e) {}
  if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) d.classList.add('reduced');
})();
