// Shared UI: header, footer, announcement bar, overlays (cart drawer, search, quick view, mobile menu), product cards, motion.
import { api, state, on, emit, esc, rs, qs, qsa, icon, brandIcon, stars, toast, setCart, toggleWishlist, waLink, waProductText, waCartText, safeUrl, debounce, reducedMotion, setBusy } from './core.js';

let navigate = (url) => { location.href = url; };
export function setNavigator(fn) { navigate = fn; }

// ---------- announcement ----------
export function renderAnnouncement() {
  const a = state.settings.announcements;
  const host = qs('#ann');
  let dismissed = false;
  try { dismissed = sessionStorage.getItem('tq_ann') === '1'; } catch { /* ignore */ }
  if (!a?.enabled || !a.messages?.length || dismissed) { host.innerHTML = ''; document.documentElement.style.setProperty('--ann-h', '0px'); return; }
  host.innerHTML = `<div class="ann" role="region" aria-label="Announcements"><div class="ann-track" aria-live="off">${a.messages.map((m, i) => `<div class="ann-msg ${i === 0 ? 'on' : ''}">${esc(m)}</div>`).join('')}</div>
    <button class="ann-close" aria-label="Dismiss announcements">${icon('close')}</button></div>`;
  qs('.ann-close', host).onclick = () => { try { sessionStorage.setItem('tq_ann', '1'); } catch { /* ignore */ } host.innerHTML = ''; document.documentElement.style.setProperty('--ann-h', '0px'); };
  const msgs = qsa('.ann-msg', host);
  if (msgs.length < 2 || reducedMotion()) return;
  let i = 0;
  setInterval(() => {
    if (document.hidden) return;
    msgs[i].classList.replace('on', 'out');
    const prev = msgs[i];
    setTimeout(() => prev.classList.remove('out'), 700);
    i = (i + 1) % msgs.length;
    msgs[i].classList.add('on');
  }, Math.max(2500, a.interval || 4500));
}

// ---------- header ----------
const navCat = (slug) => state.categories.find((c) => c.slug === slug);
export function renderHeader() {
  const b = state.settings.brand || {};
  const logo = b.logo_url ? `<img src="${esc(safeUrl(b.logo_url))}" alt="${esc(b.name || 'TEQNEST')}">` : `<span>${esc(b.name || 'TEQNEST')}</span><span class="dot" aria-hidden="true"></span>`;
  const links = [
    ['Earbuds', '/shop/earbuds'], ['Headphones', '/shop/headphones'], ['Smartwatches', '/shop/smartwatches'], ['Gadgets', '/shop/gadgets'],
  ].filter(([, u]) => navCat(u.split('/').pop()));
  const mega = state.categories.map((c) => `<a href="/shop/${esc(c.slug)}"><img src="${esc(safeUrl(c.image))}" alt="" loading="lazy" width="64" height="64"><div><strong>${esc(c.name)}</strong><span>${esc(c.description || '')}</span></div></a>`).join('');
  qs('#header').innerHTML = `<div class="wrap"><div class="header-bar">
    <a class="logo" href="/" aria-label="${esc(b.name || 'TEQNEST')} home">${logo}</a>
    <nav class="nav" aria-label="Main">
      <div class="nav-item"><a href="/">Home</a></div>
      <div class="nav-item" data-mega><button aria-expanded="false" aria-haspopup="true">Shop ${icon('chev')}</button><div class="mega" role="menu">${mega}<a class="mega-all" href="/shop">View all products</a></div></div>
      ${links.map(([l, u]) => `<div class="nav-item"><a href="${u}">${l}</a></div>`).join('')}
      <div class="nav-item"><a href="/new-arrivals">New Arrivals</a></div>
    </nav>
    <div class="header-actions">
      <button class="icon-btn" data-search aria-label="Search">${icon('search')}</button>
      <button class="icon-btn hide-sm" data-theme-toggle aria-label="Toggle light/dark theme">${icon(document.documentElement.dataset.theme === 'light' ? 'moon' : 'sun')}</button>
      <a class="icon-btn hide-sm" href="/account" aria-label="Account">${icon('user')}</a>
      <a class="icon-btn" href="/wishlist" aria-label="Wishlist">${icon('heart')}<span class="badge-count" data-wl-count></span></a>
      <button class="icon-btn" data-cart aria-label="Open cart">${icon('bag')}<span class="badge-count" data-cart-count></span></button>
      <button class="icon-btn burger" data-burger aria-label="Menu" aria-expanded="false" aria-controls="mnav"><span></span><span></span><span></span></button>
    </div></div></div>`;

  const h = qs('#header');
  qs('[data-search]', h).onclick = openSearch;
  qs('[data-cart]', h).onclick = () => openCart();
  qs('[data-burger]', h).onclick = toggleMobileNav;
  qs('[data-theme-toggle]', h).onclick = (e) => {
    const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem('tq_theme', next); } catch { /* ignore */ }
    e.currentTarget.innerHTML = icon(next === 'light' ? 'moon' : 'sun');
    qs('meta[name=theme-color]').content = next === 'light' ? '#F5F7FB' : '#090B10';
    emit('theme', next);
  };
  // Mega menu: hover on desktop, click/keyboard everywhere
  const mi = qs('[data-mega]', h); const mb = qs('button', mi);
  let t;
  const setOpen = (o) => { mi.classList.toggle('open', o); mb.setAttribute('aria-expanded', o); };
  mi.addEventListener('mouseenter', () => { clearTimeout(t); setOpen(true); });
  mi.addEventListener('mouseleave', () => { t = setTimeout(() => setOpen(false), 180); });
  mb.onclick = () => setOpen(!mi.classList.contains('open'));
  mi.addEventListener('keydown', (e) => { if (e.key === 'Escape') { setOpen(false); mb.focus(); } });
  mi.addEventListener('click', (e) => { if (e.target.closest('a')) setOpen(false); });
  document.addEventListener('click', (e) => { if (!mi.contains(e.target)) setOpen(false); });

  const onScroll = () => h.classList.toggle('scrolled', scrollY > 10);
  addEventListener('scroll', onScroll, { passive: true }); onScroll();
  updateBadges();
}
export function markActiveNav(path) {
  qsa('#header .nav a, .mnav-links a').forEach((a) => {
    if (a.getAttribute('href') === path) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
}
function updateBadges() {
  const cc = qs('[data-cart-count]'); const wc = qs('[data-wl-count]');
  const n = state.cart?.count || 0; const w = state.wishlist.size;
  if (cc) { const prev = cc.textContent; cc.textContent = n; cc.classList.toggle('on', n > 0); if (prev && prev !== String(n)) { cc.classList.remove('bump'); void cc.offsetWidth; cc.classList.add('bump'); } }
  if (wc) { wc.textContent = w; wc.classList.toggle('on', w > 0); }
}
on('cart', updateBadges); on('wishlist', updateBadges);

// ---------- mobile nav ----------
function toggleMobileNav() {
  let m = qs('#mnav');
  if (!m) {
    m = document.createElement('div'); m.id = 'mnav'; m.className = 'mnav';
    const links = [['Home', '/'], ['Shop All', '/shop'], ...state.categories.map((c) => [c.name, `/shop/${c.slug}`, c.product_count]), ['New Arrivals', '/new-arrivals'], ['Track Order', '/track'], ['About', '/about']];
    m.innerHTML = `<div class="mnav-bg" data-close></div><nav class="mnav-panel" aria-label="Mobile">
      <div style="display:flex;justify-content:space-between;align-items:center"><a class="logo" href="/">${esc(state.settings.brand?.name || 'TEQNEST')}<span class="dot"></span></a><button class="icon-btn" data-close aria-label="Close menu">${icon('close')}</button></div>
      <div class="mnav-links">${links.map(([l, u, n], i) => `<a href="${esc(u)}" style="transition-delay:${0.04 * i + 0.1}s">${esc(l)}${n != null ? `<small>${n}</small>` : icon('right')}</a>`).join('')}</div>
      <div class="mnav-foot">
        <a class="btn btn-ghost btn-block" href="/account">${icon('user')} ${state.user ? 'My Account' : 'Log in / Register'}</a>
        <button class="btn btn-ghost btn-block" data-theme-m>${icon('sun')} Toggle theme</button>
        ${waLink('Hi TEQNEST!') ? `<a class="btn btn-wa btn-block" href="${esc(waLink('Hi TEQNEST! I need some help.'))}" target="_blank" rel="noopener">${brandIcon.whatsapp.replace('<svg', '<svg width="18"')} Chat on WhatsApp</a>` : ''}
      </div></nav>`;
    document.body.append(m);
    m.addEventListener('click', (e) => { if (e.target.closest('[data-close]') || e.target.closest('a')) closeMobileNav(); });
    qs('[data-theme-m]', m).onclick = () => qs('[data-theme-toggle]').click();
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMobileNav(); });
  }
  const open = !m.classList.contains('open');
  requestAnimationFrame(() => m.classList.toggle('open', open));
  qs('[data-burger]').setAttribute('aria-expanded', open);
  document.body.classList.toggle('lock', open);
  if (open) setTimeout(() => qs('.mnav-links a', m)?.focus(), 300);
}
export function closeMobileNav() {
  const m = qs('#mnav'); if (!m?.classList.contains('open')) return;
  m.classList.remove('open'); qs('[data-burger]')?.setAttribute('aria-expanded', 'false'); document.body.classList.remove('lock');
}

// ---------- focus trap helper ----------
function trap(container, onClose) {
  const prev = document.activeElement;
  const handler = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); onClose(); }
    if (e.key !== 'Tab') return;
    const f = qsa('a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])', container).filter((x) => x.offsetParent !== null);
    if (!f.length) return;
    if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f.at(-1).focus(); }
    else if (!e.shiftKey && document.activeElement === f.at(-1)) { e.preventDefault(); f[0].focus(); }
  };
  container.addEventListener('keydown', handler);
  return () => { container.removeEventListener('keydown', handler); prev?.focus?.(); };
}

// ---------- search ----------
let searchEl, releaseSearch;
export function openSearch() {
  if (!searchEl) {
    searchEl = document.createElement('div'); searchEl.className = 'search'; searchEl.setAttribute('role', 'dialog'); searchEl.setAttribute('aria-modal', 'true'); searchEl.setAttribute('aria-label', 'Search products');
    searchEl.innerHTML = `<div class="search-box"><form class="search-input" role="search">${icon('search')}<input type="search" name="q" placeholder="Search earbuds, chargers, smartwatches…" autocomplete="off" aria-label="Search" aria-controls="sr-list"><kbd>ESC</kbd></form>
      <div class="search-results" id="sr-list" role="listbox"><div class="search-hint">Start typing to see suggestions. Press Enter to see all results.</div></div></div>`;
    document.body.append(searchEl);
    const input = qs('input', searchEl); const list = qs('.search-results', searchEl);
    let ctrl, active = -1;
    const render = debounce(async (q) => {
      if (q.trim().length < 2) { list.innerHTML = '<div class="search-hint">Start typing to see suggestions. Press Enter to see all results.</div>'; return; }
      ctrl?.abort(); ctrl = new AbortController();
      try {
        const r = await api(`/search/suggest?q=${encodeURIComponent(q)}`, { signal: ctrl.signal });
        active = -1;
        if (!r.products.length && !r.categories.length) { list.innerHTML = `<div class="search-hint">No matches for “${esc(q)}”. Try a different term or <a href="/shop" style="color:var(--cyan)">browse all products</a>.</div>`; return; }
        list.innerHTML = (r.categories.length ? `<div class="sr-label">Categories</div>${r.categories.map((c) => `<a role="option" href="/shop/${esc(c.slug)}">${icon('select')}<span class="sr-name">${esc(c.name)}</span></a>`).join('')}` : '') +
          (r.products.length ? `<div class="sr-label">Products</div>${r.products.map((p) => `<a role="option" href="/product/${esc(p.slug)}"><img src="${esc(safeUrl(p.images[0]))}" alt="" width="54" height="54"><div><div class="sr-name">${esc(p.name)}</div><div class="tiny muted">${p.price != null ? rs(p.price) + ' · ' : ''}${esc(p.availability_label)}</div></div></a>`).join('')}` : '') +
          `<a role="option" href="/shop?q=${encodeURIComponent(q)}" style="justify-content:center;color:var(--cyan);font-weight:600">See all results for “${esc(q)}” ${icon('arrow')}</a>`;
      } catch (e) { if (e.name !== 'AbortError') list.innerHTML = '<div class="search-hint">Search is unavailable right now.</div>'; }
    }, 160);
    input.addEventListener('input', () => render(input.value));
    input.addEventListener('keydown', (e) => {
      const opts = qsa('a[role=option]', list);
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault(); active = (active + (e.key === 'ArrowDown' ? 1 : -1) + opts.length) % opts.length;
        opts.forEach((o, i) => o.classList.toggle('active', i === active)); opts[active]?.scrollIntoView({ block: 'nearest' });
      }
      if (e.key === 'Enter' && active >= 0 && opts[active]) { e.preventDefault(); closeSearch(); navigate(opts[active].getAttribute('href')); }
    });
    qs('form', searchEl).onsubmit = (e) => { e.preventDefault(); const q = input.value.trim(); if (!q) return; closeSearch(); navigate(`/shop?q=${encodeURIComponent(q)}`); };
    searchEl.addEventListener('click', (e) => { if (e.target === searchEl) closeSearch(); if (e.target.closest('a')) closeSearch(); });
  }
  searchEl.classList.add('open'); document.body.classList.add('lock');
  releaseSearch = trap(searchEl, closeSearch);
  setTimeout(() => qs('input', searchEl).focus(), 50);
}
export function closeSearch() { if (!searchEl?.classList.contains('open')) return; searchEl.classList.remove('open'); document.body.classList.remove('lock'); releaseSearch?.(); }
document.addEventListener('keydown', (e) => {
  if ((e.key === '/' || (e.key === 'k' && (e.metaKey || e.ctrlKey))) && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); openSearch(); }
});

// ---------- cart drawer ----------
let drawer, releaseDrawer;
export function openCart() {
  if (!drawer) {
    drawer = document.createElement('div'); drawer.className = 'drawer';
    drawer.innerHTML = `<div class="drawer-bg" data-close></div><aside class="drawer-panel" role="dialog" aria-modal="true" aria-labelledby="cart-title">
      <div class="drawer-head"><h2 id="cart-title">Your Cart</h2><button class="icon-btn" data-close aria-label="Close cart">${icon('close')}</button></div>
      <div class="drawer-body" aria-live="polite"></div><div class="drawer-foot"></div></aside>`;
    document.body.append(drawer);
    drawer.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) closeCart(); if (e.target.closest('a[href^="/"]')) closeCart(); });
    bindCartLines(drawer);
    on('cart', () => drawer && renderDrawer());
  }
  renderDrawer();
  requestAnimationFrame(() => drawer.classList.add('open'));
  document.body.classList.add('lock');
  releaseDrawer = trap(drawer, closeCart);
  setTimeout(() => qs('[data-close].icon-btn', drawer).focus(), 100);
}
export function closeCart() { if (!drawer?.classList.contains('open')) return; drawer.classList.remove('open'); document.body.classList.remove('lock'); releaseDrawer?.(); }

export function lineItemHTML(i) {
  return `<div class="line-item" data-line="${i.line_id}">
    <a href="/product/${esc(i.product.slug)}"><img src="${esc(safeUrl(i.product.image))}" alt="" width="76" height="76" loading="lazy"></a>
    <div><a class="li-name" href="/product/${esc(i.product.slug)}">${esc(i.product.name)}</a>
      ${i.color ? `<div class="li-var">${esc(i.color)}</div>` : ''}<div class="li-var">${rs(i.product.price)} each${i.product.availability === 'preorder' ? ' · Pre-order' : ''}</div>
      ${i.problem ? `<div class="li-problem">${esc(i.problem)}</div>` : ''}
      <div class="qty" role="group" aria-label="Quantity for ${esc(i.product.name)}"><button data-dec aria-label="Decrease quantity">${icon('minus')}</button><input type="number" value="${i.qty}" min="1" max="${i.product.max_qty || 1}" aria-label="Quantity" inputmode="numeric"><button data-inc aria-label="Increase quantity" ${i.qty >= i.product.max_qty ? 'disabled' : ''}>${icon('plus')}</button></div>
      <div><button class="li-remove" data-remove>Remove</button></div></div>
    <div class="li-price">${rs(i.line_total)}</div></div>`;
}
export function bindCartLines(root) {
  const update = async (line, qty) => {
    try { setCart(await api(`/cart/items/${line}`, { method: qty ? 'PATCH' : 'DELETE', body: qty ? { qty } : undefined })); }
    catch (e) { toast(e.message, 'err'); setCart(await api('/cart')); }
  };
  root.addEventListener('click', (e) => {
    const li = e.target.closest('[data-line]'); if (!li) return;
    const id = li.dataset.line; const input = qs('input', li); const v = Number(input.value);
    if (e.target.closest('[data-inc]')) update(id, v + 1);
    else if (e.target.closest('[data-dec]')) update(id, v - 1);
    else if (e.target.closest('[data-remove]')) { li.style.opacity = '.4'; update(id, 0); }
  });
  root.addEventListener('change', (e) => {
    const li = e.target.closest('[data-line]'); if (!li || e.target.tagName !== 'INPUT') return;
    update(li.dataset.line, Math.max(0, Math.min(10, Math.floor(Number(e.target.value) || 0))));
  });
}
export function freeDeliveryHTML(cart) {
  const zone = cart.zones.find((z) => z.id === cart.zone_id) || cart.zones[0];
  if (!zone || zone.free_threshold == null || !cart.subtotal) return '';
  const after = cart.subtotal - cart.discount;
  const left = zone.free_threshold - after;
  const pct = Math.min(100, (after / zone.free_threshold) * 100);
  return `<div class="free-bar">${left > 0 ? `Add <strong>${rs(left)}</strong> more for free delivery (${esc(zone.name)})` : `You qualify for free delivery in ${esc(zone.name)}.`}<div class="bar"><i style="width:${pct}%"></i></div></div>`;
}
function renderDrawer() {
  const c = state.cart; const body = qs('.drawer-body', drawer); const foot = qs('.drawer-foot', drawer);
  qs('#cart-title', drawer).textContent = `Your Cart${c?.count ? ` (${c.count})` : ''}`;
  if (!c?.items.length) {
    body.innerHTML = `<div class="empty-state" style="margin-top:24px"><h3>Your cart is empty</h3><p>Find something you'll love.</p><a class="btn btn-primary" href="/shop">Start Shopping</a></div>`;
    foot.innerHTML = ''; return;
  }
  body.innerHTML = c.items.map(lineItemHTML).join('');
  const wa = waLink(waCartText(c));
  foot.innerHTML = `${freeDeliveryHTML(c)}
    <div class="sum-row"><span>Subtotal</span><span>${rs(c.subtotal)}</span></div>
    ${c.discount ? `<div class="sum-row"><span>Discount (${esc(c.coupon.code)})</span><span>−${rs(c.discount)}</span></div>` : ''}
    <div class="sum-row tiny"><span>Delivery calculated at checkout</span></div>
    ${c.issues.length ? `<div class="notice warn">Some items need attention before checkout.</div>` : ''}
    <a class="btn btn-primary btn-block" href="/checkout" ${c.can_checkout ? '' : 'aria-disabled="true"'}>Checkout · ${rs(c.subtotal - c.discount)}</a>
    <div style="display:flex;gap:8px"><a class="btn btn-ghost btn-sm" style="flex:1" href="/cart">View Cart</a>${wa ? `<a class="btn btn-wa btn-sm" style="flex:1" href="${esc(wa)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}</div>`;
}

export async function addToCart(product, { qty = 1, color = '', btn, open = true } = {}) {
  setBusy(btn, true);
  try {
    setCart(await api('/cart/items', { method: 'POST', body: { product_id: product.id, qty, color } }));
    if (open) openCart(); else toast(`${product.name} added to cart`, 'ok');
    return true;
  } catch (e) { toast(e.message, 'err'); return false; }
  finally { setBusy(btn, false); }
}

// ---------- product card ----------
export function productCard(p, { cls = '' } = {}) {
  const img2 = p.images[1];
  const wished = state.wishlist.has(p.id);
  const stockCls = p.low_stock ? 'low' : p.availability;
  const stockLabel = p.low_stock ? 'Low stock' : p.availability_label;
  const action = p.purchasable
    ? `<button class="btn btn-primary" data-add="${p.id}">${p.availability === 'preorder' ? 'Pre-order' : 'Add to Cart'}</button>`
    : (waLink('x') ? `<a class="btn btn-wa" href="${esc(waLink(waProductText(p)))}" target="_blank" rel="noopener">Inquire on WhatsApp</a>` : `<a class="btn btn-ghost" href="/product/${esc(p.slug)}">View Details</a>`);
  return `<article class="p-card ${cls}" data-pid="${p.id}">
    <div class="p-media">
      <img class="main" src="${esc(safeUrl(p.images[0]))}" alt="${esc(p.name)}" loading="lazy" decoding="async" width="600" height="600">
      ${img2 ? `<img class="alt" src="${esc(safeUrl(img2))}" alt="" loading="lazy" decoding="async" width="600" height="600">` : ''}
      <div class="p-tags">${p.discount_percent ? `<span class="tag tag-sale">−${p.discount_percent}%</span>` : ''}${p.new_arrival ? '<span class="tag tag-new">New</span>' : ''}${['coming_soon', 'on_request', 'preorder'].includes(p.availability) ? `<span class="tag">${esc(p.availability_label)}</span>` : ''}</div>
      <div class="p-actions">
        <button class="icon-btn ${wished ? 'on' : ''}" data-wish="${p.id}" aria-label="${wished ? 'Remove from' : 'Add to'} wishlist" aria-pressed="${wished}">${icon('heart')}</button>
        <button class="icon-btn qv" data-qv="${esc(p.slug)}" aria-label="Quick view ${esc(p.name)}">${icon('eye')}</button>
      </div>
    </div>
    <div class="p-body">
      ${p.category ? `<div class="p-cat">${esc(p.category.name)}</div>` : ''}
      <h3 class="p-name"><a href="/product/${esc(p.slug)}">${esc(p.name)}</a></h3>
      ${stars(p.rating)}
      <div class="p-price">${p.price != null ? `<span class="price">${rs(p.price)}</span>${p.discount_percent ? `<span class="price-old">${rs(p.regular_price)}</span><span class="price-off">Save ${p.discount_percent}%</span>` : ''}` : '<span class="muted small">Price on request</span>'}</div>
      <div class="p-meta"><span class="stock ${stockCls}">${esc(stockLabel)}</span></div>
      <div class="p-add">${action}</div>
    </div></article>`;
}

/** Event delegation for product cards anywhere inside root. Products are looked up from the provided map. */
export function bindProductCards(root, products) {
  const byId = new Map(products.map((p) => [p.id, p]));
  root.addEventListener('click', async (e) => {
    const add = e.target.closest('[data-add]');
    const wish = e.target.closest('[data-wish]');
    const qv = e.target.closest('[data-qv]');
    if (add) { e.preventDefault(); const p = byId.get(Number(add.dataset.add)); if (p) addToCart(p, { color: p.colors[0]?.name || '', btn: add }); }
    else if (wish) {
      e.preventDefault();
      try { const nowOn = await toggleWishlist(Number(wish.dataset.wish)); qsa(`[data-wish="${wish.dataset.wish}"]`).forEach((b) => { b.classList.toggle('on', nowOn); b.setAttribute('aria-pressed', nowOn); }); }
      catch (err) { toast(err.message, 'err'); }
    } else if (qv) { e.preventDefault(); quickView(qv.dataset.qv); }
  });
  tiltAll(root);
}

// ---------- quick view ----------
let modal, releaseModal;
export async function quickView(slug) {
  if (!modal) {
    modal = document.createElement('div'); modal.className = 'modal'; modal.setAttribute('role', 'dialog'); modal.setAttribute('aria-modal', 'true'); modal.setAttribute('aria-label', 'Quick view');
    modal.innerHTML = `<div class="modal-box"><button class="icon-btn modal-close" aria-label="Close">${icon('close')}</button><div class="modal-content"></div></div>`;
    document.body.append(modal);
    modal.addEventListener('click', (e) => { if (e.target === modal || e.target.closest('.modal-close') || e.target.closest('a[href^="/"]')) closeModal(); });
  }
  const content = qs('.modal-content', modal);
  content.innerHTML = '<div class="skel" style="height:420px;margin:24px"></div>';
  modal.classList.add('open'); document.body.classList.add('lock');
  releaseModal = trap(modal, closeModal);
  try {
    const p = await api(`/products/${encodeURIComponent(slug)}`);
    let color = p.colors[0]?.name || '';
    const wa = waLink(waProductText(p));
    content.innerHTML = `<div class="qv-grid"><img src="${esc(safeUrl(p.images[0]))}" alt="${esc(p.name)}" width="600" height="600">
      <div class="qv-info">
        ${p.category ? `<div class="eyebrow">${esc(p.category.name)}</div>` : ''}
        <h2 class="h-md">${esc(p.name)}</h2>${stars(p.rating)}
        <div class="pdp-price">${p.price != null ? `<span class="price">${rs(p.price)}</span>${p.discount_percent ? `<span class="price-old">${rs(p.regular_price)}</span><span class="price-off">−${p.discount_percent}%</span>` : ''}` : '<span class="muted">Price on request</span>'}</div>
        <span class="stock ${p.low_stock ? 'low' : p.availability}">${p.low_stock ? 'Low stock' : esc(p.availability_label)}</span>
        <p class="muted" style="margin:0">${esc(p.short_description || '')}</p>
        ${p.colors.length ? `<div><div class="label" style="margin-bottom:8px">Colour: <span data-cname>${esc(color)}</span></div><div class="swatches">${p.colors.map((c, i) => `<button class="swatch" aria-pressed="${i === 0}" data-color="${esc(c.name)}"><i style="background:${esc(c.hex)}"></i>${esc(c.name)}</button>`).join('')}</div></div>` : ''}
        <div class="buy-row">${p.purchasable ? `<button class="btn btn-primary" data-qv-add>${p.availability === 'preorder' ? 'Pre-order' : 'Add to Cart'}</button>` : ''}${!p.purchasable && wa ? `<a class="btn btn-wa" href="${esc(wa)}" target="_blank" rel="noopener">Inquire on WhatsApp</a>` : ''}</div>
        <a class="link-arrow" href="/product/${esc(p.slug)}">Full details ${icon('arrow')}</a>
      </div></div>`;
    qsa('[data-color]', content).forEach((b) => b.onclick = () => { color = b.dataset.color; qsa('[data-color]', content).forEach((x) => x.setAttribute('aria-pressed', x === b)); qs('[data-cname]', content).textContent = color; });
    const add = qs('[data-qv-add]', content);
    if (add) add.onclick = async () => { if (await addToCart(p, { color, btn: add, open: false })) { closeModal(); openCart(); } };
    qs('.modal-close', modal).focus();
  } catch (e) { content.innerHTML = `<div class="empty-state" style="margin:24px">${esc(e.message)}</div>`; }
}
export function closeModal() { if (!modal?.classList.contains('open')) return; modal.classList.remove('open'); document.body.classList.remove('lock'); releaseModal?.(); }

export function closeAllOverlays() { closeCart(); closeSearch(); closeModal(); closeMobileNav(); }

// ---------- WhatsApp float ----------
export function renderWaFloat() {
  qs('.wa-float')?.remove();
  const link = waLink('Hi TEQNEST! I need some help.');
  if (!link) return;
  const a = document.createElement('a');
  a.className = 'wa-float'; a.href = link; a.target = '_blank'; a.rel = 'noopener'; a.setAttribute('aria-label', 'Chat with TEQNEST on WhatsApp');
  a.innerHTML = brandIcon.whatsapp;
  document.body.append(a);
}

// ---------- footer ----------
export function renderFooter() {
  const s = state.settings; const b = s.brand || {}; const c = s.contact || {}; const so = s.social || {};
  const socials = ['instagram', 'facebook', 'tiktok', 'youtube'].filter((k) => so[k]).map((k) => `<a href="${esc(safeUrl(so[k]))}" target="_blank" rel="noopener" aria-label="${k[0].toUpperCase() + k.slice(1)}">${brandIcon[k]}</a>`);
  const wa = waLink('Hi TEQNEST!');
  if (wa) socials.unshift(`<a href="${esc(wa)}" target="_blank" rel="noopener" aria-label="WhatsApp">${brandIcon.whatsapp}</a>`);
  qs('#footer').innerHTML = `<div class="wrap">
    <div class="f-grid">
      <div class="f-brand"><a class="logo" href="/">${b.logo_url ? `<img src="${esc(safeUrl(b.logo_url))}" alt="${esc(b.name)}">` : `${esc(b.name || 'TEQNEST')}<span class="dot"></span>`}</a>
        <p>${esc(s.footer?.description || '')}</p><div class="socials">${socials.join('')}</div></div>
      <div><h4>Shop</h4><ul>${state.categories.map((x) => `<li><a href="/shop/${esc(x.slug)}">${esc(x.name)}</a></li>`).join('')}<li><a href="/new-arrivals">New Arrivals</a></li></ul></div>
      <div><h4>Help</h4><ul><li><a href="/track">Track Order</a></li><li><a href="/faq">FAQ</a></li><li><a href="/policy/shipping">Shipping Policy</a></li><li><a href="/policy/returns">Return &amp; Refund Policy</a></li><li><a href="/policy/privacy">Privacy Policy</a></li><li><a href="/policy/terms">Terms &amp; Conditions</a></li></ul></div>
      <div><h4>Contact</h4><ul>
        ${c.whatsapp ? `<li><a href="${esc(wa)}" target="_blank" rel="noopener">WhatsApp: +${esc(c.whatsapp.replace(/\D/g, ''))}</a></li>` : ''}
        ${c.phone ? `<li><a href="tel:${esc(c.phone.replace(/[^\d+]/g, ''))}">${esc(c.phone)}</a></li>` : ''}
        ${c.email ? `<li><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></li>` : ''}
        ${c.address ? `<li>${esc(c.address)}</li>` : ''}${c.hours ? `<li>${esc(c.hours)}</li>` : ''}
        <li><a href="/about">About TEQNEST</a></li></ul></div>
    </div>
    <div class="f-word" aria-hidden="true">${esc(b.name || 'TEQNEST')}</div>
    <div class="f-bottom"><span>© ${new Date().getFullYear()} ${esc(s.footer?.copyright || 'TEQNEST.PK')}</span><span>Prices in PKR</span></div></div>`;
}

// ---------- motion ----------
let io;
export function reveal(root = document) {
  const els = qsa('.reveal:not(.in)', root);
  if (reducedMotion() || !('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('in')); return; }
  io ||= new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }), { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
  els.forEach((e) => io.observe(e));
}
const canHover = matchMedia('(hover: hover) and (pointer: fine)').matches;
export function tiltAll(root) {
  if (!canHover || reducedMotion()) return;
  qsa('[data-tilt]', root).forEach((el) => {
    if (el.dataset.tiltBound) return; el.dataset.tiltBound = 1;
    const max = Number(el.dataset.tilt) || 8;
    el.addEventListener('pointermove', (e) => {
      const r = el.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - 0.5; const y = (e.clientY - r.top) / r.height - 0.5;
      el.style.transform = `perspective(900px) rotateX(${-y * max}deg) rotateY(${x * max}deg) translateZ(0)`;
    });
    el.addEventListener('pointerleave', () => { el.style.transform = ''; });
  });
  qsa('.feat', root).forEach((el) => el.addEventListener('pointermove', (e) => {
    const r = el.getBoundingClientRect(); el.style.setProperty('--mx', `${e.clientX - r.left}px`); el.style.setProperty('--my', `${e.clientY - r.top}px`);
  }));
}

/** Horizontal carousel with arrows, progress and native touch scrolling. */
export function carousel(root) {
  const track = qs('.c-track', root); const prev = qs('[data-prev]', root); const next = qs('[data-next]', root); const bar = qs('.c-progress i', root);
  const update = () => {
    const max = track.scrollWidth - track.clientWidth;
    prev.disabled = track.scrollLeft <= 4; next.disabled = track.scrollLeft >= max - 4;
    if (bar) { const vis = track.clientWidth / track.scrollWidth; bar.style.width = `${vis * 100}%`; bar.style.transform = `translateX(${max ? (track.scrollLeft / max) * ((1 - vis) / vis) * 100 : 0}%)`; }
  };
  const step = () => (track.firstElementChild?.getBoundingClientRect().width || 300) + 16;
  prev.onclick = () => track.scrollBy({ left: -step(), behavior: reducedMotion() ? 'auto' : 'smooth' });
  next.onclick = () => track.scrollBy({ left: step(), behavior: reducedMotion() ? 'auto' : 'smooth' });
  track.addEventListener('scroll', update, { passive: true });
  track.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') next.click(); if (e.key === 'ArrowLeft') prev.click(); });
  addEventListener('resize', update);
  update();
}
