// Core: API client, global state, formatting, icons, toasts, WhatsApp links.

export class ApiError extends Error {
  constructor(status, data) { super(data?.error || 'Request failed'); this.status = status; this.data = data; }
}

export async function api(path, { method = 'GET', body, signal } = {}) {
  const res = await fetch('/api' + path, {
    method, signal, credentials: 'same-origin',
    headers: { 'X-Requested-With': 'teqnest', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

// ---------- state ----------
const listeners = new Map();
export const state = { settings: null, categories: [], user: null, cart: null, wishlist: new Set() };
export function on(evt, fn) { (listeners.get(evt) || listeners.set(evt, new Set()).get(evt)).add(fn); return () => listeners.get(evt).delete(fn); }
export function emit(evt, data) { listeners.get(evt)?.forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } }); }

export function setCart(cart) { state.cart = cart; emit('cart', cart); }
export async function refreshCart() { setCart(await api('/cart')); return state.cart; }
export async function refreshUser() {
  const { user } = await api('/account/me');
  state.user = user;
  state.wishlist = new Set(user ? await api('/account/wishlist/ids') : guestWishlist());
  emit('user', user); emit('wishlist', state.wishlist);
}

// Guests keep a local wishlist (per-device convenience); it is merged into the account on login.
const WL_KEY = 'tq_wishlist';
function guestWishlist() { try { return JSON.parse(localStorage.getItem(WL_KEY) || '[]').filter(Number.isInteger); } catch { return []; } }
function saveGuestWishlist() { try { localStorage.setItem(WL_KEY, JSON.stringify([...state.wishlist])); } catch { /* storage unavailable */ } }
export async function mergeGuestWishlist() {
  const ids = guestWishlist();
  for (const id of ids) { try { await api(`/account/wishlist/${id}`, { method: 'POST' }); } catch { /* skip removed products */ } }
  try { localStorage.removeItem(WL_KEY); } catch { /* ignore */ }
}
export async function toggleWishlist(productId) {
  const has = state.wishlist.has(productId);
  if (state.user) await api(`/account/wishlist/${productId}`, { method: has ? 'DELETE' : 'POST' });
  has ? state.wishlist.delete(productId) : state.wishlist.add(productId);
  if (!state.user) saveGuestWishlist();
  emit('wishlist', state.wishlist);
  toast(has ? 'Removed from wishlist' : 'Saved to wishlist', 'ok');
  return !has;
}

// Recently viewed (per-device)
export function pushRecent(id) {
  try {
    const r = JSON.parse(localStorage.getItem('tq_recent') || '[]').filter((x) => x !== id);
    r.unshift(id); localStorage.setItem('tq_recent', JSON.stringify(r.slice(0, 12)));
  } catch { /* ignore */ }
}
export function getRecent() { try { return JSON.parse(localStorage.getItem('tq_recent') || '[]'); } catch { return []; } }

// ---------- helpers ----------
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);
export const rs = (n) => n == null ? '' : 'Rs ' + Number(n).toLocaleString('en-PK');
export const qs = (sel, root = document) => root.querySelector(sel);
export const qsa = (sel, root = document) => [...root.querySelectorAll(sel)];
export const safeUrl = (u) => (typeof u === 'string' && /^(\/(?!\/)|https:\/\/)/.test(u)) ? u : '#';
export const date = (s) => new Date(s.replace(' ', 'T') + (s.includes('Z') || s.includes('+') ? '' : 'Z')).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });
export const reducedMotion = () => document.documentElement.classList.contains('reduced');
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export function formData(form) {
  const o = {};
  for (const [k, v] of new FormData(form)) o[k] = v;
  form.querySelectorAll('input[type=checkbox]').forEach((c) => { if (c.name) o[c.name] = c.checked; });
  return o;
}
export function setBusy(btn, busy, label) {
  if (!btn) return;
  if (busy) { btn.dataset.label = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin"></span>${label ? `<span>${esc(label)}</span>` : ''}`; }
  else { btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
}

// ---------- toasts ----------
export function toast(msg, kind = '') {
  let box = qs('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.append(box); }
  const t = document.createElement('div');
  t.className = `toast ${kind}`;
  t.textContent = msg;
  box.append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, 3200);
}

// ---------- WhatsApp ----------
export function waNumber() { return String(state.settings?.contact?.whatsapp || '').replace(/\D/g, ''); }
export function waLink(text) {
  const n = waNumber();
  return n ? `https://wa.me/${n}?text=${encodeURIComponent(text)}` : null;
}
export function waProductText(p, { qty = 1, color = '' } = {}) {
  return `Hi TEQNEST! I'd like to ask about:\n\n• ${p.name}${color ? ` (${color})` : ''}\n• SKU: ${p.sku}\n• Quantity: ${qty}\n• Status: ${p.availability_label}${p.price != null ? `\n• Listed price: ${rs(p.price)}` : ''}\n\n${location.origin}/product/${p.slug}`;
}
export function waCartText(cart) {
  return `Hi TEQNEST! I need help with my cart:\n\n${cart.items.map((i) => `• ${i.product.name}${i.color ? ` (${i.color})` : ''} × ${i.qty} — ${rs(i.line_total)}`).join('\n')}\n\nSubtotal: ${rs(cart.subtotal)}`;
}
// Only non-sensitive order details: no address, phone, or payment references.
export function waOrderText(o) {
  return `Hi TEQNEST! I placed order ${o.order_number}.\n\n${o.items.map((i) => `• ${i.name}${i.color ? ` (${i.color})` : ''} × ${i.qty}`).join('\n')}\n\nTotal: ${rs(o.total)}\nPayment: ${o.payment_method_label}\nCity: ${o.city}\n\nPlease confirm my order.`;
}

// ---------- icons (inline SVG, stroke-based) ----------
const P = {
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  heart: '<path d="M12 20s-7-4.35-7-10a4 4 0 0 1 7-2.65A4 4 0 0 1 19 10c0 5.65-7 10-7 10Z"/>',
  bag: '<path d="M5 8h14l-1 12H6L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  chev: '<path d="m6 9 6 6 6-6"/>',
  left: '<path d="m15 18-6-6 6-6"/>', right: '<path d="m9 18 6-6-6-6"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  expand: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10Z"/>',
  select: '<path d="M12 2 3 7l9 5 9-5-9-5Z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>',
  cart: '<path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6"/><circle cx="10" cy="20" r="1"/><circle cx="17" cy="20" r="1"/>',
  support: '<path d="M4 14v-3a8 8 0 0 1 16 0v3"/><path d="M4 14a2 2 0 0 0 2 2h1v-5H6a2 2 0 0 0-2 2ZM20 14a2 2 0 0 1-2 2h-1v-5h1a2 2 0 0 1 2 2ZM17 16c0 2.5-2 4-5 4"/>',
  truck: '<path d="M2 6h11v10H2zM13 9h5l3 3v4h-8"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
  play: '<path d="M7 5v14l12-7L7 5Z"/>', cube: '<path d="m12 2 9 5v10l-9 5-9-5V7l9-5Z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
};
export const icon = (name, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || ''}</svg>`;
export const brandIcon = {
  whatsapp: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.05 4.91A9.82 9.82 0 0 0 12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.91-7.01Zm-7.01 15.24h-.01a8.23 8.23 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.82c0 4.54-3.7 8.23-8.23 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.78.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48a.92.92 0 0 0-.66.31c-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.22-.17-.47-.29Z"/></svg>',
  instagram: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
  facebook: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M13.5 21v-7.5h2.5l.4-3h-2.9V8.6c0-.87.24-1.46 1.49-1.46h1.6V4.46A21 21 0 0 0 14.27 4.3c-2.3 0-3.87 1.4-3.87 3.98v2.22H7.8v3h2.6V21h3.1Z"/></svg>',
  tiktok: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 0 1-2.59 2.5 2.6 2.6 0 0 1-2.6-2.6 2.6 2.6 0 0 1 3.37-2.48V9.66a5.73 5.73 0 0 0-.77-.05A5.69 5.69 0 0 0 4.17 15.3 5.69 5.69 0 0 0 9.86 21a5.69 5.69 0 0 0 5.69-5.69V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3a4.28 4.28 0 0 1-3.25-1.48Z"/></svg>',
  youtube: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.58 7.19a2.5 2.5 0 0 0-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42a2.5 2.5 0 0 0-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81a2.5 2.5 0 0 0 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42a2.5 2.5 0 0 0 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81ZM10 15V9l5.2 3L10 15Z"/></svg>',
};
export function stars(rating) {
  if (!rating) return '';
  const full = Math.round(rating.average);
  const s = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/></svg>';
  const e = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/></svg>';
  return `<span class="stars" aria-label="Rated ${rating.average} out of 5 from ${rating.count} review${rating.count === 1 ? '' : 's'}">${Array.from({ length: 5 }, (_, i) => i < full ? s : e).join('')}<span class="n">${rating.average} (${rating.count})</span></span>`;
}
