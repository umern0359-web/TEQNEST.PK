// Optional interactive 3D product viewer for .glb models uploaded in the admin.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

export async function mountViewer(container, url) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  container.append(renderer.domElement);
  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  const camera = new THREE.PerspectiveCamera(35, 1, 0.01, 100);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true; controls.autoRotate = !document.documentElement.classList.contains('reduced'); controls.autoRotateSpeed = 1.2; controls.enablePan = false;

  const gltf = await new GLTFLoader().loadAsync(url);
  const model = gltf.scene; scene.add(model);
  const box = new THREE.Box3().setFromObject(model); const size = box.getSize(new THREE.Vector3()).length(); const center = box.getCenter(new THREE.Vector3());
  model.position.sub(center);
  camera.position.set(0, size * 0.25, size * 1.4); camera.near = size / 100; camera.far = size * 20; camera.updateProjectionMatrix();
  controls.minDistance = size * 0.5; controls.maxDistance = size * 4;

  const resize = () => { const w = container.clientWidth, h = container.clientHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); };
  resize(); const ro = new ResizeObserver(resize); ro.observe(container);
  let raf; const loop = () => { raf = requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); }; loop();
  return () => { cancelAnimationFrame(raf); ro.disconnect(); controls.dispose(); renderer.dispose(); pmrem.dispose(); renderer.domElement.remove(); };
}
