// Cinematic hero: procedurally modelled products in a studio-lit dark environment.
// Adapts quality to the device, pauses off-screen, renders a single still frame for reduced-motion users.
import * as THREE from 'three';

export function canRun3D() {
  if (navigator.connection?.saveData) return false;
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch { return false; }
}

function tier() {
  const mem = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const small = Math.min(screen.width, screen.height) < 500;
  if (mem <= 2 || cores <= 4) return 0;          // low-end Android
  if (mem <= 4 || small) return 1;                // mid-range / phones
  return 2;                                       // desktop
}

function roundedRect(w, h, r) {
  const s = new THREE.Shape(); const x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function roundedBox(w, h, d, r, seg = 4) {
  const g = new THREE.ExtrudeGeometry(roundedRect(w - r * 2, h - r * 2, Math.min(r, (w - r * 2) / 2, (h - r * 2) / 2) * 0.9), { depth: d - r * 2, bevelEnabled: true, bevelThickness: r, bevelSize: r, bevelSegments: seg, curveSegments: seg * 2 });
  g.center(); return g;
}

function watchFaceTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 512;
  const x = c.getContext('2d');
  x.fillStyle = '#02040a'; x.fillRect(0, 0, 512, 512);
  const g = x.createLinearGradient(0, 0, 512, 512); g.addColorStop(0, '#397BFF'); g.addColorStop(1, '#00D9FF');
  x.lineCap = 'round';
  x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 26; x.beginPath(); x.arc(256, 256, 170, 0, Math.PI * 2); x.stroke();
  x.strokeStyle = g; x.beginPath(); x.arc(256, 256, 170, -Math.PI / 2, Math.PI * 1.1); x.stroke();
  x.strokeStyle = 'rgba(0,217,255,.5)'; x.lineWidth = 14; x.beginPath(); x.arc(256, 256, 130, -Math.PI / 2, Math.PI * 0.4); x.stroke();
  x.fillStyle = '#fff'; x.font = '700 96px Arial, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('10:09', 256, 250);
  x.fillStyle = '#A7AFBD'; x.font = '500 28px Arial, sans-serif'; x.fillText('TEQNEST', 256, 330);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}

export function initHero(container, { still = false } = {}) {
  const q = tier();
  const renderer = new THREE.WebGLRenderer({ antialias: q > 0, alpha: true, powerPreference: q === 2 ? 'high-performance' : 'low-power' });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, [1, 1.5, 2][q]));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.35;
  container.append(renderer.domElement);
  renderer.domElement.setAttribute('aria-hidden', 'true');

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
  camera.position.set(0, 0.3, 9);

  // Studio environment for realistic reflections (softboxes in a dark room)
  const pmrem = new THREE.PMREMGenerator(renderer);
  const env = new THREE.Scene();
  env.add(new THREE.Mesh(new THREE.BoxGeometry(30, 30, 30), new THREE.MeshBasicMaterial({ color: 0x05070b, side: THREE.BackSide })));
  const box = (color, intensity, pos, scale) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity), side: THREE.DoubleSide }));
    m.position.set(...pos); m.scale.set(...scale); m.lookAt(0, 0, 0); env.add(m);
  };
  box(0xffffff, 4.2, [0, 9, 4], [12, 3, 1]);       // top softbox
  box(0x397bff, 4.5, [-10, 1, 2], [3, 14, 1]);      // blue strip left
  box(0x00d9ff, 3.5, [10, -1, -2], [3, 12, 1]);     // cyan strip right
  box(0xffffff, 1.4, [0, -2, 12], [10, 4, 1]);      // front fill
  scene.environment = pmrem.fromScene(env, 0.04).texture;

  const rimA = new THREE.PointLight(0x397bff, 30, 20); rimA.position.set(-4, 2, -2); scene.add(rimA);
  const rimB = new THREE.PointLight(0x00d9ff, 22, 20); rimB.position.set(4, -1, -1); scene.add(rimB);

  const dark = new THREE.MeshPhysicalMaterial({ color: 0x343c4c, metalness: 0.6, roughness: 0.28, clearcoat: 1, clearcoatRoughness: 0.12 });
  const satin = new THREE.MeshPhysicalMaterial({ color: 0x3a4252, metalness: 0.25, roughness: 0.55, clearcoat: 0.4 });
  const silver = new THREE.MeshPhysicalMaterial({ color: 0xc9ced8, metalness: 1, roughness: 0.18 });
  const soft = new THREE.MeshStandardMaterial({ color: 0x0c0f15, roughness: 0.9 });
  const glow = new THREE.MeshBasicMaterial({ color: 0x00d9ff });
  const disposables = [dark, satin, silver, soft, glow];

  const root = new THREE.Group(); scene.add(root);
  const items = [];

  // --- Headphones ---
  const hp = new THREE.Group();
  const band = new THREE.Mesh(new THREE.TorusGeometry(1.05, 0.085, 20, 80, Math.PI), satin); band.position.y = 0.15; hp.add(band);
  const bandIn = new THREE.Mesh(new THREE.TorusGeometry(0.99, 0.05, 12, 60, Math.PI * 0.8), soft); bandIn.rotation.z = Math.PI * 0.1; bandIn.position.y = 0.15; hp.add(bandIn);
  for (const s of [-1, 1]) {
    const yoke = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.5, 12), silver); yoke.position.set(s * 1.05, -0.05, 0); hp.add(yoke);
    const cup = new THREE.Mesh(new THREE.CapsuleGeometry(0.36, 0.32, 8, 24), dark); cup.scale.set(1, 1, 0.55); cup.rotation.y = Math.PI / 2; cup.position.set(s * 1.05, -0.55, 0); hp.add(cup);
    const pad = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.1, 12, 32), soft); pad.scale.set(1, 1.35, 1); pad.rotation.y = Math.PI / 2; pad.position.set(s * 0.9, -0.55, 0); hp.add(pad);
    const led = new THREE.Mesh(new THREE.CircleGeometry(0.025, 12), glow); led.position.set(s * 1.26, -0.85, 0); led.rotation.y = s * Math.PI / 2; hp.add(led);
  }
  hp.scale.setScalar(0.95); hp.rotation.set(0.15, -0.5, 0.05);
  root.add(hp); items.push({ obj: hp, base: new THREE.Vector3(0.2, 0.75, 0), speed: 0.55, phase: 0, spin: 0.12 });

  // --- Smartwatch ---
  const sw = new THREE.Group();
  const caseM = new THREE.Mesh(roundedBox(1.0, 1.15, 0.32, 0.12), silver); sw.add(caseM);
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.96), new THREE.MeshBasicMaterial({ map: watchFaceTexture(), toneMapped: false })); screen.position.z = 0.165; sw.add(screen);
  disposables.push(screen.material.map, screen.material);
  const glass = new THREE.Mesh(roundedBox(0.92, 1.06, 0.03, 0.012, 2), new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: 0.02, transmission: q > 0 ? 0.9 : 0, transparent: true, opacity: q > 0 ? 1 : 0.12, clearcoat: 1 }));
  glass.position.z = 0.175; sw.add(glass); disposables.push(glass.material);
  const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.08, 20), silver); crown.rotation.z = Math.PI / 2; crown.position.set(0.53, 0.2, 0); sw.add(crown);
  for (const s of [-1, 1]) { const strap = new THREE.Mesh(roundedBox(0.78, 1.1, 0.12, 0.05), satin); strap.position.set(0, s * 1.05, -0.06); strap.rotation.x = s * 0.18; sw.add(strap); }
  sw.scale.setScalar(0.9); sw.rotation.set(-0.15, 0.45, -0.12);
  root.add(sw); items.push({ obj: sw, base: new THREE.Vector3(1.35, -0.75, 0.6), speed: 0.7, phase: 2, spin: -0.08 });

  // --- Earbuds case + buds ---
  const eb = new THREE.Group();
  const caseB = new THREE.Mesh(new THREE.CapsuleGeometry(0.42, 0.55, 10, 32), dark); caseB.rotation.z = Math.PI / 2; caseB.scale.set(0.82, 1, 0.55); eb.add(caseB);
  const ledC = new THREE.Mesh(new THREE.CircleGeometry(0.022, 12), glow); ledC.position.set(0, -0.08, 0.235); eb.add(ledC);
  for (const s of [-1, 1]) {
    const bud = new THREE.Group();
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 24, 24), dark); head.scale.set(1, 1, 0.85); bud.add(head);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 16), soft); tip.position.set(-s * 0.06, 0.02, -0.12); bud.add(tip);
    const stem = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.32, 6, 12), dark); stem.position.set(0, -0.26, 0.02); bud.add(stem);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.056, 0.056, 0.03, 16), silver); cap.position.set(0, -0.48, 0.02); bud.add(cap);
    bud.position.set(s * 0.32, 0.62, 0.05); bud.rotation.set(0.2, s * 0.6, s * 0.25);
    eb.add(bud);
  }
  eb.scale.setScalar(0.95); eb.rotation.set(0.35, -0.35, 0.05);
  root.add(eb); items.push({ obj: eb, base: new THREE.Vector3(-0.85, -1.15, 0.3), speed: 0.6, phase: 4, spin: 0.1 });

  // Reflective floor glow
  const floor = new THREE.Mesh(new THREE.CircleGeometry(4, 48), new THREE.MeshBasicMaterial({ color: 0x397bff, transparent: true, opacity: 0.08, depthWrite: false }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -2.1; root.add(floor); disposables.push(floor.material);

  // Particles
  const N = [180, 380, 700][q];
  const pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) { pos[i * 3] = (Math.random() - 0.5) * 16; pos[i * 3 + 1] = (Math.random() - 0.5) * 9; pos[i * 3 + 2] = (Math.random() - 0.5) * 8 - 2; }
  const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pm = new THREE.PointsMaterial({ color: 0x7fb2ff, size: 0.022, transparent: true, opacity: 0.7, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
  const points = new THREE.Points(pg, pm); scene.add(points); disposables.push(pg, pm);

  // Layout
  let layoutX = 0, layoutY = 0, layoutS = 1;
  function resize() {
    const w = container.clientWidth, h = container.clientHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    if (w < 760) { layoutX = 0.1; layoutY = 1.8; layoutS = Math.min(0.6, w / 760); }
    else { layoutX = Math.min(2.4, (w / h) * 1.15); layoutY = 0.05; layoutS = w < 1100 ? 0.85 : 1; }
    root.position.set(layoutX, layoutY, 0); root.scale.setScalar(layoutS);
  }
  resize();
  const ro = new ResizeObserver(resize); ro.observe(container);

  // Interaction
  const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
  const onMove = (e) => { mouse.tx = (e.clientX / innerWidth - 0.5) * 2; mouse.ty = (e.clientY / innerHeight - 0.5) * 2; };
  addEventListener('pointermove', onMove, { passive: true });
  let scrollP = 0;
  const onScroll = () => { scrollP = Math.min(1, scrollY / (container.clientHeight || 1)); };
  addEventListener('scroll', onScroll, { passive: true });

  const t0 = performance.now();
  let visible = true, raf = 0, intro = 0;
  function frame() {
    const t = (performance.now() - t0) / 1000;
    intro = Math.min(1, intro + 0.012);
    const ease = 1 - Math.pow(1 - intro, 3);
    mouse.x += (mouse.tx - mouse.x) * 0.04; mouse.y += (mouse.ty - mouse.y) * 0.04;
    for (const it of items) {
      it.obj.position.set(it.base.x, it.base.y + Math.sin(t * it.speed + it.phase) * 0.12 - (1 - ease) * 1.5, it.base.z);
      it.obj.rotation.y += it.spin * 0.01;
      it.obj.rotation.x += Math.sin(t * 0.3 + it.phase) * 0.0006;
    }
    // slow cinematic camera drift + parallax
    camera.position.x = Math.sin(t * 0.08) * 0.6 + mouse.x * 0.35;
    camera.position.y = 0.3 + Math.cos(t * 0.06) * 0.25 - mouse.y * 0.25;
    camera.position.z = 9 - ease * 0.6 + scrollP * 1.5;
    camera.lookAt(layoutX * 0.55, layoutY * 0.5 - scrollP * 0.6, 0);
    root.rotation.y = mouse.x * 0.08;
    points.rotation.y = t * 0.012; points.position.y = scrollP * 1.2;
    rimA.intensity = 26 + Math.sin(t * 0.7) * 6;
    renderer.render(scene, camera);
  }
  function loop() { raf = requestAnimationFrame(loop); if (visible && !document.hidden) frame(); }

  if (still) { intro = 1; frame(); } else loop();

  const vis = new IntersectionObserver(([e]) => { visible = e.isIntersecting; }, { threshold: 0 });
  vis.observe(container);

  return function dispose() {
    cancelAnimationFrame(raf); ro.disconnect(); vis.disconnect();
    removeEventListener('pointermove', onMove); removeEventListener('scroll', onScroll);
    scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    disposables.forEach((d) => d.dispose?.());
    scene.environment?.dispose(); pmrem.dispose();
    renderer.dispose(); renderer.domElement.remove();
  };
}
