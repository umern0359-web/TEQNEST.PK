import { api, state, esc, qs, qsa, icon, rs } from '../core.js';
import { productCard, bindProductCards, reveal } from '../ui.js';

const AV = [['in_stock', 'In Stock'], ['preorder', 'Pre-order'], ['coming_soon', 'Coming Soon'], ['on_request', 'Available on Request'], ['out_of_stock', 'Out of Stock']];
const SORTS = [['featured', 'Featured'], ['newest', 'Newest'], ['popular', 'Best selling'], ['price_asc', 'Price: low to high'], ['price_desc', 'Price: high to low'], ['name', 'Name A–Z']];

export async function shopView(main, { category, newArrivals, navigate }) {
  const params = new URLSearchParams(location.search);
  const cat = category ? state.categories.find((c) => c.slug === category) : null;
  if (category && !cat) return false; // 404
  const q = params.get('q') || '';
  const title = newArrivals ? 'New Arrivals' : cat ? cat.name : q ? `Results for “${q}”` : 'Shop All';
  const desc = newArrivals ? 'The latest additions to the TEQNEST collection.' : cat ? cat.description : q ? '' : 'Explore the full TEQNEST collection.';

  main.innerHTML = `<div class="wrap">
    <div class="page-head"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span aria-hidden="true">/</span><a href="/shop">Shop</a>${cat || newArrivals ? `<span aria-hidden="true">/</span><span aria-current="page">${esc(title)}</span>` : ''}</nav>
      <h1 class="h-lg">${esc(title)}</h1>${desc ? `<p class="muted" style="margin:10px 0 0;max-width:560px">${esc(desc)}</p>` : ''}</div>
    <div class="shop">
      <aside class="filters" aria-label="Filters" data-filters>
        <div class="f-sheet-head" style="display:none;justify-content:space-between;align-items:center"><h2 class="h-md">Filters</h2><button class="icon-btn" data-close-f aria-label="Close filters">${icon('close')}</button></div>
        <div class="f-group"><h3>Category</h3><div class="f-list">
          <a href="/shop${q ? `?q=${encodeURIComponent(q)}` : ''}" ${!cat && !newArrivals ? 'aria-current="page"' : ''}>All products</a>
          ${state.categories.map((c) => `<a href="/shop/${esc(c.slug)}" ${cat?.slug === c.slug ? 'aria-current="page"' : ''}>${esc(c.name)} <span class="tiny muted">${c.product_count}</span></a>`).join('')}
          <a href="/new-arrivals" ${newArrivals ? 'aria-current="page"' : ''}>New Arrivals</a></div></div>
        <form data-ff>
          <div class="f-group"><h3>Availability</h3><div class="f-list">${AV.map(([v, l]) => `<label class="check"><input type="checkbox" name="availability" value="${v}" ${params.get('availability')?.split(',').includes(v) ? 'checked' : ''}> ${l}</label>`).join('')}</div></div>
          <div class="f-group"><h3>Price (PKR)</h3><div class="price-inputs"><input class="input" name="min" type="number" min="0" inputmode="numeric" placeholder="Min" value="${esc(params.get('min') || '')}" aria-label="Minimum price"><input class="input" name="max" type="number" min="0" inputmode="numeric" placeholder="Max" value="${esc(params.get('max') || '')}" aria-label="Maximum price"></div></div>
          <div class="f-group"><label class="check"><input type="checkbox" name="on_sale" value="1" ${params.get('on_sale') ? 'checked' : ''}> On sale</label></div>
          <div style="display:flex;gap:8px;padding-top:16px"><button class="btn btn-primary btn-sm" style="flex:1" type="submit">Apply</button><button class="btn btn-ghost btn-sm" type="button" data-clear>Clear</button></div>
        </form>
      </aside>
      <div>
        <div class="toolbar">
          <span class="count" aria-live="polite" data-count>Loading…</span>
          <div style="display:flex;gap:8px;align-items:center">
            <button class="btn btn-ghost btn-sm" data-open-f style="display:none">${icon('filter').replace('<svg', '<svg width="16"')} Filters</button>
            <label class="sr-only" for="sort">Sort by</label>
            <select class="input" id="sort" style="height:42px;width:auto;font-size:14px">${SORTS.map(([v, l]) => `<option value="${v}" ${(params.get('sort') || (newArrivals ? 'newest' : 'featured')) === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
          </div>
        </div>
        <div class="chips" data-chips></div>
        <div class="p-grid" data-grid>${'<div class="skel" style="aspect-ratio:3/4.4"></div>'.repeat(6)}</div>
        <nav class="pager" data-pager aria-label="Pagination"></nav>
      </div>
    </div></div>`;

  // Mobile filter sheet
  const filters = qs('[data-filters]', main);
  const mq = matchMedia('(max-width: 999px)');
  const syncBtn = () => { qs('[data-open-f]', main).style.display = mq.matches ? 'inline-flex' : 'none'; };
  syncBtn(); mq.addEventListener('change', syncBtn);
  const closeSheet = () => { filters.classList.remove('sheet'); qs('.f-sheet-head', filters).style.display = 'none'; document.body.classList.remove('lock'); };
  qs('[data-open-f]', main).onclick = () => { filters.classList.add('sheet'); qs('.f-sheet-head', filters).style.display = 'flex'; document.body.classList.add('lock'); };
  qs('[data-close-f]', main).onclick = closeSheet;

  const go = (mut) => {
    const p = new URLSearchParams(location.search);
    mut(p); p.delete('page');
    if (!p.get('sort') || p.get('sort') === (newArrivals ? 'newest' : 'featured')) p.delete('sort');
    closeSheet();
    navigate(location.pathname + (p.toString() ? `?${p}` : ''), { replace: true, keepScroll: true });
  };
  qs('#sort', main).onchange = (e) => go((p) => p.set('sort', e.target.value));
  qs('[data-ff]', main).onsubmit = (e) => {
    e.preventDefault(); const f = e.target;
    go((p) => {
      const av = qsa('input[name=availability]:checked', f).map((x) => x.value);
      av.length ? p.set('availability', av.join(',')) : p.delete('availability');
      for (const k of ['min', 'max']) f[k].value ? p.set(k, Math.max(0, Number(f[k].value))) : p.delete(k);
      f.on_sale.checked ? p.set('on_sale', '1') : p.delete('on_sale');
    });
  };
  qs('[data-clear]', main).onclick = () => go((p) => { for (const k of ['availability', 'min', 'max', 'on_sale']) p.delete(k); });
  // Auto-apply checkbox filters on desktop for instant feedback
  qsa('[data-ff] input[type=checkbox]', main).forEach((c) => c.addEventListener('change', () => { if (!mq.matches) qs('[data-ff]', main).requestSubmit(); }));

  // Active filter chips
  const chips = [];
  if (q) chips.push(['q', `Search: ${q}`]);
  if (params.get('availability')) chips.push(['availability', params.get('availability').split(',').map((a) => AV.find((x) => x[0] === a)?.[1]).filter(Boolean).join(', ')]);
  if (params.get('min') || params.get('max')) chips.push(['price', `${params.get('min') ? rs(params.get('min')) : 'Rs 0'} – ${params.get('max') ? rs(params.get('max')) : 'any'}`]);
  if (params.get('on_sale')) chips.push(['on_sale', 'On sale']);
  const chipEl = qs('[data-chips]', main);
  chipEl.innerHTML = chips.map(([k, l]) => `<span class="chip">${esc(l)}<button data-chip="${k}" aria-label="Remove filter ${esc(l)}">${icon('close').replace('<svg', '<svg width="14"')}</button></span>`).join('');
  chipEl.onclick = (e) => { const b = e.target.closest('[data-chip]'); if (!b) return; go((p) => { const k = b.dataset.chip; if (k === 'price') { p.delete('min'); p.delete('max'); } else p.delete(k); }); };

  // Fetch
  const apiParams = new URLSearchParams();
  for (const k of ['q', 'sort', 'min', 'max', 'availability', 'on_sale', 'page']) if (params.get(k)) apiParams.set(k, params.get(k));
  if (cat) apiParams.set('category', cat.slug);
  if (newArrivals) { apiParams.set('new', '1'); if (!params.get('sort')) apiParams.set('sort', 'newest'); }
  apiParams.set('limit', '24');
  const r = await api(`/products?${apiParams}`);
  const grid = qs('[data-grid]', main); if (!grid) return true;
  qs('[data-count]', main).textContent = `${r.total} product${r.total === 1 ? '' : 's'}`;
  grid.innerHTML = r.products.length ? r.products.map((p, i) => productCard(p, { cls: 'reveal' }).replace('class="p-card reveal"', `class="p-card reveal" style="--d:${(i % 3) * 0.05}s"`)).join('')
    : `<div class="empty-state" style="grid-column:1/-1"><h3>No products found</h3><p>Try removing a filter or searching for something else.</p><a class="btn btn-ghost" href="/shop">View all products</a></div>`;
  bindProductCards(grid, r.products);
  // pagination
  if (r.pages > 1) {
    const link = (n) => { const p = new URLSearchParams(location.search); n > 1 ? p.set('page', n) : p.delete('page'); return `${location.pathname}${p.toString() ? `?${p}` : ''}`; };
    const pageNums = [];
    for (let n = 1; n <= r.pages; n++) if (n === 1 || n === r.pages || Math.abs(n - r.page) <= 1) pageNums.push(n); else if (pageNums.at(-1) !== '…') pageNums.push('…');
    qs('[data-pager]', main).innerHTML = (r.page > 1 ? `<a href="${link(r.page - 1)}" aria-label="Previous page">${icon('left').replace('<svg', '<svg width="16"')}</a>` : '') +
      pageNums.map((n) => n === '…' ? '<span>…</span>' : n === r.page ? `<span class="cur" aria-current="page">${n}</span>` : `<a href="${link(n)}">${n}</a>`).join('') +
      (r.page < r.pages ? `<a href="${link(r.page + 1)}" aria-label="Next page">${icon('right').replace('<svg', '<svg width="16"')}</a>` : '');
  }
  reveal(main);
  return true;
}
