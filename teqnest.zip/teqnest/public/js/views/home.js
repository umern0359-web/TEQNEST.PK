import { api, state, esc, qs, qsa, icon, safeUrl, reducedMotion, date, stars, toast, setBusy } from '../core.js';
import { productCard, bindProductCards, reveal, carousel, tiltAll } from '../ui.js';

let disposeHero = null;
export function cleanupHome() { disposeHero?.(); disposeHero = null; }

const featIcon = { select: 'select', cart: 'cart', support: 'support', truck: 'truck' };

export async function homeView(main) {
  const s = state.settings;
  const hero = s.hero || {}; const hs = s.home_sections || {}; const story = s.brand_story || {}; const promo = s.promo || {};
  const cats = state.categories.filter((c) => c.show_on_home);

  main.innerHTML = `
  <section class="hero" aria-label="Introduction">
    <div class="hero-fallback" aria-hidden="true"><div class="hf-prods">
      <img src="/img/products/headphones-graphite-1.svg" alt=""><img src="/img/products/earbuds-white-1.svg" alt=""><img src="/img/products/watch-blue-2.svg" alt="">
    </div></div>
    <div class="hero-canvas" aria-hidden="true"></div>
    <div class="wrap"><div class="hero-inner">
      <div class="eyebrow h-anim">${esc(hero.eyebrow || 'TEQNEST.PK')}</div>
      <h1 class="h-xl"><span class="line"><span class="h-anim">${esc(hero.line1 || 'UPGRADE YOUR')}</span></span><span class="line"><span class="h-anim grad-text">${esc(hero.line2 || 'EVERYDAY TECH.')}</span></span></h1>
      <p class="lead h-anim">${esc(hero.description || '')}</p>
      <div class="hero-ctas h-anim">
        <a class="btn btn-primary" href="${esc(safeUrl(hero.primary?.url || '/shop'))}">${esc(hero.primary?.label || 'Explore Collection')} ${icon('arrow')}</a>
        <a class="btn btn-ghost" href="${esc(safeUrl(hero.secondary?.url || '/about'))}">${esc(hero.secondary?.label || 'Discover TEQNEST')}</a>
      </div>
    </div></div>
    <a class="hero-scroll" href="#categories" aria-label="Scroll to categories"><span>Scroll</span><i></i></a>
  </section>

  <section class="section" id="categories" style="padding-top:clamp(40px,6vw,80px)">
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Collections</div><h2 class="h-lg" style="margin-top:12px">${esc(hs.categories_heading || 'SHOP BY CATEGORY')}</h2></div><a class="link-arrow" href="/shop">All products ${icon('arrow')}</a></div>
      <div class="cat-grid">${cats.map((c, i) => `
        <a class="cat-card reveal" style="--d:${(i % 3) * 0.08}s" href="/shop/${esc(c.slug)}" data-tilt="6">
          <img src="${esc(safeUrl(c.image))}" alt="" loading="lazy" decoding="async" width="600" height="700">
          <span class="cat-count">${c.product_count} item${c.product_count === 1 ? '' : 's'}</span>
          <div class="cat-body"><h3>${esc(c.name)}</h3><p>${esc(c.description || '')}</p><span class="cat-cta">Explore ${icon('arrow').replace('<svg', '<svg width="14"')}</span></div>
        </a>`).join('')}</div>
    </div>
  </section>

  <section class="section" style="padding-top:0" aria-labelledby="trending-h">
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Trending</div><h2 class="h-lg" id="trending-h" style="margin-top:12px">${esc(hs.trending_heading || "TECH EVERYONE'S TALKING ABOUT.")}</h2></div><a class="link-arrow" href="/shop?sort=popular">See more ${icon('arrow')}</a></div>
      <div class="p-grid cols-4" data-trending>${'<div class="skel" style="aspect-ratio:3/4.4"></div>'.repeat(4)}</div>
    </div>
  </section>

  <section class="section" aria-labelledby="story-h">
    <div class="wrap split">
      <div class="split-media reveal" data-parallax><img src="${esc(safeUrl(story.image || '/img/products/watch-blue-1.svg'))}" alt="" loading="lazy"><div class="orb"></div></div>
      <div class="reveal" style="--d:.1s">
        <div class="eyebrow">The TEQNEST Experience</div>
        <h2 class="h-lg" id="story-h" style="margin:14px 0 22px">${esc(story.heading || '')}</h2>
        ${(story.paragraphs || []).map((p) => `<p class="muted" style="font-size:17px">${esc(p)}</p>`).join('')}
        <ul class="points">${(story.points || []).map((p) => `<li><i>${icon('check')}</i>${esc(p)}</li>`).join('')}</ul>
        ${story.cta ? `<a class="btn btn-ghost" href="${esc(safeUrl(story.cta.url))}">${esc(story.cta.label)} ${icon('arrow')}</a>` : ''}
      </div>
    </div>
  </section>

  <section class="section" aria-labelledby="new-h" style="padding-top:0">
    <div class="wrap carousel" data-carousel>
      <div class="section-head reveal"><div><div class="eyebrow">Just landed</div><h2 class="h-lg" id="new-h" style="margin-top:12px">${esc(hs.new_heading || 'NEW ARRIVALS')}</h2></div>
        <div class="c-nav"><button data-prev aria-label="Previous products">${icon('left')}</button><button data-next aria-label="Next products">${icon('right')}</button></div></div>
      <div class="c-track" data-new tabindex="0" aria-label="New arrivals carousel">${'<div class="skel" style="aspect-ratio:3/4.4"></div>'.repeat(4)}</div>
      <div class="c-progress" aria-hidden="true"><i></i></div>
    </div>
  </section>

  ${promo.enabled ? `<section class="section" style="padding-top:0"><div class="wrap"><div class="promo reveal">
    <div><div class="eyebrow">${esc(promo.eyebrow || '')}</div><h2 class="h-lg" style="margin-top:14px">${esc(promo.heading || '')}</h2><p>${esc(promo.text || '')}</p>
      <a class="btn btn-primary" href="${esc(safeUrl(promo.cta_url || '/shop'))}">${esc(promo.cta_label || 'Shop Now')} ${icon('arrow')}</a></div>
    ${promo.image ? `<img src="${esc(safeUrl(promo.image))}" alt="" loading="lazy">` : ''}</div></div></section>` : ''}

  <section class="section" style="padding-top:0" aria-labelledby="why-h">
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Why us</div><h2 class="h-lg" id="why-h" style="margin-top:12px">${esc(hs.why_heading || 'WHY CHOOSE TEQNEST?')}</h2></div></div>
      <div class="feat-grid">${(s.why_choose || []).map((f, i) => `<div class="feat reveal" style="--d:${i * 0.08}s"><div class="ico">${icon(featIcon[f.icon] || 'check')}</div><h3>${esc(f.title)}</h3><p>${esc(f.text)}</p></div>`).join('')}</div>
    </div>
  </section>

  <section class="section" style="padding-top:0" aria-labelledby="rev-h" data-reviews-section>
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Verified reviews</div><h2 class="h-lg" id="rev-h" style="margin-top:12px">${esc(hs.reviews_heading || 'FROM OUR CUSTOMERS')}</h2></div></div>
      <div data-reviews></div>
    </div>
  </section>

  <section class="section" style="padding-top:0" aria-labelledby="news-h">
    <div class="wrap"><div class="news reveal">
      <div class="eyebrow">Newsletter</div>
      <h2 class="h-lg" id="news-h" style="margin-top:14px">${esc(hs.newsletter_heading || "STAY AHEAD OF WHAT'S NEXT.")}</h2>
      <p class="muted">${esc(hs.newsletter_text || '')}</p>
      <form data-news novalidate><label class="sr-only" for="news-email">Email address</label><input id="news-email" type="email" name="email" placeholder="you@example.com" required autocomplete="email"><button class="btn btn-primary btn-sm" type="submit">Subscribe</button></form>
      <div class="msg" role="status" aria-live="polite"></div>
    </div></div>
  </section>`;

  // Hero: 3D when capable, otherwise the static fallback stays
  startHero(main);
  heroIntro(main);

  // Newsletter
  const nf = qs('[data-news]', main);
  nf.onsubmit = async (e) => {
    e.preventDefault();
    const msg = qs('.news .msg', main); const btn = qs('button', nf);
    const email = nf.email.value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { msg.textContent = 'Please enter a valid email address.'; msg.style.color = 'var(--danger)'; return; }
    setBusy(btn, true);
    try { const r = await api('/newsletter', { method: 'POST', body: { email } }); msg.textContent = r.message; msg.style.color = 'var(--ok)'; nf.reset(); }
    catch (err) { msg.textContent = err.message; msg.style.color = 'var(--danger)'; }
    finally { setBusy(btn, false); }
  };

  reveal(main); tiltAll(main); parallax(main);

  // Data
  const [trending, fresh, reviews] = await Promise.all([
    api('/products?trending=1&limit=4&sort=featured').then((r) => r.products.length ? r : api('/products?limit=4&sort=featured')),
    api('/products?new=1&limit=12&sort=newest'),
    api('/reviews/featured').catch(() => []),
  ]);
  const tEl = qs('[data-trending]', main);
  if (!tEl) return; // navigated away
  tEl.innerHTML = trending.products.map((p, i) => productCard(p, { cls: 'reveal' }).replace('class="p-card reveal"', `class="p-card reveal" style="--d:${(i % 4) * 0.06}s"`)).join('') || '<div class="empty-state">Products coming soon.</div>';
  const nEl = qs('[data-new]', main);
  nEl.innerHTML = fresh.products.map((p) => productCard(p)).join('') || '<div class="empty-state">New arrivals coming soon.</div>';
  bindProductCards(main, [...trending.products, ...fresh.products]);
  carousel(qs('[data-carousel]', main));
  const rEl = qs('[data-reviews]', main);
  rEl.innerHTML = reviews.length
    ? `<div class="rev-grid">${reviews.slice(0, 6).map((r, i) => `<figure class="rev reveal" style="--d:${(i % 3) * 0.08}s;margin:0">${stars({ average: r.rating, count: 1 }).replace(/<span class="n">.*?<\/span>/, '')}
        ${r.title ? `<strong>${esc(r.title)}</strong>` : ''}<blockquote>${esc(r.body)}</blockquote>
        <footer><span>${esc(r.name)} · <a href="/product/${esc(r.product_slug)}" style="text-decoration:underline">${esc(r.product_name)}</a></span><span class="verified">${icon('shield')} Verified purchase</span></footer></figure>`).join('')}</div>`
    : `<div class="empty-state reveal"><h3>Reviews from verified buyers will appear here</h3><p>Customers can review products from their delivered orders. We only show genuine, moderated reviews.</p></div>`;
  reveal(main);
}

async function startHero(main) {
  const holder = qs('.hero-canvas', main); const heroEl = qs('.hero', main);
  if (state.settings.hero?.enable_3d === false) return;
  try {
    const mod = await import('../hero3d.js');
    if (!mod.canRun3D() || !holder.isConnected) return;
    disposeHero = mod.initHero(holder, { still: reducedMotion() });
    requestAnimationFrame(() => heroEl.classList.add('has-3d'));
  } catch (e) { console.warn('3D hero unavailable, using fallback', e); }
}

function heroIntro(main) {
  const els = qsa('.h-anim', main);
  if (reducedMotion() || !window.gsap) return;
  window.gsap.from(els, { yPercent: 110, opacity: 0, duration: 1.2, ease: 'expo.out', stagger: 0.09, delay: 0.1, clearProps: 'all' });
}

function parallax(main) {
  if (reducedMotion() || !window.gsap || !window.ScrollTrigger) return;
  window.gsap.registerPlugin(window.ScrollTrigger);
  qsa('[data-parallax] img', main).forEach((img) => {
    window.gsap.fromTo(img, { yPercent: -8 }, { yPercent: 8, ease: 'none', scrollTrigger: { trigger: img.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } });
  });
}
export function killScrollTriggers() { window.ScrollTrigger?.getAll().forEach((t) => t.kill()); }
