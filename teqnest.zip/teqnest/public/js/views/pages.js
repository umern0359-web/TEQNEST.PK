import { state, esc, qs } from '../core.js';
import { reveal } from '../ui.js';

const POLICIES = { privacy: 'privacy', terms: 'terms', shipping: 'shipping', returns: 'returns' };

function page(main, eyebrow, title, html) {
  main.innerHTML = `<div class="wrap" style="padding-bottom:80px"><div class="page-head"><div class="eyebrow">${esc(eyebrow)}</div><h1 class="h-lg">${esc(title)}</h1></div><div class="reveal">${html}</div></div>`;
  reveal(main);
  return true;
}
const paras = (body) => `<div class="prose-page">${String(body || '').split(/\n{2,}/).map((p) => `<p>${esc(p)}</p>`).join('')}</div>`;

export function policyView(main, { key }) {
  const k = POLICIES[key]; if (!k) return false;
  const pg = state.settings.pages?.[k]; if (!pg) return false;
  return page(main, 'Policies', pg.title, paras(pg.body));
}
export function aboutView(main) {
  const pg = state.settings.pages?.about || { title: 'About TEQNEST', body: '' };
  const story = state.settings.brand_story || {};
  return page(main, state.settings.brand?.tagline || 'About', pg.title, `<div class="split" style="align-items:start"><div>${paras(pg.body)}<a class="btn btn-primary" href="/shop" style="margin-top:12px">Explore the Collection</a></div>
    <div class="split-media"><img src="${esc(story.image || '/img/products/watch-blue-1.svg')}" alt="" loading="lazy" style="transform:none"><div class="orb"></div></div></div>`);
}
export function faqView(main) {
  const f = state.settings.pages?.faq || { title: 'FAQ', items: [] };
  const r = page(main, 'Help', f.title || 'FAQ', `<div class="faq" style="max-width:820px">${(f.items || []).map((it) => `<details><summary>${esc(it.q)}</summary><p>${esc(it.a)}</p></details>`).join('')}</div>
    <p class="muted" style="margin-top:32px">Still have a question? <a href="/track" style="color:var(--cyan)">Track an order</a> or message us on WhatsApp using the button at the bottom of the page.</p>`);
  qs('details', main)?.setAttribute('open', '');
  return r;
}
export function notFoundView(main) {
  main.innerHTML = `<div class="wrap"><div class="empty-state" style="margin:80px auto;max-width:560px"><div class="h-xl grad-text" style="font-size:96px">404</div><h3>Page not found</h3><p>The page you're looking for doesn't exist or has moved.</p><a class="btn btn-primary" href="/shop">Go to Shop</a></div></div>`;
  document.title = 'Page not found | TEQNEST';
  return true;
}
