import { api, state, esc, qs, qsa, icon, rs, safeUrl, stars, toast, toggleWishlist, waLink, waProductText, pushRecent, getRecent, date, setBusy, brandIcon, ApiError } from '../core.js';
import { productCard, bindProductCards, addToCart, reveal, tiltAll } from '../ui.js';

function videoEmbed(url) {
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  if (yt) return { type: 'iframe', src: `https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0` , thumb: `https://i.ytimg.com/vi/${yt[1]}/hqdefault.jpg` };
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return { type: 'iframe', src: `https://player.vimeo.com/video/${vm[1]}`, thumb: null };
  return { type: 'video', src: url, thumb: null };
}

let cleanup = [];
export function cleanupProduct() { cleanup.forEach((f) => f()); cleanup = []; document.body.classList.remove('has-sticky'); }

export async function productView(main, { slug, navigate }) {
  let p;
  try { p = await api(`/products/${encodeURIComponent(slug)}`); }
  catch (e) { if (e instanceof ApiError && e.status === 404) return false; throw e; }
  pushRecent(p.id);

  const media = [
    ...p.images.map((src) => ({ type: 'img', src })),
    ...p.videos.map((v) => videoEmbed(v)),
    ...(p.model_url ? [{ type: '3d', src: p.model_url }] : []),
  ];
  if (!media.length) media.push({ type: 'img', src: '/img/products/tracker-graphite-1.svg' });
  let idx = 0; let color = p.colors[0]?.name || ''; let qty = 1;
  const wa = () => waLink(waProductText(p, { qty, color }));
  const stockLine = p.availability === 'in_stock'
    ? (p.low_stock ? `<strong>Only a few left.</strong> Order soon.` : `<strong>In stock</strong> and ready to order.`)
    : { preorder: '<strong>Pre-order.</strong> This item is not yet in stock; your order will be dispatched once stock arrives. We will contact you about timing.',
      coming_soon: '<strong>Coming soon.</strong> This product is not available to buy yet. Message us on WhatsApp to be notified.',
      on_request: '<strong>Available on request.</strong> This product is not currently held in stock. Send us an inquiry and we will tell you about availability.',
      out_of_stock: '<strong>Out of stock.</strong> Message us on WhatsApp to ask about a restock.' }[p.availability];

  main.innerHTML = `<div class="wrap">
    <div class="page-head" style="padding-bottom:20px"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span aria-hidden="true">/</span><a href="/shop">Shop</a>${p.category ? `<span aria-hidden="true">/</span><a href="/shop/${esc(p.category.slug)}">${esc(p.category.name)}</a>` : ''}<span aria-hidden="true">/</span><span aria-current="page">${esc(p.name)}</span></nav></div>
    <div class="pdp">
      <div class="gallery">
        <div class="g-main" data-main tabindex="0" aria-label="Product media. Use arrow keys to browse, Enter for fullscreen." aria-roledescription="carousel"></div>
        <div class="g-thumbs" role="tablist" aria-label="Product media thumbnails">${media.map((m, i) => `<button role="tab" data-i="${i}" aria-current="${i === 0}" aria-label="${m.type === 'img' ? `Image ${i + 1}` : m.type === '3d' ? '3D view' : 'Video'}">${m.type === 'img' ? `<img src="${esc(safeUrl(m.src))}" alt="" loading="lazy">` : m.thumb ? `<img src="${esc(m.thumb)}" alt="" loading="lazy"><span class="play">VIDEO</span>` : `<img src="${esc(safeUrl(p.images[0] || ''))}" alt=""><span class="play">${m.type === '3d' ? '3D' : 'VIDEO'}</span>`}</button>`).join('')}</div>
      </div>
      <div class="pdp-info">
        ${p.category ? `<a class="eyebrow" href="/shop/${esc(p.category.slug)}">${esc(p.category.name)}</a>` : ''}
        <h1>${esc(p.name)}</h1>
        <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">${stars(p.rating)}<span class="tiny muted">SKU: ${esc(p.sku)}</span></div>
        <div class="pdp-price">${p.price != null ? `<span class="price">${rs(p.price)}</span>${p.discount_percent ? `<span class="price-old">${rs(p.regular_price)}</span><span class="tag tag-sale">Save ${p.discount_percent}%</span>` : ''}` : '<span class="h-md muted">Price on request</span>'}</div>
        ${p.short_description ? `<p class="muted" style="margin:0;font-size:17px">${esc(p.short_description)}</p>` : ''}
        <div class="avail-box"><span class="stock ${p.low_stock ? 'low' : p.availability}" style="margin-bottom:6px">${p.low_stock ? 'Low stock' : esc(p.availability_label)}</span><div>${stockLine}</div></div>
        ${p.colors.length ? `<div><div class="label" style="margin-bottom:10px">Colour: <span data-cname style="color:var(--text)">${esc(color)}</span></div><div class="swatches" role="group" aria-label="Colour">${p.colors.map((c, i) => `<button class="swatch" aria-pressed="${i === 0}" data-color="${esc(c.name)}"><i style="background:${esc(c.hex)}"></i>${esc(c.name)}</button>`).join('')}</div></div>` : ''}
        ${p.purchasable ? `<div><div class="label" style="margin-bottom:10px">Quantity</div><div class="qty lg" role="group" aria-label="Quantity"><button data-q="-1" aria-label="Decrease quantity">${icon('minus')}</button><input type="number" value="1" min="1" max="${p.max_qty}" data-qty aria-label="Quantity" inputmode="numeric"><button data-q="1" aria-label="Increase quantity">${icon('plus')}</button></div></div>` : ''}
        <div class="buy-row" data-buy>
          ${p.purchasable ? `<button class="btn btn-primary" data-add>${p.availability === 'preorder' ? 'Pre-order Now' : 'Add to Cart'}</button><button class="btn btn-ghost" data-buynow>Buy Now</button>` : ''}
          <button class="icon-btn ${state.wishlist.has(p.id) ? 'on' : ''}" data-wish aria-pressed="${state.wishlist.has(p.id)}" aria-label="Add to wishlist">${icon('heart')}</button>
        </div>
        ${wa() ? `<a class="btn btn-wa ${p.purchasable ? 'btn-ghost' : ''}" data-wa href="${esc(wa())}" target="_blank" rel="noopener" style="${p.purchasable ? 'background:none;border:1px solid #1fae5b;color:#2fd277' : ''}">${brandIcon.whatsapp.replace('<svg', '<svg width="18"')} ${p.purchasable ? 'Ask on WhatsApp' : 'Inquire on WhatsApp'}</a>` : (!p.purchasable ? `<div class="notice">Contact us to enquire about this product${state.settings.contact?.email ? `: <a href="mailto:${esc(state.settings.contact.email)}">${esc(state.settings.contact.email)}</a>` : '.'}</div>` : '')}

        <div style="margin-top:12px">
          <div class="tabs" role="tablist">${[['desc', 'Overview'], ['specs', 'Specifications'], ['box', "What's in the box"], ['reviews', `Reviews${p.rating ? ` (${p.rating.count})` : ''}`]].map(([k, l], i) => `<button role="tab" id="tab-${k}" aria-controls="panel-${k}" aria-selected="${i === 0}" data-tab="${k}" tabindex="${i === 0 ? 0 : -1}">${l}</button>`).join('')}</div>
          <div class="tab-panel" role="tabpanel" id="panel-desc" aria-labelledby="tab-desc">
            ${p.features.length ? `<h3 class="h-md" style="font-size:18px;margin-bottom:14px">Key features</h3><ul class="check-list" style="margin-bottom:22px">${p.features.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}
            <div class="prose">${esc(p.description || '')}</div></div>
          <div class="tab-panel" role="tabpanel" id="panel-specs" aria-labelledby="tab-specs" hidden>${p.specs.length ? `<table class="spec-table"><tbody>${p.specs.map((s) => `<tr><th scope="row">${esc(s.label)}</th><td>${esc(s.value)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">Specifications will be added soon.</p>'}</div>
          <div class="tab-panel" role="tabpanel" id="panel-box" aria-labelledby="tab-box" hidden>${p.in_box.length ? `<ul class="check-list">${p.in_box.map((f) => `<li>${esc(f)}</li>`).join('')}</ul>` : '<p class="muted">Box contents will be listed soon.</p>'}</div>
          <div class="tab-panel" role="tabpanel" id="panel-reviews" aria-labelledby="tab-reviews" hidden data-reviews><div class="skel" style="height:120px"></div></div>
        </div>
      </div>
    </div>
    <section class="section" style="padding-top:40px" data-related-sec hidden><div class="section-head"><h2 class="h-md">You may also like</h2></div><div class="p-grid cols-4" data-related></div></section>
    <section class="section" style="padding-top:0" data-recent-sec hidden><div class="section-head"><h2 class="h-md">Recently viewed</h2></div><div class="p-grid cols-4" data-recent></div></section>
  </div>
  ${p.purchasable ? `<div class="sticky-buy" data-sticky><div class="sb-name">${esc(p.name)}<div class="tiny muted">${rs(p.price)}</div></div><button class="btn btn-primary btn-sm" data-sticky-add>${p.availability === 'preorder' ? 'Pre-order' : 'Add to Cart'}</button></div>` : ''}`;

  // ----- gallery -----
  const mainEl = qs('[data-main]', main);
  let viewerDispose = null;
  function show(i) {
    idx = (i + media.length) % media.length;
    viewerDispose?.(); viewerDispose = null;
    const m = media[idx];
    mainEl.classList.remove('zoom');
    const nav = media.length > 1 ? `<button class="icon-btn g-arrow prev" data-g="-1" aria-label="Previous">${icon('left')}</button><button class="icon-btn g-arrow next" data-g="1" aria-label="Next">${icon('right')}</button>` : '';
    if (m.type === 'img') mainEl.innerHTML = `<img src="${esc(safeUrl(m.src))}" alt="${esc(p.name)} — image ${idx + 1} of ${media.length}" width="900" height="900">${nav}<div class="g-btns"><button class="icon-btn" data-fs aria-label="View fullscreen">${icon('expand')}</button></div>`;
    else if (m.type === 'iframe') mainEl.innerHTML = `<iframe src="${esc(m.src)}" title="${esc(p.name)} video" allow="accelerometer; encrypted-media; picture-in-picture" allowfullscreen loading="lazy"></iframe>${nav}`;
    else if (m.type === 'video') mainEl.innerHTML = `<video src="${esc(safeUrl(m.src))}" controls playsinline preload="metadata"></video>${nav}`;
    else { mainEl.innerHTML = `<div style="position:absolute;inset:0;display:grid;place-items:center" class="muted small">Loading 3D model…</div>${nav}`; load3D(m.src); }
    mainEl.style.cursor = m.type === 'img' ? 'zoom-in' : 'default';
    qsa('.g-thumbs button', main).forEach((b, j) => b.setAttribute('aria-current', j === idx));
    qs(`.g-thumbs button[data-i="${idx}"]`, main)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  async function load3D(src) {
    try {
      const mod = await import('../viewer3d.js');
      if (media[idx].type !== '3d') return;
      viewerDispose = await mod.mountViewer(mainEl, src);
      qs('.muted', mainEl)?.remove();
    } catch (e) { console.error(e); mainEl.innerHTML = '<div style="position:absolute;inset:0;display:grid;place-items:center" class="muted small">3D view could not be loaded on this device.</div>'; }
  }
  cleanup.push(() => viewerDispose?.());
  show(0);
  qs('.g-thumbs', main).onclick = (e) => { const b = e.target.closest('[data-i]'); if (b) show(Number(b.dataset.i)); };
  mainEl.addEventListener('click', (e) => {
    const g = e.target.closest('[data-g]'); if (g) { e.stopPropagation(); show(idx + Number(g.dataset.g)); return; }
    if (e.target.closest('[data-fs]')) { openLightbox(); return; }
    if (media[idx].type !== 'img' || e.target.closest('button')) return;
    if (matchMedia('(hover: hover)').matches) mainEl.classList.toggle('zoom'); else openLightbox();
  });
  mainEl.addEventListener('pointermove', (e) => {
    if (!mainEl.classList.contains('zoom')) return;
    const r = mainEl.getBoundingClientRect();
    mainEl.style.setProperty('--zx', `${((e.clientX - r.left) / r.width) * 100}%`); mainEl.style.setProperty('--zy', `${((e.clientY - r.top) / r.height) * 100}%`);
  });
  mainEl.addEventListener('pointerleave', () => mainEl.classList.remove('zoom'));
  mainEl.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight') show(idx + 1); if (e.key === 'ArrowLeft') show(idx - 1); if (e.key === 'Enter' && media[idx].type === 'img') openLightbox(); });
  swipe(mainEl, (d) => { if (media[idx].type !== '3d') show(idx + d); });

  function openLightbox() {
    const imgs = media.map((m, i) => ({ ...m, i })).filter((m) => m.type === 'img');
    if (!imgs.length) return;
    let k = Math.max(0, imgs.findIndex((m) => m.i === idx));
    const lb = document.createElement('div'); lb.className = 'lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Image viewer');
    lb.innerHTML = `<img alt=""><button class="icon-btn lb-close" aria-label="Close">${icon('close')}</button>${imgs.length > 1 ? `<button class="icon-btn lb-prev" aria-label="Previous image">${icon('left')}</button><button class="icon-btn lb-next" aria-label="Next image">${icon('right')}</button>` : ''}<div class="lb-count"></div>`;
    document.body.append(lb); document.body.classList.add('lock');
    const render = () => { qs('img', lb).src = safeUrl(imgs[k].src); qs('img', lb).alt = `${p.name} — image ${k + 1}`; qs('.lb-count', lb).textContent = `${k + 1} / ${imgs.length}`; };
    const close = () => { lb.classList.remove('open'); document.body.classList.remove('lock'); setTimeout(() => lb.remove(), 300); document.removeEventListener('keydown', key); mainEl.focus(); };
    const key = (e) => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') { k = (k + 1) % imgs.length; render(); } if (e.key === 'ArrowLeft') { k = (k - 1 + imgs.length) % imgs.length; render(); } };
    lb.onclick = (e) => { if (e.target.closest('.lb-close') || e.target === lb) close(); if (e.target.closest('.lb-next')) { k = (k + 1) % imgs.length; render(); } if (e.target.closest('.lb-prev')) { k = (k - 1 + imgs.length) % imgs.length; render(); } };
    swipe(lb, (d) => { k = (k + d + imgs.length) % imgs.length; render(); });
    document.addEventListener('keydown', key);
    render(); requestAnimationFrame(() => lb.classList.add('open')); qs('.lb-close', lb).focus();
  }

  // ----- options -----
  const waEl = qs('[data-wa]', main);
  const refreshWa = () => { if (waEl) waEl.href = wa(); };
  qsa('[data-color]', main).forEach((b) => b.onclick = () => { color = b.dataset.color; qsa('[data-color]', main).forEach((x) => x.setAttribute('aria-pressed', x === b)); qs('[data-cname]', main).textContent = color; refreshWa(); });
  const qtyInput = qs('[data-qty]', main);
  const setQty = (v) => { qty = Math.max(1, Math.min(p.max_qty || 1, Math.floor(v) || 1)); if (qtyInput) qtyInput.value = qty; refreshWa(); };
  qsa('[data-q]', main).forEach((b) => b.onclick = () => setQty(qty + Number(b.dataset.q)));
  qtyInput?.addEventListener('change', () => setQty(Number(qtyInput.value)));

  const add = qs('[data-add]', main);
  if (add) add.onclick = () => addToCart(p, { qty, color, btn: add });
  const bn = qs('[data-buynow]', main);
  if (bn) bn.onclick = async () => { if (await addToCart(p, { qty, color, btn: bn, open: false })) navigate('/checkout'); };
  const sa = qs('[data-sticky-add]', main);
  if (sa) sa.onclick = () => addToCart(p, { qty, color, btn: sa });
  const wishBtn = qs('[data-wish]', main);
  wishBtn.onclick = async () => { try { const onNow = await toggleWishlist(p.id); wishBtn.classList.toggle('on', onNow); wishBtn.setAttribute('aria-pressed', onNow); } catch (e) { toast(e.message, 'err'); } };

  // sticky buy bar on mobile once main CTA scrolls out
  const sticky = qs('[data-sticky]', main);
  if (sticky) {
    const io = new IntersectionObserver(([e]) => { const on = !e.isIntersecting && e.boundingClientRect.top < 0; sticky.classList.toggle('on', on); document.body.classList.toggle('has-sticky', on); });
    io.observe(qs('[data-buy]', main)); cleanup.push(() => io.disconnect());
  }

  // ----- tabs -----
  const tabs = qsa('[data-tab]', main);
  const select = (t) => { tabs.forEach((x) => { const on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1; qs(`#panel-${x.dataset.tab}`, main).hidden = !on; }); t.focus(); };
  tabs.forEach((t, i) => { t.onclick = () => select(t); t.onkeydown = (e) => { if (e.key === 'ArrowRight') select(tabs[(i + 1) % tabs.length]); if (e.key === 'ArrowLeft') select(tabs[(i - 1 + tabs.length) % tabs.length]); }; });

  // ----- reviews -----
  loadReviews(main, p).then(() => {
    if (location.hash === '#review') { const t = qs('[data-tab="reviews"]', main); select(t); t.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  });

  // ----- related + recently viewed -----
  const [rel, rec] = await Promise.all([
    p.category ? api(`/products?category=${p.category.slug}&exclude=${p.id}&limit=4`) : { products: [] },
    (() => { const ids = getRecent().filter((x) => x !== p.id).slice(0, 4); return ids.length ? api(`/products?ids=${ids.join(',')}&limit=4`) : { products: [] }; })(),
  ]);
  const relEl = qs('[data-related]', main); if (!relEl) return true;
  let relProducts = rel.products;
  if (relProducts.length < 4) { const more = await api(`/products?exclude=${p.id}&limit=8&sort=featured`); relProducts = [...relProducts, ...more.products.filter((x) => !relProducts.some((y) => y.id === x.id))].slice(0, 4); }
  if (relProducts.length) { qs('[data-related-sec]', main).hidden = false; relEl.innerHTML = relProducts.map((x) => productCard(x, { cls: 'reveal' })).join(''); }
  const order = getRecent();
  const recents = rec.products.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
  if (recents.length) { qs('[data-recent-sec]', main).hidden = false; qs('[data-recent]', main).innerHTML = recents.map((x) => productCard(x, { cls: 'reveal' })).join(''); }
  bindProductCards(qs('[data-related-sec]', main).parentElement, [...relProducts, ...recents]);
  reveal(main); tiltAll(main);
  return true;
}

async function loadReviews(main, p) {
  const el = qs('[data-reviews]', main);
  const reviews = await api(`/products/${encodeURIComponent(p.slug)}/reviews`).catch(() => []);
  const list = reviews.length
    ? reviews.map((r) => `<div class="rev" style="margin-bottom:12px">${stars({ average: r.rating, count: 1 }).replace(/<span class="n">.*?<\/span>/, '')}${r.title ? `<strong>${esc(r.title)}</strong>` : ''}<p style="margin:0">${esc(r.body)}</p><footer><span>${esc(r.name)} · ${date(r.created_at)}</span><span class="verified">${icon('shield')} Verified purchase</span></footer></div>`).join('')
    : '<p class="muted">No reviews yet. Reviews can be written by customers who have received this product.</p>';
  let form = '';
  if (p.can_review) {
    form = `<form class="card" data-review style="margin-top:18px;display:grid;gap:14px"><h3 class="h-md" style="font-size:18px">Write a review</h3>
      <fieldset style="border:0;padding:0;margin:0"><legend class="label" style="margin-bottom:6px">Your rating</legend><div class="rating-input">${[5, 4, 3, 2, 1].map((n) => `<input type="radio" id="rt${n}" name="rating" value="${n}" required><label for="rt${n}" title="${n} star${n > 1 ? 's' : ''}">★</label>`).join('')}</div></fieldset>
      <div class="field"><label for="rv-title">Title (optional)</label><input class="input" id="rv-title" name="title" maxlength="120"></div>
      <div class="field"><label for="rv-body">Your review</label><textarea class="input" id="rv-body" name="body" required minlength="10" maxlength="2000"></textarea></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary" type="submit">Submit Review</button></form>`;
  } else if (!state.user) {
    form = `<p class="small muted" style="margin-top:14px">Bought this product? <a href="/account/login?next=${encodeURIComponent(location.pathname)}" style="color:var(--cyan)">Log in</a> to review it once your order is delivered.</p>`;
  }
  el.innerHTML = list + form;
  const f = qs('[data-review]', el);
  if (f) f.onsubmit = async (e) => {
    e.preventDefault(); const btn = qs('button[type=submit]', f); const err = qs('.form-err', f);
    const rating = Number(new FormData(f).get('rating'));
    if (!rating) { err.textContent = 'Please choose a rating.'; return; }
    setBusy(btn, true); err.textContent = '';
    try { const r = await api('/account/reviews', { method: 'POST', body: { product_id: p.id, rating, title: f.title.value, body: f.body.value } }); f.outerHTML = `<div class="notice ok" style="margin-top:14px">${esc(r.message)}</div>`; }
    catch (ex) { err.textContent = ex.message; setBusy(btn, false); }
  };
}

function swipe(el, cb) {
  let x0 = null, y0 = 0;
  el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (x0 == null) return;
    const dx = e.changedTouches[0].clientX - x0; const dy = e.changedTouches[0].clientY - y0;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) cb(dx < 0 ? 1 : -1);
    x0 = null;
  }, { passive: true });
}
