import { api, state, esc, qs, qsa, icon, rs, safeUrl, toast, setCart, refreshCart, waLink, waCartText, waOrderText, formData, setBusy, date, on, brandIcon } from '../core.js';
import { lineItemHTML, bindCartLines, freeDeliveryHTML } from '../ui.js';

let offCart = null;
export function cleanupCheckout() { offCart?.(); offCart = null; }

function summaryRows(c) {
  return `<div class="sum-row"><span>Subtotal</span><span>${rs(c.subtotal)}</span></div>
    ${c.discount ? `<div class="sum-row"><span>Discount (${esc(c.coupon.code)})</span><span style="color:var(--ok)">−${rs(c.discount)}</span></div>` : ''}
    <div class="sum-row"><span>Delivery${c.zone_id ? ` (${esc(c.zones.find((z) => z.id === c.zone_id)?.name || '')})` : ''}</span><span>${c.delivery_fee == null ? 'Select area' : c.delivery_fee === 0 ? 'Free' : rs(c.delivery_fee)}</span></div>
    <div class="sum-row total"><span>Total</span><span>${rs(c.total)}</span></div>`;
}
function couponHTML(c) {
  return c.coupon
    ? `<div class="notice ok" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><span>Code <strong>${esc(c.coupon.code)}</strong> applied</span><button class="li-remove" data-rm-coupon style="margin:0">Remove</button></div>`
    : `<form class="coupon-row" data-coupon><label class="sr-only" for="coupon">Discount code</label><input class="input" id="coupon" name="code" placeholder="Discount code" autocomplete="off" style="text-transform:uppercase"><button class="btn btn-ghost" type="submit">Apply</button></form>${c.coupon_error ? `<div class="form-err" style="margin-top:8px">${esc(c.coupon_error)}</div>` : ''}`;
}
function bindCoupon(root) {
  root.addEventListener('submit', async (e) => {
    const f = e.target.closest('[data-coupon]'); if (!f) return;
    e.preventDefault(); const btn = qs('button', f); const code = f.code.value.trim();
    if (!code) return;
    setBusy(btn, true);
    try { setCart(await api('/cart/coupon', { method: 'POST', body: { code } })); toast('Discount applied', 'ok'); }
    catch (err) { toast(err.message, 'err'); setBusy(btn, false); }
  });
  root.addEventListener('click', async (e) => {
    if (!e.target.closest('[data-rm-coupon]')) return;
    setCart(await api('/cart/coupon', { method: 'POST', body: { code: '' } }));
  });
}

// ---------------- Cart page ----------------
export async function cartView(main) {
  main.innerHTML = `<div class="wrap"><div class="page-head"><h1 class="h-lg">Your Cart</h1></div><div data-cart-page></div></div>`;
  const host = qs('[data-cart-page]', main);
  const render = (c) => {
    if (!c.items.length) { host.innerHTML = `<div class="empty-state" style="margin-bottom:80px"><h3>Your cart is empty</h3><p>Browse our collection to find your next upgrade.</p><a class="btn btn-primary" href="/shop">Shop Now</a></div>`; return; }
    const wa = waLink(waCartText(c));
    host.innerHTML = `<div class="co"><section class="card">${c.items.map(lineItemHTML).join('')}</section>
      <aside class="card" style="display:grid;gap:14px"><h2 class="h-md" style="font-size:20px">Order Summary</h2>
        ${freeDeliveryHTML(c)}
        <div class="field"><label for="zone">Delivery area</label><select class="input" id="zone" data-zone><option value="">Select delivery area</option>${c.zones.map((z) => `<option value="${z.id}" ${z.id === c.zone_id ? 'selected' : ''}>${esc(z.name)} — ${z.fee ? rs(z.fee) : 'Free'}${z.free_threshold != null ? ` (free over ${rs(z.free_threshold)})` : ''}</option>`).join('')}</select></div>
        ${couponHTML(c)}${summaryRows(c)}
        ${c.issues.length ? `<div class="notice warn">${c.issues.map((i) => `${esc(i.name)}: ${esc(i.message)}`).join('<br>')}<br>Please update or remove these items to continue.</div>` : ''}
        <a class="btn btn-primary btn-block" href="/checkout" ${c.can_checkout ? '' : 'aria-disabled="true"'}>Proceed to Checkout</a>
        ${wa ? `<a class="btn btn-wa btn-block" href="${esc(wa)}" target="_blank" rel="noopener">${brandIcon.whatsapp.replace('<svg', '<svg width="18"')} Ask about this cart</a>` : ''}
        <a class="link-arrow" href="/shop" style="justify-self:center">Continue shopping ${icon('arrow')}</a>
      </aside></div>`;
  };
  bindCartLines(host); bindCoupon(host);
  host.addEventListener('change', async (e) => { if (e.target.matches('[data-zone]')) setCart(await api('/cart/zone', { method: 'POST', body: { zone_id: e.target.value || null } })); });
  offCart = on('cart', render);
  render(await refreshCart());
  return true;
}

// ---------------- Checkout ----------------
export async function checkoutView(main, { navigate }) {
  const c = await refreshCart();
  if (!c.items.length) { navigate('/cart', { replace: true }); return true; }
  const u = state.user;
  const addresses = u ? await api('/account/addresses').catch(() => []) : [];
  const def = addresses.find((a) => a.is_default) || addresses[0] || {};
  const pay = Object.entries(state.settings.payments || {}).filter(([, v]) => v.enabled);
  const field = (name, label, attrs = '', val = '', hint = '') => `<div class="field ${attrs.includes('span') ? 'span-2' : ''}"><label for="co-${name}">${label}</label>${attrs.includes('textarea') ? `<textarea class="input" id="co-${name}" name="${name}" ${attrs.replace('textarea', '').replace('span', '')}>${esc(val)}</textarea>` : `<input class="input" id="co-${name}" name="${name}" value="${esc(val)}" ${attrs.replace('span', '')}>`}${hint ? `<span class="hint">${hint}</span>` : ''}</div>`;

  main.innerHTML = `<div class="wrap">
    <div class="page-head"><nav class="crumbs" aria-label="Breadcrumb"><a href="/cart">Cart</a><span aria-hidden="true">/</span><span aria-current="page">Checkout</span></nav><h1 class="h-lg">Checkout</h1>
      ${!u ? `<p class="muted" style="margin:10px 0 0">Checking out as a guest. <a href="/account/login?next=/checkout" style="color:var(--cyan)">Log in</a> to save addresses and track orders in your account.</p>` : ''}</div>
    <form class="co" data-co novalidate>
      <div>
        <section class="card"><h2><span class="num">1</span>Contact & Delivery</h2>
          ${addresses.length ? `<div class="field" style="margin-bottom:16px"><label for="co-saved">Saved address</label><select class="input" id="co-saved" data-saved>${addresses.map((a) => `<option value="${a.id}" ${a.id === def.id ? 'selected' : ''}>${esc(a.label || 'Address')} — ${esc(a.address)}, ${esc(a.city)}</option>`).join('')}<option value="">Use a new address</option></select></div>` : ''}
          <div class="form-grid two">
            ${field('full_name', 'Full name *', 'required autocomplete="name" maxlength="120" span', def.full_name || u?.name || '')}
            ${field('phone', 'Mobile number *', 'required type="tel" inputmode="tel" autocomplete="tel" placeholder="03XX XXXXXXX"', def.phone || u?.phone || '')}
            ${field('whatsapp', 'WhatsApp number', 'type="tel" inputmode="tel" placeholder="If different from mobile"', def.whatsapp || '')}
            ${field('email', 'Email (optional)', 'type="email" autocomplete="email" span', u?.email || '', 'We will email your order confirmation if provided.')}
            ${field('address', 'Complete delivery address *', 'required textarea rows="2" autocomplete="street-address" maxlength="500" span', def.address || '', 'House/flat number, street, block/sector, landmark')}
            ${field('city', 'City *', 'required autocomplete="address-level2" list="cities"', def.city || '')}
            ${field('area', 'Area', 'autocomplete="address-level3" placeholder="e.g. Gulshan-e-Iqbal"', def.area || '')}
            ${field('postal_code', 'Postal code (optional)', 'inputmode="numeric" autocomplete="postal-code" maxlength="10"', def.postal_code || '')}
          </div>
          <datalist id="cities">${['Karachi', 'Lahore', 'Islamabad', 'Rawalpindi', 'Faisalabad', 'Multan', 'Peshawar', 'Quetta', 'Hyderabad', 'Sialkot', 'Gujranwala'].map((x) => `<option value="${x}">`).join('')}</datalist>
        </section>
        <section class="card"><h2><span class="num">2</span>Delivery Area</h2><div style="display:grid;gap:10px" data-zones></div></section>
        <section class="card"><h2><span class="num">3</span>Payment</h2><div style="display:grid;gap:10px" data-pay>
          ${pay.length ? pay.map(([k, v], i) => `<label class="radio-card" data-pm="${k}"><input type="radio" name="payment_method" value="${k}" ${i === 0 ? 'checked' : ''} required><div><div class="rc-title">${esc(v.label)}</div>${v.instructions && k !== 'cod' ? `<div class="rc-sub">You'll get payment instructions after placing the order. Your order is confirmed once we verify the payment.</div>` : k === 'cod' ? `<div class="rc-sub">${esc(v.instructions || 'Pay when your order arrives.')}</div>` : ''}</div></label>`).join('') : '<div class="notice warn">Online ordering is temporarily unavailable. Please contact us on WhatsApp.</div>'}
        </div></section>
        <section class="card">${field('notes', 'Order notes (optional)', 'textarea rows="2" maxlength="1000" span', '', 'Delivery instructions or anything we should know')}
          ${u ? `<label class="check" style="padding-left:0;margin-top:10px"><input type="checkbox" name="save_address" ${addresses.length ? '' : 'checked'}> Save this address to my account</label>` : ''}</section>
      </div>
      <aside class="card" style="display:grid;gap:14px" data-summary></aside>
    </form></div>`;

  const form = qs('[data-co]', main);
  const saved = qs('[data-saved]', main);
  if (saved) saved.onchange = () => {
    const a = addresses.find((x) => String(x.id) === saved.value) || {};
    for (const k of ['full_name', 'phone', 'whatsapp', 'address', 'city', 'area', 'postal_code']) form[k].value = a[k] || (k === 'full_name' ? u?.name || '' : '');
    if (a.zone_id) setZone(a.zone_id);
  };

  const zonesEl = qs('[data-zones]', main); const sumEl = qs('[data-summary]', main);
  const renderZones = (cart) => {
    zonesEl.innerHTML = cart.zones.length ? cart.zones.map((z) => {
      const free = z.free_threshold != null && cart.subtotal - cart.discount >= z.free_threshold;
      return `<label class="radio-card"><input type="radio" name="zone_id" value="${z.id}" ${z.id === cart.zone_id ? 'checked' : ''} required><div><div class="rc-title">${esc(z.name)}</div><div class="rc-sub">${esc(z.description || '')}${z.free_threshold != null ? ` · Free over ${rs(z.free_threshold)}` : ''}${!z.cod_available ? ' · Cash on Delivery not available' : ''}</div></div><span class="rc-right">${free || !z.fee ? 'Free' : rs(z.fee)}</span></label>`;
    }).join('') : '<div class="notice warn">Delivery is not currently configured. Please contact us on WhatsApp to order.</div>';
    // COD availability per zone
    const zone = cart.zones.find((z) => z.id === cart.zone_id);
    const cod = qs('[data-pm="cod"]', main);
    if (cod) {
      const off = zone && !zone.cod_available;
      cod.classList.toggle('disabled', !!off); qs('input', cod).disabled = !!off;
      if (off && qs('input', cod).checked) { const alt = qs('[data-pay] input:not(:disabled)', main); if (alt) alt.checked = true; }
    }
  };
  const renderSummary = (cart) => {
    sumEl.innerHTML = `<h2 class="h-md" style="font-size:20px">Order Summary</h2>
      <div>${cart.items.map((i) => `<div class="mini-line"><img src="${esc(safeUrl(i.product.image))}" alt="" width="56" height="56"><div><div style="font-weight:600;font-size:14px;line-height:1.3">${esc(i.product.name)}</div><div class="tiny muted">${i.color ? `${esc(i.color)} · ` : ''}Qty ${i.qty}${i.product.availability === 'preorder' ? ' · Pre-order' : ''}</div>${i.problem ? `<div class="tiny" style="color:var(--danger)">${esc(i.problem)}</div>` : ''}</div><div style="font-weight:600">${rs(i.line_total)}</div></div>`).join('')}</div>
      ${couponHTML(cart)}${summaryRows(cart)}
      ${cart.issues.length ? `<div class="notice warn">Some items are no longer available in the requested quantity. <a href="/cart" style="text-decoration:underline">Update your cart</a>.</div>` : ''}
      <div class="form-err" role="alert" data-err></div>
      <button class="btn btn-primary btn-block" type="submit" ${cart.can_checkout && pay.length ? '' : 'disabled'}>Place Order · ${rs(cart.total)}</button>
      <p class="tiny muted" style="margin:0;text-align:center">By placing your order you agree to our <a href="/policy/terms" style="text-decoration:underline">Terms</a> and <a href="/policy/privacy" style="text-decoration:underline">Privacy Policy</a>.</p>`;
  };
  const render = (cart) => { renderZones(cart); renderSummary(cart); };
  async function setZone(id) { setCart(await api('/cart/zone', { method: 'POST', body: { zone_id: Number(id) } })); }
  zonesEl.addEventListener('change', (e) => { if (e.target.name === 'zone_id') setZone(e.target.value); });
  bindCoupon(sumEl);
  offCart = on('cart', render);
  render(c);
  if (!c.zone_id && def.zone_id) setZone(def.zone_id);
  else if (!c.zone_id && c.zones.length === 1) setZone(c.zones[0].id);

  form.onsubmit = async (e) => {
    e.preventDefault();
    const err = qs('[data-err]', main); err.textContent = '';
    qsa('[aria-invalid]', form).forEach((x) => x.removeAttribute('aria-invalid'));
    // client-side checks (server re-validates everything)
    const d = formData(form);
    const bad = [];
    if (!d.full_name?.trim()) bad.push(['full_name', 'Please enter your full name.']);
    if (!/^(?:\+?92|0)?3\d{9}$/.test((d.phone || '').replace(/[\s-]/g, ''))) bad.push(['phone', 'Please enter a valid Pakistani mobile number, e.g. 0300 1234567.']);
    if (d.whatsapp && !/^(?:\+?92|0)?3\d{9}$/.test(d.whatsapp.replace(/[\s-]/g, ''))) bad.push(['whatsapp', 'WhatsApp number is not valid.']);
    if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email)) bad.push(['email', 'Email address is not valid.']);
    if ((d.address || '').trim().length < 8) bad.push(['address', 'Please enter your complete delivery address.']);
    if (!d.city?.trim()) bad.push(['city', 'Please enter your city.']);
    if (!d.zone_id) bad.push(['zone_id', 'Please select your delivery area.']);
    if (!d.payment_method) bad.push(['payment_method', 'Please choose a payment method.']);
    if (bad.length) {
      err.textContent = bad[0][1];
      bad.forEach(([k]) => form[k]?.setAttribute?.('aria-invalid', 'true'));
      const first = form[bad[0][0]]; (first?.focus ? first : first?.[0])?.focus?.();
      return;
    }
    const btn = qs('button[type=submit]', sumEl);
    setBusy(btn, true, 'Placing order…');
    try {
      const r = await api('/checkout', { method: 'POST', body: d });
      try { sessionStorage.setItem(`tq_order_${r.order_number}`, r.access_token); } catch { /* ignore */ }
      setCart(await api('/cart'));
      navigate(`/order/${r.order_number}?t=${encodeURIComponent(r.access_token)}&new=1`, { replace: true });
    } catch (ex) {
      err.textContent = ex.message;
      if (ex.data?.issues) await refreshCart();
      setBusy(btn, false);
    }
  };
  return true;
}

// ---------------- Order confirmation / detail ----------------
const STEPS = ['pending', 'confirmed', 'shipped', 'delivered'];
export function orderStatusHTML(o) {
  const at = o.status === 'processing' ? 1 : STEPS.indexOf(o.status);
  if (o.status === 'cancelled') return `<div class="notice warn">This order was cancelled.</div>`;
  return `<div class="status-steps">${STEPS.map((_, i) => `<div class="${i <= at ? 'on' : ''}"></div>`).join('')}</div><div class="status-labels">${['Received', 'Confirmed', 'Shipped', 'Delivered'].map((l, i) => `<span class="${i <= at ? 'on' : ''}">${l}</span>`).join('')}</div>`;
}
export function orderDetailHTML(o, { showAddress = true, allowPayRef = true } = {}) {
  return `<div class="co" style="padding-bottom:0">
    <div style="display:grid;gap:20px">
      <section class="card"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center"><h2 class="h-md" style="font-size:20px">Order ${esc(o.order_number)}</h2><span class="pill ${o.status}">${esc(o.status_label)}</span></div>
        <p class="tiny muted" style="margin:6px 0 0">Placed ${date(o.created_at)}</p>${orderStatusHTML(o)}
        ${o.tracking ? `<div class="notice" style="margin-top:14px">Shipped${o.tracking.carrier ? ` via <strong>${esc(o.tracking.carrier)}</strong>` : ''} · Tracking: <strong>${esc(o.tracking.number)}</strong>${o.tracking.url ? ` · <a href="${esc(safeUrl(o.tracking.url))}" target="_blank" rel="noopener" style="text-decoration:underline">Track shipment</a>` : ''}</div>` : ''}
      </section>
      <section class="card"><h3 class="h-md" style="font-size:18px;margin-bottom:8px">Items</h3>${o.items.map((i) => `<div class="mini-line"><img src="${esc(safeUrl(i.image || ''))}" alt="" width="56" height="56"><div><div style="font-weight:600;font-size:14px">${esc(i.name)}</div><div class="tiny muted">${i.color ? `${esc(i.color)} · ` : ''}${rs(i.unit_price)} × ${i.qty}${i.is_preorder ? ' · Pre-order' : ''}</div></div><div style="font-weight:600">${rs(i.unit_price * i.qty)}</div></div>`).join('')}
        <div style="display:grid;gap:8px;margin-top:12px"><div class="sum-row"><span>Subtotal</span><span>${rs(o.subtotal)}</span></div>${o.discount ? `<div class="sum-row"><span>Discount${o.coupon_code ? ` (${esc(o.coupon_code)})` : ''}</span><span>−${rs(o.discount)}</span></div>` : ''}<div class="sum-row"><span>Delivery (${esc(o.zone_name || '')})</span><span>${o.delivery_fee ? rs(o.delivery_fee) : 'Free'}</span></div><div class="sum-row total"><span>Total</span><span>${rs(o.total)}</span></div></div></section>
      ${o.events?.length ? `<section class="card"><h3 class="h-md" style="font-size:18px;margin-bottom:16px">Order history</h3><ol class="timeline">${o.events.map((e) => `<li class="done"><div style="font-weight:600;font-size:14px">${esc(e.message || e.type)}</div><div class="tiny muted">${date(e.created_at)}</div></li>`).join('')}</ol></section>` : ''}
    </div>
    <aside style="display:grid;gap:20px">
      <section class="card"><h3 class="h-md" style="font-size:18px;margin-bottom:10px">Payment</h3><div class="sum-row"><span>Method</span><span style="color:var(--text)">${esc(o.payment_method_label)}</span></div><div class="sum-row" style="margin-top:6px"><span>Status</span><span class="pill ${o.payment_status}">${esc(o.payment_status_label)}</span></div>
        ${o.payment_instructions && !['paid', 'refunded'].includes(o.payment_status) && o.status !== 'cancelled' ? `<div class="notice" style="margin-top:14px"><strong>How to pay</strong>\n${esc(o.payment_instructions)}\n\nUse <strong>${esc(o.order_number)}</strong> as the payment reference.</div>
          ${o.payment_reference_submitted ? '<div class="notice ok" style="margin-top:10px">Payment reference received — we will verify it shortly.</div>' : !allowPayRef ? '<p class="tiny muted" style="margin:10px 0 0">Open your order confirmation link or your account to submit a payment reference, or send it to us on WhatsApp.</p>' : `<form data-payref style="display:grid;gap:10px;margin-top:14px"><div class="field"><label for="pref">Transaction ID / reference</label><input class="input" id="pref" name="reference" required minlength="4" maxlength="120" placeholder="After paying, enter the transaction ID"></div><div class="form-err" role="alert"></div><button class="btn btn-ghost btn-sm" type="submit">Submit for verification</button></form>`}` : ''}
      </section>
      ${showAddress && o.address ? `<section class="card"><h3 class="h-md" style="font-size:18px;margin-bottom:10px">Delivery details</h3><p class="small" style="margin:0;line-height:1.7">${esc(o.full_name)}<br>${esc(o.address)}<br>${esc([o.area, o.city, o.postal_code].filter(Boolean).join(', '))}<br>${esc(o.phone)}${o.whatsapp ? ` · WhatsApp ${esc(o.whatsapp)}` : ''}${o.email ? `<br>${esc(o.email)}` : ''}</p>${o.notes ? `<p class="small muted" style="margin:10px 0 0">Notes: ${esc(o.notes)}</p>` : ''}</section>` : ''}
    </aside></div>`;
}
export function bindPaymentRef(root, o, token, rerender) {
  const f = qs('[data-payref]', root); if (!f) return;
  f.onsubmit = async (e) => {
    e.preventDefault(); const btn = qs('button', f); setBusy(btn, true);
    try { const upd = await api(`/orders/${o.order_number}/payment-reference${token ? `?t=${encodeURIComponent(token)}` : ''}`, { method: 'POST', body: { reference: f.reference.value } }); toast('Payment reference submitted', 'ok'); rerender(upd); }
    catch (ex) { qs('.form-err', f).textContent = ex.message; setBusy(btn, false); }
  };
}

export async function orderView(main, { number }) {
  const params = new URLSearchParams(location.search);
  let token = params.get('t');
  try { token ||= sessionStorage.getItem(`tq_order_${number}`); } catch { /* ignore */ }
  let o;
  try { o = await api(`/orders/${encodeURIComponent(number)}${token ? `?t=${encodeURIComponent(token)}` : ''}`); }
  catch { main.innerHTML = `<div class="wrap"><div class="empty-state" style="margin:60px 0"><h3>Order not found</h3><p>Use <a href="/track" style="color:var(--cyan)">Track Order</a> with your order number and mobile number.</p></div></div>`; return true; }
  // keep the secret token out of the address bar/history once used
  if (params.get('t')) { try { sessionStorage.setItem(`tq_order_${number}`, token); } catch { /* ignore */ } history.replaceState(history.state, '', `/order/${number}${params.get('new') ? '?new=1' : ''}`); }
  const isNew = params.get('new');
  const render = (ord) => {
    const wa = waLink(waOrderText(ord));
    main.innerHTML = `<div class="wrap">
      ${isNew ? `<div class="success-hero"><div class="success-ring"><svg viewBox="0 0 52 52" fill="none" stroke="var(--ok)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><path d="M14 27l8 8 16-18"/></svg></div>
        <div class="eyebrow">Order received</div><h1 class="h-lg" style="margin:12px 0">Thank you, ${esc(ord.full_name?.split(' ')[0] || '')}!</h1>
        <p class="muted" style="max-width:560px;margin:0 auto">Your order number is <strong style="color:var(--text)">${esc(ord.order_number)}</strong>. ${ord.email ? 'A confirmation has been sent to your email if email delivery is configured. ' : ''}We will contact you to confirm your order.</p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:24px">${wa ? `<a class="btn btn-wa" href="${esc(wa)}" target="_blank" rel="noopener">${brandIcon.whatsapp.replace('<svg', '<svg width="18"')} Confirm on WhatsApp</a>` : ''}<a class="btn btn-ghost" href="/shop">Continue Shopping</a></div></div>`
        : `<div class="page-head"><h1 class="h-lg">Order ${esc(ord.order_number)}</h1></div>`}
      ${orderDetailHTML(ord)}
      <p class="small muted" style="margin:24px 0 80px">Save your order number. You can check its status anytime on the <a href="/track" style="color:var(--cyan)">Track Order</a> page${state.user ? ' or in <a href="/account/orders" style="color:var(--cyan)">your account</a>' : ''}.</p></div>`;
    bindPaymentRef(main, ord, token, render);
  };
  render(o);
  return true;
}

// ---------------- Track ----------------
export async function trackView(main) {
  const params = new URLSearchParams(location.search);
  main.innerHTML = `<div class="wrap" style="padding-bottom:80px"><div class="page-head"><div class="eyebrow">Order status</div><h1 class="h-lg">Track Your Order</h1><p class="muted" style="margin:10px 0 0">Enter your order number and the mobile number used at checkout.</p></div>
    <form class="card" data-track style="max-width:640px;display:grid;gap:16px"><div class="form-grid two">
      <div class="field"><label for="t-on">Order number</label><input class="input" id="t-on" name="order_number" placeholder="TQ-XXXXXX-XXXXX" required value="${esc(params.get('order') || '')}" style="text-transform:uppercase"></div>
      <div class="field"><label for="t-ph">Mobile number</label><input class="input" id="t-ph" name="phone" type="tel" inputmode="tel" placeholder="03XX XXXXXXX" required></div></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary" type="submit">Track Order</button></form>
    <div data-result style="margin-top:28px"></div></div>`;
  const f = qs('[data-track]', main);
  f.onsubmit = async (e) => {
    e.preventDefault(); const btn = qs('button', f); const err = qs('.form-err', f); err.textContent = '';
    setBusy(btn, true);
    try { const o = await api('/track', { method: 'POST', body: formData(f) }); qs('[data-result]', main).innerHTML = orderDetailHTML(o, { showAddress: false, allowPayRef: false }); }
    catch (ex) { err.textContent = ex.message; qs('[data-result]', main).innerHTML = ''; }
    finally { setBusy(btn, false); }
  };
  return true;
}
