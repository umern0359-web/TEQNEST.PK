import { api, state, esc, qs, qsa, icon, rs, toast, refreshUser, refreshCart, mergeGuestWishlist, formData, setBusy, date } from '../core.js';
import { productCard, bindProductCards } from '../ui.js';
import { orderDetailHTML, bindPaymentRef } from './checkout.js';

const nextUrl = () => { const n = new URLSearchParams(location.search).get('next'); return n && n.startsWith('/') && !n.startsWith('//') ? n : '/account'; };

function authShell(title, sub, body) {
  return `<div class="wrap"><div class="auth-wrap"><div style="text-align:center;margin-bottom:28px"><div class="eyebrow">TEQNEST account</div><h1 class="h-lg" style="margin-top:12px">${title}</h1>${sub ? `<p class="muted" style="margin:10px 0 0">${sub}</p>` : ''}</div><div class="card">${body}</div></div></div>`;
}
function bindForm(main, sel, handler) {
  const f = qs(sel, main);
  f.onsubmit = async (e) => {
    e.preventDefault(); const btn = qs('button[type=submit]', f); const err = qs('.form-err', f); err.textContent = '';
    setBusy(btn, true);
    try { await handler(formData(f), f); } catch (ex) { err.textContent = ex.message; } finally { if (btn.isConnected) setBusy(btn, false); }
  };
}
async function afterLogin(navigate) {
  await mergeGuestWishlist();
  await Promise.all([refreshUser(), refreshCart()]);
  navigate(nextUrl(), { replace: true });
}

export async function loginView(main, { navigate }) {
  if (state.user) { navigate(nextUrl(), { replace: true }); return true; }
  main.innerHTML = authShell('Welcome back', 'Log in to track orders and manage your wishlist.', `
    <form data-login style="display:grid;gap:16px" novalidate>
      <div class="field"><label for="l-email">Email</label><input class="input" id="l-email" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="l-pw">Password</label><input class="input" id="l-pw" name="password" type="password" autocomplete="current-password" required></div>
      <div style="text-align:right"><a class="small" href="/account/forgot" style="color:var(--cyan)">Forgot password?</a></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary btn-block" type="submit">Log In</button>
      <p class="small muted" style="text-align:center;margin:0">New to TEQNEST? <a href="/account/register${location.search}" style="color:var(--cyan)">Create an account</a></p></form>`);
  bindForm(main, '[data-login]', async (d) => { await api('/account/login', { method: 'POST', body: d }); toast('Logged in', 'ok'); await afterLogin(navigate); });
  return true;
}

export async function registerView(main, { navigate }) {
  if (state.user) { navigate('/account', { replace: true }); return true; }
  main.innerHTML = authShell('Create account', 'Faster checkout, order tracking and a saved wishlist.', `
    <form data-reg style="display:grid;gap:16px" novalidate>
      <div class="field"><label for="r-name">Full name</label><input class="input" id="r-name" name="name" autocomplete="name" required maxlength="100"></div>
      <div class="field"><label for="r-email">Email</label><input class="input" id="r-email" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="r-phone">Mobile number (optional)</label><input class="input" id="r-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="03XX XXXXXXX"></div>
      <div class="field"><label for="r-pw">Password</label><input class="input" id="r-pw" name="password" type="password" autocomplete="new-password" required minlength="8"><span class="hint">At least 8 characters, with letters and numbers.</span></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary btn-block" type="submit">Create Account</button>
      <p class="small muted" style="text-align:center;margin:0">Already have an account? <a href="/account/login${location.search}" style="color:var(--cyan)">Log in</a></p></form>`);
  bindForm(main, '[data-reg]', async (d) => { await api('/account/register', { method: 'POST', body: d }); toast('Welcome to TEQNEST!', 'ok'); await afterLogin(navigate); });
  return true;
}

export async function forgotView(main) {
  main.innerHTML = authShell('Reset password', "Enter your email and we'll send you a reset link.", `
    <form data-forgot style="display:grid;gap:16px" novalidate>
      <div class="field"><label for="f-email">Email</label><input class="input" id="f-email" name="email" type="email" autocomplete="email" required></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary btn-block" type="submit">Send Reset Link</button>
      <p class="small muted" style="text-align:center;margin:0"><a href="/account/login" style="color:var(--cyan)">Back to login</a></p></form>`);
  bindForm(main, '[data-forgot]', async (d, f) => { const r = await api('/account/password/forgot', { method: 'POST', body: d }); f.innerHTML = `<div class="notice ok">${esc(r.message)}</div><a class="btn btn-ghost btn-block" href="/account/login">Back to login</a>`; });
  return true;
}

export async function resetView(main, { navigate }) {
  const token = new URLSearchParams(location.search).get('token') || '';
  main.innerHTML = authShell('Choose a new password', '', `
    <form data-reset style="display:grid;gap:16px" novalidate>
      <div class="field"><label for="n-pw">New password</label><input class="input" id="n-pw" name="password" type="password" autocomplete="new-password" required minlength="8"><span class="hint">At least 8 characters, with letters and numbers.</span></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary btn-block" type="submit">Update Password</button></form>`);
  history.replaceState(history.state, '', '/account/reset'); // remove token from URL
  bindForm(main, '[data-reset]', async (d) => { const r = await api('/account/password/reset', { method: 'POST', body: { ...d, token } }); toast(r.message, 'ok'); navigate('/account/login', { replace: true }); });
  return true;
}

// ---------------- Dashboard ----------------
const TABS = [['', 'Overview'], ['orders', 'Orders'], ['wishlist', 'Wishlist'], ['addresses', 'Addresses'], ['profile', 'Profile & Security']];

export async function accountView(main, { tab = '', sub, navigate }) {
  if (!state.user) { navigate(`/account/login?next=${encodeURIComponent(location.pathname)}`, { replace: true }); return true; }
  main.innerHTML = `<div class="wrap"><div class="page-head"><div class="eyebrow">My account</div><h1 class="h-lg">Hi, ${esc(state.user.name.split(' ')[0])}</h1></div>
    <div class="acct"><nav class="acct-nav" aria-label="Account">${TABS.map(([k, l]) => `<a href="/account${k ? '/' + k : ''}" ${tab === k ? 'aria-current="page"' : ''}>${l}</a>`).join('')}
      ${['staff', 'admin'].includes(state.user.role) ? '<a href="/admin">Admin dashboard ↗</a>' : ''}<button data-logout>Log out</button></nav>
    <div data-pane><div class="skel" style="height:240px"></div></div></div></div>`;
  qs('[data-logout]', main).onclick = async () => { await api('/account/logout', { method: 'POST' }); await Promise.all([refreshUser(), refreshCart()]); toast('Logged out'); navigate('/', { replace: true }); };
  const pane = qs('[data-pane]', main);

  if (tab === '') {
    const orders = await api('/account/orders');
    pane.innerHTML = `<div class="form-grid two" style="margin-bottom:20px">
      <div class="card"><div class="tiny muted">Orders</div><div class="h-lg">${orders.length}</div></div>
      <div class="card"><div class="tiny muted">Wishlist</div><div class="h-lg">${state.wishlist.size}</div></div></div>
      <div class="card"><h2 class="h-md" style="font-size:20px;margin-bottom:12px">Recent orders</h2>${ordersTable(orders.slice(0, 5))}</div>`;
  } else if (tab === 'orders' && sub) {
    const o = await api(`/account/orders/${encodeURIComponent(sub)}`);
    const render = (ord) => {
      pane.innerHTML = `<a class="link-arrow" href="/account/orders" style="margin-bottom:18px">${icon('left')} All orders</a>${orderDetailHTML(ord)}
        ${ord.status === 'delivered' ? `<div class="card" style="margin-top:20px"><h3 class="h-md" style="font-size:18px;margin-bottom:10px">Review your items</h3>${ord.items.filter((i) => i.product_id).map((i) => `<div class="mini-line" style="grid-template-columns:1fr auto"><span>${esc(i.name)}</span>${i.reviewed ? '<span class="tiny muted">Reviewed</span>' : `<a class="btn btn-ghost btn-sm" href="/p/${i.product_id}#review">Write review</a>`}</div>`).join('')}</div>` : ''}`;
      bindPaymentRef(pane, ord, null, render);
    };
    render(o);
  } else if (tab === 'orders') {
    pane.innerHTML = `<div class="card">${ordersTable(await api('/account/orders'))}</div>`;
  } else if (tab === 'wishlist') {
    const items = await api('/account/wishlist');
    pane.innerHTML = items.length ? `<div class="p-grid">${items.map((p) => productCard(p)).join('')}</div>` : `<div class="empty-state"><h3>Your wishlist is empty</h3><p>Tap the heart on any product to save it here.</p><a class="btn btn-primary" href="/shop">Browse Products</a></div>`;
    bindProductCards(pane, items);
  } else if (tab === 'addresses') {
    await addressesPane(pane);
  } else if (tab === 'profile') {
    profilePane(pane);
  } else return false;
  return true;
}

function ordersTable(orders) {
  if (!orders.length) return `<div class="empty-state"><h3>No orders yet</h3><p>When you place an order, it will appear here.</p><a class="btn btn-primary" href="/shop">Start Shopping</a></div>`;
  return `<div class="table-wrap"><table class="table"><thead><tr><th>Order</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th></tr></thead><tbody>
    ${orders.map((o) => `<tr><td><a href="/account/orders/${esc(o.order_number)}" style="color:var(--cyan);font-weight:600">${esc(o.order_number)}</a></td><td>${date(o.created_at)}</td><td>${o.item_count}</td><td>${rs(o.total)}</td><td><span class="pill ${o.status}">${esc(o.status[0].toUpperCase() + o.status.slice(1))}</span></td></tr>`).join('')}</tbody></table></div>`;
}

async function addressesPane(pane) {
  const zones = state.cart?.zones || [];
  const render = (list) => {
    pane.innerHTML = `<div class="addr-grid">${list.map((a) => `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><strong>${esc(a.label || 'Address')}</strong>${a.is_default ? '<span class="pill">Default</span>' : ''}</div>
      <p class="small muted" style="line-height:1.7">${esc(a.full_name)}<br>${esc(a.address)}<br>${esc([a.area, a.city, a.postal_code].filter(Boolean).join(', '))}<br>${esc(a.phone)}</p>
      <div style="display:flex;gap:8px"><button class="btn btn-ghost btn-sm" data-edit="${a.id}">Edit</button><button class="btn btn-ghost btn-sm" data-del="${a.id}">Delete</button></div></div>`).join('')}
      <button class="card" data-new style="border-style:dashed;display:grid;place-items:center;min-height:180px;color:var(--text-2)">${icon('plus').replace('<svg', '<svg width="28"')}<span>Add new address</span></button></div><div data-form></div>`;
    pane.onclick = async (e) => {
      const ed = e.target.closest('[data-edit]'); const del = e.target.closest('[data-del]');
      if (e.target.closest('[data-new]')) form({});
      else if (ed) form(list.find((a) => a.id === Number(ed.dataset.edit)));
      else if (del && confirm('Delete this address?')) render(await api(`/account/addresses/${del.dataset.del}`, { method: 'DELETE' }));
    };
  };
  const form = (a) => {
    const host = qs('[data-form]', pane);
    host.innerHTML = `<form class="card" style="margin-top:20px;display:grid;gap:16px" novalidate><h3 class="h-md" style="font-size:18px">${a.id ? 'Edit address' : 'New address'}</h3><div class="form-grid two">
      ${[['label', 'Label (e.g. Home, Office)'], ['full_name', 'Full name *'], ['phone', 'Mobile number *'], ['whatsapp', 'WhatsApp number'], ['address', 'Complete address *'], ['city', 'City *'], ['area', 'Area'], ['postal_code', 'Postal code']].map(([k, l]) => `<div class="field ${k === 'address' ? 'span-2' : ''}"><label for="a-${k}">${l}</label><input class="input" id="a-${k}" name="${k}" value="${esc(a[k] || '')}"></div>`).join('')}
      <div class="field"><label for="a-zone">Delivery area</label><select class="input" id="a-zone" name="zone_id"><option value="">—</option>${zones.map((z) => `<option value="${z.id}" ${z.id === a.zone_id ? 'selected' : ''}>${esc(z.name)}</option>`).join('')}</select></div>
      <label class="check" style="align-self:end"><input type="checkbox" name="is_default" ${a.is_default ? 'checked' : ''}> Default address</label></div>
      <div class="form-err" role="alert"></div><div style="display:flex;gap:8px"><button class="btn btn-primary" type="submit">Save Address</button><button class="btn btn-ghost" type="button" data-cancel>Cancel</button></div></form>`;
    const f = qs('form', host);
    qs('[data-cancel]', f).onclick = () => { host.innerHTML = ''; };
    f.onsubmit = async (e) => {
      e.preventDefault(); const btn = qs('[type=submit]', f); setBusy(btn, true);
      try { render(await api(`/account/addresses${a.id ? '/' + a.id : ''}`, { method: a.id ? 'PUT' : 'POST', body: formData(f) })); toast('Address saved', 'ok'); }
      catch (ex) { qs('.form-err', f).textContent = ex.message; setBusy(btn, false); }
    };
    f.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  render(await api('/account/addresses'));
}

function profilePane(pane) {
  const u = state.user;
  pane.innerHTML = `<div style="display:grid;gap:20px">
    <form class="card" data-profile style="display:grid;gap:16px" novalidate><h2 class="h-md" style="font-size:20px">Profile</h2><div class="form-grid two">
      <div class="field"><label for="p-name">Full name</label><input class="input" id="p-name" name="name" value="${esc(u.name)}" required></div>
      <div class="field"><label for="p-phone">Mobile number</label><input class="input" id="p-phone" name="phone" type="tel" value="${esc(u.phone || '')}"></div>
      <div class="field span-2"><label>Email</label><input class="input" value="${esc(u.email)}" disabled></div></div>
      <div class="form-err" role="alert"></div><button class="btn btn-primary" type="submit" style="justify-self:start">Save Changes</button></form>
    <form class="card" data-pw style="display:grid;gap:16px" novalidate><h2 class="h-md" style="font-size:20px">Change password</h2><div class="form-grid two">
      <div class="field"><label for="p-cur">Current password</label><input class="input" id="p-cur" name="current_password" type="password" autocomplete="current-password" required></div>
      <div class="field"><label for="p-new">New password</label><input class="input" id="p-new" name="new_password" type="password" autocomplete="new-password" required minlength="8"></div></div>
      <div class="form-err" role="alert"></div><button class="btn btn-ghost" type="submit" style="justify-self:start">Update Password</button></form></div>`;
  bindForm(pane, '[data-profile]', async (d) => { const r = await api('/account/profile', { method: 'PATCH', body: d }); state.user = r.user; toast('Profile updated', 'ok'); });
  bindForm(pane, '[data-pw]', async (d, f) => { const r = await api('/account/password/change', { method: 'POST', body: d }); f.reset(); toast(r.message, 'ok'); });
}

// ---------------- Wishlist (works for guests too) ----------------
export async function wishlistView(main) {
  main.innerHTML = `<div class="wrap" style="padding-bottom:80px"><div class="page-head"><h1 class="h-lg">Wishlist</h1>${!state.user ? '<p class="muted" style="margin:10px 0 0">Saved on this device. <a href="/account/login?next=/wishlist" style="color:var(--cyan)">Log in</a> to keep your wishlist across devices.</p>' : ''}</div><div data-wl></div></div>`;
  const ids = [...state.wishlist];
  const items = ids.length ? (await api(`/products?ids=${ids.join(',')}&limit=48`)).products : [];
  const host = qs('[data-wl]', main);
  host.innerHTML = items.length ? `<div class="p-grid cols-4">${items.map((p) => productCard(p)).join('')}</div>` : `<div class="empty-state"><h3>Your wishlist is empty</h3><p>Tap the heart on any product to save it here.</p><a class="btn btn-primary" href="/shop">Browse Products</a></div>`;
  bindProductCards(host, items);
  return true;
}
